/*******************************************************************************
* File Name: CSSoilMoisture_TunerHelper.h
* Version 3.50
*
* Description:
*  This file provides constants and structure declarations for the tunner hepl
*  APIs for CapSense CSD component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CAPSENSE_CSD_TUNERHELPER_CSSoilMoisture_H)
#define CY_CAPSENSE_CSD_TUNERHELPER_CSSoilMoisture_H

#include "CSSoilMoisture.h"
#include "CSSoilMoisture_CSHL.h"
#if (CSSoilMoisture_TUNER_API_GENERATE)
    #include "CSSoilMoisture_MBX.h"
    #include "EZI2C.h"
#endif /* (CSSoilMoisture_TUNER_API_GENERATE) */


/***************************************
*     Constants for mailboxes
***************************************/

#define CSSoilMoisture_DEFAULT_MAILBOXES_NUMBER   (1u)


/***************************************
*        Function Prototypes
***************************************/

void CSSoilMoisture_TunerStart(void) ;
void CSSoilMoisture_TunerComm(void) ;

#if (CSSoilMoisture_TUNER_API_GENERATE)
    CSSoilMoisture_NO_STRICT_VOLATILE void CSSoilMoisture_ProcessAllWidgets(volatile CSSoilMoisture_OUTBOX *outbox)
	                                        					;

    extern volatile CSSoilMoisture_MAILBOXES CSSoilMoisture_mailboxesComm;
#endif /* (CSSoilMoisture_TUNER_API_GENERATE) */

#endif  /* (CY_CAPSENSE_CSD_TUNERHELPER_CSSoilMoisture_H)*/


/* [] END OF FILE */
