/*******************************************************************************
* File Name: CSSoilMoisture_AMuxCH0.h
* Version 3.50
*
*  Description:
*    This file contains the constants and function prototypes for the Analog
*    Multiplexer User Module CapSense_CSD_AMux.
*
*   Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CAPSENSE_CSD_AMUX_CSSoilMoisture_AMuxCH0_H)
#define CY_CAPSENSE_CSD_AMUX_CSSoilMoisture_AMuxCH0_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cyfitter_cfg.h"


/***************************************
*        Function Prototypes
***************************************/

void CSSoilMoisture_AMuxCH0_Start(void);
void CSSoilMoisture_AMuxCH0_Init(void);
void CSSoilMoisture_AMuxCH0_Stop(void);
void CSSoilMoisture_AMuxCH0_Select(uint8 channel) CYREENTRANT;
void CSSoilMoisture_AMuxCH0_FastSelect(uint8 channel) CYREENTRANT;
void CSSoilMoisture_AMuxCH0_DisconnectAll(void) CYREENTRANT;
/* The Connect and Disconnect functions are declared elsewhere */
/* void CSSoilMoisture_AMuxCH0_Connect(uint8 channel); */
/* void CSSoilMoisture_AMuxCH0_Disconnect(uint8 channel); */


/***************************************
*     Initial Parameter Constants
***************************************/

#define CSSoilMoisture_AMuxCH0_CHANNELS  (1u + 2u +1u+ 0u)
#define CSSoilMoisture_AMuxCH0_MUXTYPE   (1u)


/***************************************
*             API Constants
***************************************/

#define CSSoilMoisture_AMuxCH0_NULL_CHANNEL   (0xFFu)
#define CSSoilMoisture_AMuxCH0_MUX_SINGLE     (1u)
#define CSSoilMoisture_AMuxCH0_MUX_DIFF       (2u)


/***************************************
*        Conditional Functions
***************************************/

#if (CSSoilMoisture_AMuxCH0_MUXTYPE == CSSoilMoisture_AMuxCH0_MUX_SINGLE)
#define CSSoilMoisture_AMuxCH0_Connect(channel) CSSoilMoisture_AMuxCH0_Set(channel)
#define CSSoilMoisture_AMuxCH0_Disconnect(channel) CSSoilMoisture_AMuxCH0_Unset(channel)
#else
    void CSSoilMoisture_AMuxCH0_Connect(uint8 channel) CYREENTRANT;
    void CSSoilMoisture_AMuxCH0_Disconnect(uint8 channel) CYREENTRANT;
#endif  /* End (CSSoilMoisture_AMuxCH0_MUXTYPE == CSSoilMoisture_AMuxCH0_MUX_SINGLE) */

#endif /* CY_CAPSENSE_CSD_AMUX_CSSoilMoisture_AMuxCH0_H */


/* [] END OF FILE */
