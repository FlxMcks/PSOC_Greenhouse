/*******************************************************************************
* File Name: TOneSec_PM.c
* Version 2.80
*
*  Description:
*     This file provides the power management source code to API for the
*     Timer.
*
*   Note:
*     None
*
*******************************************************************************
* Copyright 2008-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#include "TOneSec.h"

static TOneSec_backupStruct TOneSec_backup;


/*******************************************************************************
* Function Name: TOneSec_SaveConfig
********************************************************************************
*
* Summary:
*     Save the current user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  TOneSec_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void TOneSec_SaveConfig(void) 
{
    #if (!TOneSec_UsingFixedFunction)
        TOneSec_backup.TimerUdb = TOneSec_ReadCounter();
        TOneSec_backup.InterruptMaskValue = TOneSec_STATUS_MASK;
        #if (TOneSec_UsingHWCaptureCounter)
            TOneSec_backup.TimerCaptureCounter = TOneSec_ReadCaptureCount();
        #endif /* Back Up capture counter register  */

        #if(!TOneSec_UDB_CONTROL_REG_REMOVED)
            TOneSec_backup.TimerControlRegister = TOneSec_ReadControlRegister();
        #endif /* Backup the enable state of the Timer component */
    #endif /* Backup non retention registers in UDB implementation. All fixed function registers are retention */
}


/*******************************************************************************
* Function Name: TOneSec_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  TOneSec_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void TOneSec_RestoreConfig(void) 
{   
    #if (!TOneSec_UsingFixedFunction)

        TOneSec_WriteCounter(TOneSec_backup.TimerUdb);
        TOneSec_STATUS_MASK =TOneSec_backup.InterruptMaskValue;
        #if (TOneSec_UsingHWCaptureCounter)
            TOneSec_SetCaptureCount(TOneSec_backup.TimerCaptureCounter);
        #endif /* Restore Capture counter register*/

        #if(!TOneSec_UDB_CONTROL_REG_REMOVED)
            TOneSec_WriteControlRegister(TOneSec_backup.TimerControlRegister);
        #endif /* Restore the enable state of the Timer component */
    #endif /* Restore non retention registers in the UDB implementation only */
}


/*******************************************************************************
* Function Name: TOneSec_Sleep
********************************************************************************
*
* Summary:
*     Stop and Save the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  TOneSec_backup.TimerEnableState:  Is modified depending on the
*  enable state of the block before entering sleep mode.
*
*******************************************************************************/
void TOneSec_Sleep(void) 
{
    #if(!TOneSec_UDB_CONTROL_REG_REMOVED)
        /* Save Counter's enable state */
        if(TOneSec_CTRL_ENABLE == (TOneSec_CONTROL & TOneSec_CTRL_ENABLE))
        {
            /* Timer is enabled */
            TOneSec_backup.TimerEnableState = 1u;
        }
        else
        {
            /* Timer is disabled */
            TOneSec_backup.TimerEnableState = 0u;
        }
    #endif /* Back up enable state from the Timer control register */
    TOneSec_Stop();
    TOneSec_SaveConfig();
}


/*******************************************************************************
* Function Name: TOneSec_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  TOneSec_backup.enableState:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void TOneSec_Wakeup(void) 
{
    TOneSec_RestoreConfig();
    #if(!TOneSec_UDB_CONTROL_REG_REMOVED)
        if(TOneSec_backup.TimerEnableState == 1u)
        {     /* Enable Timer's operation */
                TOneSec_Enable();
        } /* Do nothing if Timer was disabled before */
    #endif /* Remove this code section if Control register is removed */
}


/* [] END OF FILE */
