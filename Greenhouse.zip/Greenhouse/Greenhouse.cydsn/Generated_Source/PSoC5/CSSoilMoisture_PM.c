/*******************************************************************************
* File Name: CSSoilMoisture_PM.c
* Version 3.50
*
* Description:
*  This file provides Sleep APIs for CapSense CSD Component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "CSSoilMoisture.h"

CSSoilMoisture_BACKUP_STRUCT CSSoilMoisture_backup =
{   
    0x00u, /* enableState; */
    
};


/*******************************************************************************
* Function Name: CSSoilMoisture_SaveConfig
********************************************************************************
*
* Summary:
*  Saves customer configuration of CapSense none-retention registers. Resets 
*  all sensors to an inactive state.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Side Effects:
*  Function CSSoilMoisture_SaveConfig disconnects all sensors from the
*  Analog MUX Bus and puts them into inactive state. Call this function
*  during the active scan can cause unpredictable component behavior.
*
* Note:
*  This function should be called after completion of all scans.
*
* Global Variables:
*  CSSoilMoisture_backup - used to save component state before enter sleep 
*  mode and none-retention registers.
*
* Reentrant:
*  Yes.
*
*******************************************************************************/
void CSSoilMoisture_SaveConfig(void) 
{    

    /* Set CONTROL_REG */
    CSSoilMoisture_backup.ctrlReg = CSSoilMoisture_CONTROL_REG;

    /* Clear all sensors */
    CSSoilMoisture_ClearSensors();
    
    /* The pins disable is customer concern: Cmod and Rb */
}


/*******************************************************************************
* Function Name: CSSoilMoisture_Sleep
********************************************************************************
*
* Summary:
*  Disables Active mode power template bits for number of component used within 
*  CapSense. Calls CSSoilMoisture_SaveConfig() function to save customer 
*  configuration of CapSense none-retention registers and resets all sensors 
*  to an inactive state.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Side Effects:
*  Function CSSoilMoisture_Sleep disconnects all sensors from the
*  Analog MUX Bus and puts them into inactive state. Call this function
*  during the active scan can cause unpredictable component behavior.
*
* Note:
*  This function should be called after completion of all scans.
*
* Global Variables:
*  CSSoilMoisture_backup - used to save component state before enter sleep 
*  mode and none-retention registers.
*
* Reentrant:
*  No
*
*******************************************************************************/
void CSSoilMoisture_Sleep(void) 
{
    /* Check and save enable state */
    if(CSSoilMoisture_IS_CAPSENSE_ENABLE(CSSoilMoisture_CONTROL_REG))
    {
        CSSoilMoisture_backup.enableState = 1u;
        CSSoilMoisture_Stop();
    }
    else
    {
        CSSoilMoisture_backup.enableState = 0u;
    }
    
    CSSoilMoisture_SaveConfig();
}


/*******************************************************************************
* Function Name: CSSoilMoisture_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores CapSense configuration and non-retention register values.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Side Effects:
*  Must be called only after CSSoilMoisture_SaveConfig() routine. Otherwise 
*  the component configuration will be overwritten with its initial setting.
*  This finction modifies the CONTROL_REG register. 
*
* Note:
*  This function should be called after completion of all scans.
*
* Global Variables:
*  CSSoilMoisture_backup - used to save component state before enter sleep 
*  mode and none-retention registers.
*
*******************************************************************************/
void CSSoilMoisture_RestoreConfig(void) 
{       
    /* Set PRS */
    #if (CSSoilMoisture_PRS_OPTIONS == CSSoilMoisture_PRS_8BITS)        
        /* Write FIFO with seed */
        CSSoilMoisture_SEED_COPY_REG = CSSoilMoisture_MEASURE_FULL_RANGE_LOW;               /* F0 register */
    
    #elif (CSSoilMoisture_PRS_OPTIONS == CSSoilMoisture_PRS_16BITS)
        /* Write FIFO with seed */
        CY_SET_REG16(CSSoilMoisture_SEED_COPY_PTR, CSSoilMoisture_MEASURE_FULL_RANGE);      /* F0 register */
                
    #elif (CSSoilMoisture_PRS_OPTIONS == CSSoilMoisture_PRS_16BITS_4X)
        
        /* Write FIFO with seed */
        CSSoilMoisture_SEED_COPY_A__F1_REG = CSSoilMoisture_MEASURE_FULL_RANGE_LOW;         /* F0 register */
        CSSoilMoisture_SEED_COPY_A__F0_REG =CSSoilMoisture_MEASURE_FULL_RANGE_LOW;          /* F1 register */
        
    #else
        /* Do nothing = config without PRS */
    #endif  /* (CSSoilMoisture_PRS_OPTIONS == CSSoilMoisture_PRS_8BITS) */
    
    /* Set the Measure */
    #if (CSSoilMoisture_IMPLEMENTATION_CH0 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF)
        /* Window PWM  - FF Timer register are retention */
        /* Raw Counter - FF Timer register are retention */
    #else
        
        /* Window PWM */
        CSSoilMoisture_PWM_CH0_PERIOD_LO_REG    = CSSoilMoisture_MEASURE_FULL_RANGE_LOW;        /* F0 register */
        
        /* Raw Counter */
        CSSoilMoisture_RAW_CH0_PERIOD_HI_REG    = CSSoilMoisture_MEASURE_FULL_RANGE_LOW;        /* F1 register */
        CSSoilMoisture_RAW_CH0_PERIOD_LO_REG    = CSSoilMoisture_MEASURE_FULL_RANGE_LOW;        /* F0 register */
    
    #endif  /* (CSSoilMoisture_IMPLEMENTATION_CH0 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF) */ 
    
    #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN)
        #if (CSSoilMoisture_IMPLEMENTATION_CH1 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF)
            /* Window PWM  - FF Timer register are retention */
            /* Raw Counter - FF Timer register are retention */
        #else
            
            /* Window PWM */
            CSSoilMoisture_PWM_CH1_PERIOD_LO_REG    = CSSoilMoisture_MEASURE_FULL_RANGE_LOW;       /* F0 register */
            
            /* Raw Counter */
            CSSoilMoisture_RAW_CH1_PERIOD_HI_REG    = CSSoilMoisture_MEASURE_FULL_RANGE_LOW;       /* F1 register */
            CSSoilMoisture_RAW_CH1_PERIOD_LO_REG    = CSSoilMoisture_MEASURE_FULL_RANGE_LOW;       /* F0 register */
            
        #endif  /* (CSSoilMoisture_IMPLEMENTATION_CH1 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF) */
    
    #endif  /* (CSSoilMoisture_DESIGN_TYPE == TWO_CHANNELS_DESIGN)*/

    /* Set CONTROL_REG */
    CSSoilMoisture_CONTROL_REG = CSSoilMoisture_backup.ctrlReg;

    /* Enable window generation */
    #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_ONE_CHANNEL_DESIGN)
        CSSoilMoisture_CONTROL_REG |= CSSoilMoisture_CTRL_WINDOW_EN__CH0;
    #elif (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN) 
        CSSoilMoisture_CONTROL_REG |= (CSSoilMoisture_CTRL_WINDOW_EN__CH0 | CSSoilMoisture_CTRL_WINDOW_EN__CH1); 
    #endif  /* CSSoilMoisture_DESIGN_TYPE */
 
    /* The pins enable are customer concern: Cmod and Rb */
 }
 

/*******************************************************************************
* Function Name: CSSoilMoisture_Wakeup
********************************************************************************
*
* Summary:
*  Restores CapSense configuration and non-retention register values. 
*  Restores enabled state of component by setting Active mode power template 
*  bits for number of component used within CapSense.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Side Effects:
*  Must be called only after CSSoilMoisture_SaveConfig() routine. Otherwise 
*  the component configuration will be overwritten with its initial setting.
*  This finction modifies the CONTROL_REG register. 
*
* Note:
*  This function should be called after completion of all scans.
*
* Global Variables:
*  CSSoilMoisture_backup - used to save component state before enter sleep 
*  mode and none-retention registers.
*
*******************************************************************************/
void CSSoilMoisture_Wakeup(void) 
{
    CSSoilMoisture_RestoreConfig();
    
    /* Restore CapSense Enable state */
    if (CSSoilMoisture_backup.enableState != 0u)
    {
        CSSoilMoisture_Enable();
    }
}


/* [] END OF FILE */
