/*******************************************************************************
* File Name: TOneSec.h
* Version 2.80
*
*  Description:
*     Contains the function prototypes and constants available to the timer
*     user module.
*
*   Note:
*     None
*
********************************************************************************
* Copyright 2008-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#if !defined(CY_TIMER_TOneSec_H)
#define CY_TIMER_TOneSec_H

#include "cytypes.h"
#include "cyfitter.h"
#include "CyLib.h" /* For CyEnterCriticalSection() and CyExitCriticalSection() functions */

extern uint8 TOneSec_initVar;

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component Timer_v2_80 requires cy_boot v3.0 or later
#endif /* (CY_ PSOC5LP) */


/**************************************
*           Parameter Defaults
**************************************/

#define TOneSec_Resolution                 8u
#define TOneSec_UsingFixedFunction         1u
#define TOneSec_UsingHWCaptureCounter      0u
#define TOneSec_SoftwareCaptureMode        0u
#define TOneSec_SoftwareTriggerMode        0u
#define TOneSec_UsingHWEnable              0u
#define TOneSec_EnableTriggerMode          0u
#define TOneSec_InterruptOnCaptureCount    0u
#define TOneSec_RunModeUsed                0u
#define TOneSec_ControlRegRemoved          0u

#if defined(TOneSec_TimerUDB_sCTRLReg_SyncCtl_ctrlreg__CONTROL_REG)
    #define TOneSec_UDB_CONTROL_REG_REMOVED            (0u)
#elif  (TOneSec_UsingFixedFunction)
    #define TOneSec_UDB_CONTROL_REG_REMOVED            (0u)
#else 
    #define TOneSec_UDB_CONTROL_REG_REMOVED            (1u)
#endif /* End TOneSec_TimerUDB_sCTRLReg_SyncCtl_ctrlreg__CONTROL_REG */


/***************************************
*       Type defines
***************************************/


/**************************************************************************
 * Sleep Wakeup Backup structure for Timer Component
 *************************************************************************/
typedef struct
{
    uint8 TimerEnableState;
    #if(!TOneSec_UsingFixedFunction)

        uint8 TimerUdb;
        uint8 InterruptMaskValue;
        #if (TOneSec_UsingHWCaptureCounter)
            uint8 TimerCaptureCounter;
        #endif /* variable declarations for backing up non retention registers in CY_UDB_V1 */

        #if (!TOneSec_UDB_CONTROL_REG_REMOVED)
            uint8 TimerControlRegister;
        #endif /* variable declaration for backing up enable state of the Timer */
    #endif /* define backup variables only for UDB implementation. Fixed function registers are all retention */

}TOneSec_backupStruct;


/***************************************
*       Function Prototypes
***************************************/

void    TOneSec_Start(void) ;
void    TOneSec_Stop(void) ;

void    TOneSec_SetInterruptMode(uint8 interruptMode) ;
uint8   TOneSec_ReadStatusRegister(void) ;
/* Deprecated function. Do not use this in future. Retained for backward compatibility */
#define TOneSec_GetInterruptSource() TOneSec_ReadStatusRegister()

#if(!TOneSec_UDB_CONTROL_REG_REMOVED)
    uint8   TOneSec_ReadControlRegister(void) ;
    void    TOneSec_WriteControlRegister(uint8 control) ;
#endif /* (!TOneSec_UDB_CONTROL_REG_REMOVED) */

uint8  TOneSec_ReadPeriod(void) ;
void    TOneSec_WritePeriod(uint8 period) ;
uint8  TOneSec_ReadCounter(void) ;
void    TOneSec_WriteCounter(uint8 counter) ;
uint8  TOneSec_ReadCapture(void) ;
void    TOneSec_SoftwareCapture(void) ;

#if(!TOneSec_UsingFixedFunction) /* UDB Prototypes */
    #if (TOneSec_SoftwareCaptureMode)
        void    TOneSec_SetCaptureMode(uint8 captureMode) ;
    #endif /* (!TOneSec_UsingFixedFunction) */

    #if (TOneSec_SoftwareTriggerMode)
        void    TOneSec_SetTriggerMode(uint8 triggerMode) ;
    #endif /* (TOneSec_SoftwareTriggerMode) */

    #if (TOneSec_EnableTriggerMode)
        void    TOneSec_EnableTrigger(void) ;
        void    TOneSec_DisableTrigger(void) ;
    #endif /* (TOneSec_EnableTriggerMode) */


    #if(TOneSec_InterruptOnCaptureCount)
        void    TOneSec_SetInterruptCount(uint8 interruptCount) ;
    #endif /* (TOneSec_InterruptOnCaptureCount) */

    #if (TOneSec_UsingHWCaptureCounter)
        void    TOneSec_SetCaptureCount(uint8 captureCount) ;
        uint8   TOneSec_ReadCaptureCount(void) ;
    #endif /* (TOneSec_UsingHWCaptureCounter) */

    void TOneSec_ClearFIFO(void) ;
#endif /* UDB Prototypes */

/* Sleep Retention APIs */
void TOneSec_Init(void)          ;
void TOneSec_Enable(void)        ;
void TOneSec_SaveConfig(void)    ;
void TOneSec_RestoreConfig(void) ;
void TOneSec_Sleep(void)         ;
void TOneSec_Wakeup(void)        ;


/***************************************
*   Enumerated Types and Parameters
***************************************/

/* Enumerated Type B_Timer__CaptureModes, Used in Capture Mode */
#define TOneSec__B_TIMER__CM_NONE 0
#define TOneSec__B_TIMER__CM_RISINGEDGE 1
#define TOneSec__B_TIMER__CM_FALLINGEDGE 2
#define TOneSec__B_TIMER__CM_EITHEREDGE 3
#define TOneSec__B_TIMER__CM_SOFTWARE 4



/* Enumerated Type B_Timer__TriggerModes, Used in Trigger Mode */
#define TOneSec__B_TIMER__TM_NONE 0x00u
#define TOneSec__B_TIMER__TM_RISINGEDGE 0x04u
#define TOneSec__B_TIMER__TM_FALLINGEDGE 0x08u
#define TOneSec__B_TIMER__TM_EITHEREDGE 0x0Cu
#define TOneSec__B_TIMER__TM_SOFTWARE 0x10u


/***************************************
*    Initialial Parameter Constants
***************************************/

#define TOneSec_INIT_PERIOD             99u
#define TOneSec_INIT_CAPTURE_MODE       ((uint8)((uint8)1u << TOneSec_CTRL_CAP_MODE_SHIFT))
#define TOneSec_INIT_TRIGGER_MODE       ((uint8)((uint8)0u << TOneSec_CTRL_TRIG_MODE_SHIFT))
#if (TOneSec_UsingFixedFunction)
    #define TOneSec_INIT_INTERRUPT_MODE (((uint8)((uint8)1u << TOneSec_STATUS_TC_INT_MASK_SHIFT)) | \
                                                  ((uint8)((uint8)0 << TOneSec_STATUS_CAPTURE_INT_MASK_SHIFT)))
#else
    #define TOneSec_INIT_INTERRUPT_MODE (((uint8)((uint8)1u << TOneSec_STATUS_TC_INT_MASK_SHIFT)) | \
                                                 ((uint8)((uint8)0 << TOneSec_STATUS_CAPTURE_INT_MASK_SHIFT)) | \
                                                 ((uint8)((uint8)0 << TOneSec_STATUS_FIFOFULL_INT_MASK_SHIFT)))
#endif /* (TOneSec_UsingFixedFunction) */
#define TOneSec_INIT_CAPTURE_COUNT      (2u)
#define TOneSec_INIT_INT_CAPTURE_COUNT  ((uint8)((uint8)(1u - 1u) << TOneSec_CTRL_INTCNT_SHIFT))


/***************************************
*           Registers
***************************************/

#if (TOneSec_UsingFixedFunction) /* Implementation Specific Registers and Register Constants */


    /***************************************
    *    Fixed Function Registers
    ***************************************/

    #define TOneSec_STATUS         (*(reg8 *) TOneSec_TimerHW__SR0 )
    /* In Fixed Function Block Status and Mask are the same register */
    #define TOneSec_STATUS_MASK    (*(reg8 *) TOneSec_TimerHW__SR0 )
    #define TOneSec_CONTROL        (*(reg8 *) TOneSec_TimerHW__CFG0)
    #define TOneSec_CONTROL2       (*(reg8 *) TOneSec_TimerHW__CFG1)
    #define TOneSec_CONTROL2_PTR   ( (reg8 *) TOneSec_TimerHW__CFG1)
    #define TOneSec_RT1            (*(reg8 *) TOneSec_TimerHW__RT1)
    #define TOneSec_RT1_PTR        ( (reg8 *) TOneSec_TimerHW__RT1)

    #if (CY_PSOC3 || CY_PSOC5LP)
        #define TOneSec_CONTROL3       (*(reg8 *) TOneSec_TimerHW__CFG2)
        #define TOneSec_CONTROL3_PTR   ( (reg8 *) TOneSec_TimerHW__CFG2)
    #endif /* (CY_PSOC3 || CY_PSOC5LP) */
    #define TOneSec_GLOBAL_ENABLE  (*(reg8 *) TOneSec_TimerHW__PM_ACT_CFG)
    #define TOneSec_GLOBAL_STBY_ENABLE  (*(reg8 *) TOneSec_TimerHW__PM_STBY_CFG)

    #define TOneSec_CAPTURE_LSB         (* (reg16 *) TOneSec_TimerHW__CAP0 )
    #define TOneSec_CAPTURE_LSB_PTR       ((reg16 *) TOneSec_TimerHW__CAP0 )
    #define TOneSec_PERIOD_LSB          (* (reg16 *) TOneSec_TimerHW__PER0 )
    #define TOneSec_PERIOD_LSB_PTR        ((reg16 *) TOneSec_TimerHW__PER0 )
    #define TOneSec_COUNTER_LSB         (* (reg16 *) TOneSec_TimerHW__CNT_CMP0 )
    #define TOneSec_COUNTER_LSB_PTR       ((reg16 *) TOneSec_TimerHW__CNT_CMP0 )


    /***************************************
    *    Register Constants
    ***************************************/

    /* Fixed Function Block Chosen */
    #define TOneSec_BLOCK_EN_MASK                     TOneSec_TimerHW__PM_ACT_MSK
    #define TOneSec_BLOCK_STBY_EN_MASK                TOneSec_TimerHW__PM_STBY_MSK

    /* Control Register Bit Locations */
    /* Interrupt Count - Not valid for Fixed Function Block */
    #define TOneSec_CTRL_INTCNT_SHIFT                  0x00u
    /* Trigger Polarity - Not valid for Fixed Function Block */
    #define TOneSec_CTRL_TRIG_MODE_SHIFT               0x00u
    /* Trigger Enable - Not valid for Fixed Function Block */
    #define TOneSec_CTRL_TRIG_EN_SHIFT                 0x00u
    /* Capture Polarity - Not valid for Fixed Function Block */
    #define TOneSec_CTRL_CAP_MODE_SHIFT                0x00u
    /* Timer Enable - As defined in Register Map, part of TMRX_CFG0 register */
    #define TOneSec_CTRL_ENABLE_SHIFT                  0x00u

    /* Control Register Bit Masks */
    #define TOneSec_CTRL_ENABLE                        ((uint8)((uint8)0x01u << TOneSec_CTRL_ENABLE_SHIFT))

    /* Control2 Register Bit Masks */
    /* As defined in Register Map, Part of the TMRX_CFG1 register */
    #define TOneSec_CTRL2_IRQ_SEL_SHIFT                 0x00u
    #define TOneSec_CTRL2_IRQ_SEL                      ((uint8)((uint8)0x01u << TOneSec_CTRL2_IRQ_SEL_SHIFT))

    #if (CY_PSOC5A)
        /* Use CFG1 Mode bits to set run mode */
        /* As defined by Verilog Implementation */
        #define TOneSec_CTRL_MODE_SHIFT                 0x01u
        #define TOneSec_CTRL_MODE_MASK                 ((uint8)((uint8)0x07u << TOneSec_CTRL_MODE_SHIFT))
    #endif /* (CY_PSOC5A) */
    #if (CY_PSOC3 || CY_PSOC5LP)
        /* Control3 Register Bit Locations */
        #define TOneSec_CTRL_RCOD_SHIFT        0x02u
        #define TOneSec_CTRL_ENBL_SHIFT        0x00u
        #define TOneSec_CTRL_MODE_SHIFT        0x00u

        /* Control3 Register Bit Masks */
        #define TOneSec_CTRL_RCOD_MASK  ((uint8)((uint8)0x03u << TOneSec_CTRL_RCOD_SHIFT)) /* ROD and COD bit masks */
        #define TOneSec_CTRL_ENBL_MASK  ((uint8)((uint8)0x80u << TOneSec_CTRL_ENBL_SHIFT)) /* HW_EN bit mask */
        #define TOneSec_CTRL_MODE_MASK  ((uint8)((uint8)0x03u << TOneSec_CTRL_MODE_SHIFT)) /* Run mode bit mask */

        #define TOneSec_CTRL_RCOD       ((uint8)((uint8)0x03u << TOneSec_CTRL_RCOD_SHIFT))
        #define TOneSec_CTRL_ENBL       ((uint8)((uint8)0x80u << TOneSec_CTRL_ENBL_SHIFT))
    #endif /* (CY_PSOC3 || CY_PSOC5LP) */

    /*RT1 Synch Constants: Applicable for PSoC3 and PSoC5LP */
    #define TOneSec_RT1_SHIFT                       0x04u
    /* Sync TC and CMP bit masks */
    #define TOneSec_RT1_MASK                        ((uint8)((uint8)0x03u << TOneSec_RT1_SHIFT))
    #define TOneSec_SYNC                            ((uint8)((uint8)0x03u << TOneSec_RT1_SHIFT))
    #define TOneSec_SYNCDSI_SHIFT                   0x00u
    /* Sync all DSI inputs with Mask  */
    #define TOneSec_SYNCDSI_MASK                    ((uint8)((uint8)0x0Fu << TOneSec_SYNCDSI_SHIFT))
    /* Sync all DSI inputs */
    #define TOneSec_SYNCDSI_EN                      ((uint8)((uint8)0x0Fu << TOneSec_SYNCDSI_SHIFT))

    #define TOneSec_CTRL_MODE_PULSEWIDTH            ((uint8)((uint8)0x01u << TOneSec_CTRL_MODE_SHIFT))
    #define TOneSec_CTRL_MODE_PERIOD                ((uint8)((uint8)0x02u << TOneSec_CTRL_MODE_SHIFT))
    #define TOneSec_CTRL_MODE_CONTINUOUS            ((uint8)((uint8)0x00u << TOneSec_CTRL_MODE_SHIFT))

    /* Status Register Bit Locations */
    /* As defined in Register Map, part of TMRX_SR0 register */
    #define TOneSec_STATUS_TC_SHIFT                 0x07u
    /* As defined in Register Map, part of TMRX_SR0 register, Shared with Compare Status */
    #define TOneSec_STATUS_CAPTURE_SHIFT            0x06u
    /* As defined in Register Map, part of TMRX_SR0 register */
    #define TOneSec_STATUS_TC_INT_MASK_SHIFT        (TOneSec_STATUS_TC_SHIFT - 0x04u)
    /* As defined in Register Map, part of TMRX_SR0 register, Shared with Compare Status */
    #define TOneSec_STATUS_CAPTURE_INT_MASK_SHIFT   (TOneSec_STATUS_CAPTURE_SHIFT - 0x04u)

    /* Status Register Bit Masks */
    #define TOneSec_STATUS_TC                       ((uint8)((uint8)0x01u << TOneSec_STATUS_TC_SHIFT))
    #define TOneSec_STATUS_CAPTURE                  ((uint8)((uint8)0x01u << TOneSec_STATUS_CAPTURE_SHIFT))
    /* Interrupt Enable Bit-Mask for interrupt on TC */
    #define TOneSec_STATUS_TC_INT_MASK              ((uint8)((uint8)0x01u << TOneSec_STATUS_TC_INT_MASK_SHIFT))
    /* Interrupt Enable Bit-Mask for interrupt on Capture */
    #define TOneSec_STATUS_CAPTURE_INT_MASK         ((uint8)((uint8)0x01u << TOneSec_STATUS_CAPTURE_INT_MASK_SHIFT))

#else   /* UDB Registers and Register Constants */


    /***************************************
    *           UDB Registers
    ***************************************/

    #define TOneSec_STATUS              (* (reg8 *) TOneSec_TimerUDB_rstSts_stsreg__STATUS_REG )
    #define TOneSec_STATUS_MASK         (* (reg8 *) TOneSec_TimerUDB_rstSts_stsreg__MASK_REG)
    #define TOneSec_STATUS_AUX_CTRL     (* (reg8 *) TOneSec_TimerUDB_rstSts_stsreg__STATUS_AUX_CTL_REG)
    #define TOneSec_CONTROL             (* (reg8 *) TOneSec_TimerUDB_sCTRLReg_SyncCtl_ctrlreg__CONTROL_REG )
    
    #if(TOneSec_Resolution <= 8u) /* 8-bit Timer */
        #define TOneSec_CAPTURE_LSB         (* (reg8 *) TOneSec_TimerUDB_sT8_timerdp_u0__F0_REG )
        #define TOneSec_CAPTURE_LSB_PTR       ((reg8 *) TOneSec_TimerUDB_sT8_timerdp_u0__F0_REG )
        #define TOneSec_PERIOD_LSB          (* (reg8 *) TOneSec_TimerUDB_sT8_timerdp_u0__D0_REG )
        #define TOneSec_PERIOD_LSB_PTR        ((reg8 *) TOneSec_TimerUDB_sT8_timerdp_u0__D0_REG )
        #define TOneSec_COUNTER_LSB         (* (reg8 *) TOneSec_TimerUDB_sT8_timerdp_u0__A0_REG )
        #define TOneSec_COUNTER_LSB_PTR       ((reg8 *) TOneSec_TimerUDB_sT8_timerdp_u0__A0_REG )
    #elif(TOneSec_Resolution <= 16u) /* 8-bit Timer */
        #if(CY_PSOC3) /* 8-bit addres space */
            #define TOneSec_CAPTURE_LSB         (* (reg16 *) TOneSec_TimerUDB_sT8_timerdp_u0__F0_REG )
            #define TOneSec_CAPTURE_LSB_PTR       ((reg16 *) TOneSec_TimerUDB_sT8_timerdp_u0__F0_REG )
            #define TOneSec_PERIOD_LSB          (* (reg16 *) TOneSec_TimerUDB_sT8_timerdp_u0__D0_REG )
            #define TOneSec_PERIOD_LSB_PTR        ((reg16 *) TOneSec_TimerUDB_sT8_timerdp_u0__D0_REG )
            #define TOneSec_COUNTER_LSB         (* (reg16 *) TOneSec_TimerUDB_sT8_timerdp_u0__A0_REG )
            #define TOneSec_COUNTER_LSB_PTR       ((reg16 *) TOneSec_TimerUDB_sT8_timerdp_u0__A0_REG )
        #else /* 16-bit address space */
            #define TOneSec_CAPTURE_LSB         (* (reg16 *) TOneSec_TimerUDB_sT8_timerdp_u0__16BIT_F0_REG )
            #define TOneSec_CAPTURE_LSB_PTR       ((reg16 *) TOneSec_TimerUDB_sT8_timerdp_u0__16BIT_F0_REG )
            #define TOneSec_PERIOD_LSB          (* (reg16 *) TOneSec_TimerUDB_sT8_timerdp_u0__16BIT_D0_REG )
            #define TOneSec_PERIOD_LSB_PTR        ((reg16 *) TOneSec_TimerUDB_sT8_timerdp_u0__16BIT_D0_REG )
            #define TOneSec_COUNTER_LSB         (* (reg16 *) TOneSec_TimerUDB_sT8_timerdp_u0__16BIT_A0_REG )
            #define TOneSec_COUNTER_LSB_PTR       ((reg16 *) TOneSec_TimerUDB_sT8_timerdp_u0__16BIT_A0_REG )
        #endif /* CY_PSOC3 */
    #elif(TOneSec_Resolution <= 24u)/* 24-bit Timer */
        #define TOneSec_CAPTURE_LSB         (* (reg32 *) TOneSec_TimerUDB_sT8_timerdp_u0__F0_REG )
        #define TOneSec_CAPTURE_LSB_PTR       ((reg32 *) TOneSec_TimerUDB_sT8_timerdp_u0__F0_REG )
        #define TOneSec_PERIOD_LSB          (* (reg32 *) TOneSec_TimerUDB_sT8_timerdp_u0__D0_REG )
        #define TOneSec_PERIOD_LSB_PTR        ((reg32 *) TOneSec_TimerUDB_sT8_timerdp_u0__D0_REG )
        #define TOneSec_COUNTER_LSB         (* (reg32 *) TOneSec_TimerUDB_sT8_timerdp_u0__A0_REG )
        #define TOneSec_COUNTER_LSB_PTR       ((reg32 *) TOneSec_TimerUDB_sT8_timerdp_u0__A0_REG )
    #else /* 32-bit Timer */
        #if(CY_PSOC3 || CY_PSOC5) /* 8-bit address space */
            #define TOneSec_CAPTURE_LSB         (* (reg32 *) TOneSec_TimerUDB_sT8_timerdp_u0__F0_REG )
            #define TOneSec_CAPTURE_LSB_PTR       ((reg32 *) TOneSec_TimerUDB_sT8_timerdp_u0__F0_REG )
            #define TOneSec_PERIOD_LSB          (* (reg32 *) TOneSec_TimerUDB_sT8_timerdp_u0__D0_REG )
            #define TOneSec_PERIOD_LSB_PTR        ((reg32 *) TOneSec_TimerUDB_sT8_timerdp_u0__D0_REG )
            #define TOneSec_COUNTER_LSB         (* (reg32 *) TOneSec_TimerUDB_sT8_timerdp_u0__A0_REG )
            #define TOneSec_COUNTER_LSB_PTR       ((reg32 *) TOneSec_TimerUDB_sT8_timerdp_u0__A0_REG )
        #else /* 32-bit address space */
            #define TOneSec_CAPTURE_LSB         (* (reg32 *) TOneSec_TimerUDB_sT8_timerdp_u0__32BIT_F0_REG )
            #define TOneSec_CAPTURE_LSB_PTR       ((reg32 *) TOneSec_TimerUDB_sT8_timerdp_u0__32BIT_F0_REG )
            #define TOneSec_PERIOD_LSB          (* (reg32 *) TOneSec_TimerUDB_sT8_timerdp_u0__32BIT_D0_REG )
            #define TOneSec_PERIOD_LSB_PTR        ((reg32 *) TOneSec_TimerUDB_sT8_timerdp_u0__32BIT_D0_REG )
            #define TOneSec_COUNTER_LSB         (* (reg32 *) TOneSec_TimerUDB_sT8_timerdp_u0__32BIT_A0_REG )
            #define TOneSec_COUNTER_LSB_PTR       ((reg32 *) TOneSec_TimerUDB_sT8_timerdp_u0__32BIT_A0_REG )
        #endif /* CY_PSOC3 || CY_PSOC5 */ 
    #endif

    #define TOneSec_COUNTER_LSB_PTR_8BIT       ((reg8 *) TOneSec_TimerUDB_sT8_timerdp_u0__A0_REG )
    
    #if (TOneSec_UsingHWCaptureCounter)
        #define TOneSec_CAP_COUNT              (*(reg8 *) TOneSec_TimerUDB_sCapCount_counter__PERIOD_REG )
        #define TOneSec_CAP_COUNT_PTR          ( (reg8 *) TOneSec_TimerUDB_sCapCount_counter__PERIOD_REG )
        #define TOneSec_CAPTURE_COUNT_CTRL     (*(reg8 *) TOneSec_TimerUDB_sCapCount_counter__CONTROL_AUX_CTL_REG )
        #define TOneSec_CAPTURE_COUNT_CTRL_PTR ( (reg8 *) TOneSec_TimerUDB_sCapCount_counter__CONTROL_AUX_CTL_REG )
    #endif /* (TOneSec_UsingHWCaptureCounter) */


    /***************************************
    *       Register Constants
    ***************************************/

    /* Control Register Bit Locations */
    #define TOneSec_CTRL_INTCNT_SHIFT              0x00u       /* As defined by Verilog Implementation */
    #define TOneSec_CTRL_TRIG_MODE_SHIFT           0x02u       /* As defined by Verilog Implementation */
    #define TOneSec_CTRL_TRIG_EN_SHIFT             0x04u       /* As defined by Verilog Implementation */
    #define TOneSec_CTRL_CAP_MODE_SHIFT            0x05u       /* As defined by Verilog Implementation */
    #define TOneSec_CTRL_ENABLE_SHIFT              0x07u       /* As defined by Verilog Implementation */

    /* Control Register Bit Masks */
    #define TOneSec_CTRL_INTCNT_MASK               ((uint8)((uint8)0x03u << TOneSec_CTRL_INTCNT_SHIFT))
    #define TOneSec_CTRL_TRIG_MODE_MASK            ((uint8)((uint8)0x03u << TOneSec_CTRL_TRIG_MODE_SHIFT))
    #define TOneSec_CTRL_TRIG_EN                   ((uint8)((uint8)0x01u << TOneSec_CTRL_TRIG_EN_SHIFT))
    #define TOneSec_CTRL_CAP_MODE_MASK             ((uint8)((uint8)0x03u << TOneSec_CTRL_CAP_MODE_SHIFT))
    #define TOneSec_CTRL_ENABLE                    ((uint8)((uint8)0x01u << TOneSec_CTRL_ENABLE_SHIFT))

    /* Bit Counter (7-bit) Control Register Bit Definitions */
    /* As defined by the Register map for the AUX Control Register */
    #define TOneSec_CNTR_ENABLE                    0x20u

    /* Status Register Bit Locations */
    #define TOneSec_STATUS_TC_SHIFT                0x00u  /* As defined by Verilog Implementation */
    #define TOneSec_STATUS_CAPTURE_SHIFT           0x01u  /* As defined by Verilog Implementation */
    #define TOneSec_STATUS_TC_INT_MASK_SHIFT       TOneSec_STATUS_TC_SHIFT
    #define TOneSec_STATUS_CAPTURE_INT_MASK_SHIFT  TOneSec_STATUS_CAPTURE_SHIFT
    #define TOneSec_STATUS_FIFOFULL_SHIFT          0x02u  /* As defined by Verilog Implementation */
    #define TOneSec_STATUS_FIFONEMP_SHIFT          0x03u  /* As defined by Verilog Implementation */
    #define TOneSec_STATUS_FIFOFULL_INT_MASK_SHIFT TOneSec_STATUS_FIFOFULL_SHIFT

    /* Status Register Bit Masks */
    /* Sticky TC Event Bit-Mask */
    #define TOneSec_STATUS_TC                      ((uint8)((uint8)0x01u << TOneSec_STATUS_TC_SHIFT))
    /* Sticky Capture Event Bit-Mask */
    #define TOneSec_STATUS_CAPTURE                 ((uint8)((uint8)0x01u << TOneSec_STATUS_CAPTURE_SHIFT))
    /* Interrupt Enable Bit-Mask */
    #define TOneSec_STATUS_TC_INT_MASK             ((uint8)((uint8)0x01u << TOneSec_STATUS_TC_SHIFT))
    /* Interrupt Enable Bit-Mask */
    #define TOneSec_STATUS_CAPTURE_INT_MASK        ((uint8)((uint8)0x01u << TOneSec_STATUS_CAPTURE_SHIFT))
    /* NOT-Sticky FIFO Full Bit-Mask */
    #define TOneSec_STATUS_FIFOFULL                ((uint8)((uint8)0x01u << TOneSec_STATUS_FIFOFULL_SHIFT))
    /* NOT-Sticky FIFO Not Empty Bit-Mask */
    #define TOneSec_STATUS_FIFONEMP                ((uint8)((uint8)0x01u << TOneSec_STATUS_FIFONEMP_SHIFT))
    /* Interrupt Enable Bit-Mask */
    #define TOneSec_STATUS_FIFOFULL_INT_MASK       ((uint8)((uint8)0x01u << TOneSec_STATUS_FIFOFULL_SHIFT))

    #define TOneSec_STATUS_ACTL_INT_EN             0x10u   /* As defined for the ACTL Register */

    /* Datapath Auxillary Control Register definitions */
    #define TOneSec_AUX_CTRL_FIFO0_CLR             0x01u   /* As defined by Register map */
    #define TOneSec_AUX_CTRL_FIFO1_CLR             0x02u   /* As defined by Register map */
    #define TOneSec_AUX_CTRL_FIFO0_LVL             0x04u   /* As defined by Register map */
    #define TOneSec_AUX_CTRL_FIFO1_LVL             0x08u   /* As defined by Register map */
    #define TOneSec_STATUS_ACTL_INT_EN_MASK        0x10u   /* As defined for the ACTL Register */

#endif /* Implementation Specific Registers and Register Constants */

#endif  /* CY_TIMER_TOneSec_H */


/* [] END OF FILE */
