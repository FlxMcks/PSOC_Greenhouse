/*******************************************************************************
* File Name: POneWireTemperature.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_POneWireTemperature_H) /* Pins POneWireTemperature_H */
#define CY_PINS_POneWireTemperature_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "POneWireTemperature_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 POneWireTemperature__PORT == 15 && ((POneWireTemperature__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    POneWireTemperature_Write(uint8 value);
void    POneWireTemperature_SetDriveMode(uint8 mode);
uint8   POneWireTemperature_ReadDataReg(void);
uint8   POneWireTemperature_Read(void);
void    POneWireTemperature_SetInterruptMode(uint16 position, uint16 mode);
uint8   POneWireTemperature_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the POneWireTemperature_SetDriveMode() function.
     *  @{
     */
        #define POneWireTemperature_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define POneWireTemperature_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define POneWireTemperature_DM_RES_UP          PIN_DM_RES_UP
        #define POneWireTemperature_DM_RES_DWN         PIN_DM_RES_DWN
        #define POneWireTemperature_DM_OD_LO           PIN_DM_OD_LO
        #define POneWireTemperature_DM_OD_HI           PIN_DM_OD_HI
        #define POneWireTemperature_DM_STRONG          PIN_DM_STRONG
        #define POneWireTemperature_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define POneWireTemperature_MASK               POneWireTemperature__MASK
#define POneWireTemperature_SHIFT              POneWireTemperature__SHIFT
#define POneWireTemperature_WIDTH              1u

/* Interrupt constants */
#if defined(POneWireTemperature__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in POneWireTemperature_SetInterruptMode() function.
     *  @{
     */
        #define POneWireTemperature_INTR_NONE      (uint16)(0x0000u)
        #define POneWireTemperature_INTR_RISING    (uint16)(0x0001u)
        #define POneWireTemperature_INTR_FALLING   (uint16)(0x0002u)
        #define POneWireTemperature_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define POneWireTemperature_INTR_MASK      (0x01u) 
#endif /* (POneWireTemperature__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define POneWireTemperature_PS                     (* (reg8 *) POneWireTemperature__PS)
/* Data Register */
#define POneWireTemperature_DR                     (* (reg8 *) POneWireTemperature__DR)
/* Port Number */
#define POneWireTemperature_PRT_NUM                (* (reg8 *) POneWireTemperature__PRT) 
/* Connect to Analog Globals */                                                  
#define POneWireTemperature_AG                     (* (reg8 *) POneWireTemperature__AG)                       
/* Analog MUX bux enable */
#define POneWireTemperature_AMUX                   (* (reg8 *) POneWireTemperature__AMUX) 
/* Bidirectional Enable */                                                        
#define POneWireTemperature_BIE                    (* (reg8 *) POneWireTemperature__BIE)
/* Bit-mask for Aliased Register Access */
#define POneWireTemperature_BIT_MASK               (* (reg8 *) POneWireTemperature__BIT_MASK)
/* Bypass Enable */
#define POneWireTemperature_BYP                    (* (reg8 *) POneWireTemperature__BYP)
/* Port wide control signals */                                                   
#define POneWireTemperature_CTL                    (* (reg8 *) POneWireTemperature__CTL)
/* Drive Modes */
#define POneWireTemperature_DM0                    (* (reg8 *) POneWireTemperature__DM0) 
#define POneWireTemperature_DM1                    (* (reg8 *) POneWireTemperature__DM1)
#define POneWireTemperature_DM2                    (* (reg8 *) POneWireTemperature__DM2) 
/* Input Buffer Disable Override */
#define POneWireTemperature_INP_DIS                (* (reg8 *) POneWireTemperature__INP_DIS)
/* LCD Common or Segment Drive */
#define POneWireTemperature_LCD_COM_SEG            (* (reg8 *) POneWireTemperature__LCD_COM_SEG)
/* Enable Segment LCD */
#define POneWireTemperature_LCD_EN                 (* (reg8 *) POneWireTemperature__LCD_EN)
/* Slew Rate Control */
#define POneWireTemperature_SLW                    (* (reg8 *) POneWireTemperature__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define POneWireTemperature_PRTDSI__CAPS_SEL       (* (reg8 *) POneWireTemperature__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define POneWireTemperature_PRTDSI__DBL_SYNC_IN    (* (reg8 *) POneWireTemperature__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define POneWireTemperature_PRTDSI__OE_SEL0        (* (reg8 *) POneWireTemperature__PRTDSI__OE_SEL0) 
#define POneWireTemperature_PRTDSI__OE_SEL1        (* (reg8 *) POneWireTemperature__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define POneWireTemperature_PRTDSI__OUT_SEL0       (* (reg8 *) POneWireTemperature__PRTDSI__OUT_SEL0) 
#define POneWireTemperature_PRTDSI__OUT_SEL1       (* (reg8 *) POneWireTemperature__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define POneWireTemperature_PRTDSI__SYNC_OUT       (* (reg8 *) POneWireTemperature__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(POneWireTemperature__SIO_CFG)
    #define POneWireTemperature_SIO_HYST_EN        (* (reg8 *) POneWireTemperature__SIO_HYST_EN)
    #define POneWireTemperature_SIO_REG_HIFREQ     (* (reg8 *) POneWireTemperature__SIO_REG_HIFREQ)
    #define POneWireTemperature_SIO_CFG            (* (reg8 *) POneWireTemperature__SIO_CFG)
    #define POneWireTemperature_SIO_DIFF           (* (reg8 *) POneWireTemperature__SIO_DIFF)
#endif /* (POneWireTemperature__SIO_CFG) */

/* Interrupt Registers */
#if defined(POneWireTemperature__INTSTAT)
    #define POneWireTemperature_INTSTAT            (* (reg8 *) POneWireTemperature__INTSTAT)
    #define POneWireTemperature_SNAP               (* (reg8 *) POneWireTemperature__SNAP)
    
	#define POneWireTemperature_0_INTTYPE_REG 		(* (reg8 *) POneWireTemperature__0__INTTYPE)
#endif /* (POneWireTemperature__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_POneWireTemperature_H */


/* [] END OF FILE */
