/*******************************************************************************
* File Name: CSSoilMoisture_CSHL.h
* Version 3.50
*
* Description:
*  This file provides constants and parameter values for the High Level APIs
*  for CapSense CSD component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CAPSENSE_CSD_CSHL_CSSoilMoisture_H)
#define CY_CAPSENSE_CSD_CSHL_CSSoilMoisture_H

#include "CSSoilMoisture.h"


/***************************************
*   Condition compilation parameters
***************************************/

#define CSSoilMoisture_SIGNAL_SIZE                (8u)
#define CSSoilMoisture_AUTO_RESET                 (0u)
#define CSSoilMoisture_RAW_FILTER_MASK            (8u)

/* Signal size definition */
#define CSSoilMoisture_SIGNAL_SIZE_UINT8          (8u)
#define CSSoilMoisture_SIGNAL_SIZE_UINT16         (16u)

/* Auto reset definition */
#define CSSoilMoisture_AUTO_RESET_DISABLE         (0u)
#define CSSoilMoisture_AUTO_RESET_ENABLE          (1u)

/* Mask for RAW and POS filters */
#define CSSoilMoisture_MEDIAN_FILTER              (0x01u)
#define CSSoilMoisture_AVERAGING_FILTER           (0x02u)
#define CSSoilMoisture_IIR2_FILTER                (0x04u)
#define CSSoilMoisture_IIR4_FILTER                (0x08u)
#define CSSoilMoisture_JITTER_FILTER              (0x10u)
#define CSSoilMoisture_IIR8_FILTER                (0x20u)
#define CSSoilMoisture_IIR16_FILTER               (0x40u)


/***************************************
*           API Constants
***************************************/

/* Widgets constants definition */
#define CSSoilMoisture_DUMMYWIDGET__BTN        (0u)

#define CSSoilMoisture_TOTAL_DIPLEXED_SLIDERS_COUNT        (0u)
#define CSSoilMoisture_TOTAL_LINEAR_SLIDERS_COUNT          (0u)
#define CSSoilMoisture_TOTAL_RADIAL_SLIDERS_COUNT          (0u)
#define CSSoilMoisture_TOTAL_TOUCH_PADS_COUNT              (0u)
#define CSSoilMoisture_TOTAL_BUTTONS_COUNT                 (1u)
#define CSSoilMoisture_TOTAL_MATRIX_BUTTONS_COUNT          (0u)
#define CSSoilMoisture_TOTAL_GENERICS_COUNT                (0u)

#define CSSoilMoisture_POS_FILTERS_MASK        (0u)
#define CSSoilMoisture_LINEAR_SLIDERS_POS_FILTERS_MASK        (0u)
#define CSSoilMoisture_RADIAL_SLIDERS_POS_FILTERS_MASK        (0u)
#define CSSoilMoisture_TOUCH_PADS_POS_FILTERS_MASK        (0u)

#define CSSoilMoisture_UNUSED_DEBOUNCE_COUNTER_INDEX   (1u)


#define CSSoilMoisture_END_OF_SLIDERS_INDEX   (0u)
#define CSSoilMoisture_END_OF_TOUCH_PAD_INDEX   (0u)
#define CSSoilMoisture_END_OF_BUTTONS_INDEX   (0u)
#define CSSoilMoisture_END_OF_MATRIX_BUTTONS_INDEX   (0u)
#define CSSoilMoisture_END_OF_WIDGETS_INDEX   (1u)


#define CSSoilMoisture_TOTAL_SLIDERS_COUNT            ( CSSoilMoisture_TOTAL_LINEAR_SLIDERS_COUNT + \
                                                          CSSoilMoisture_TOTAL_RADIAL_SLIDERS_COUNT )
                                                          
#define CSSoilMoisture_TOTAL_CENTROIDS_COUNT          ( CSSoilMoisture_TOTAL_SLIDERS_COUNT + \
                                                         (CSSoilMoisture_TOTAL_TOUCH_PADS_COUNT*2u) )

#define CSSoilMoisture_TOTAL_WIDGET_COUNT             ( CSSoilMoisture_TOTAL_LINEAR_SLIDERS_COUNT + \
                                                          CSSoilMoisture_TOTAL_RADIAL_SLIDERS_COUNT + \
                                                          CSSoilMoisture_TOTAL_TOUCH_PADS_COUNT + \
                                                          CSSoilMoisture_TOTAL_BUTTONS_COUNT + \
                                                          CSSoilMoisture_TOTAL_MATRIX_BUTTONS_COUNT )
                                                           
#define CSSoilMoisture_ANY_POS_FILTER                 ( CSSoilMoisture_MEDIAN_FILTER | \
                                                          CSSoilMoisture_AVERAGING_FILTER | \
                                                          CSSoilMoisture_IIR2_FILTER | \
                                                          CSSoilMoisture_IIR4_FILTER | \
                                                          CSSoilMoisture_JITTER_FILTER )
                                                         
#define CSSoilMoisture_IS_DIPLEX_SLIDER               ( CSSoilMoisture_TOTAL_DIPLEXED_SLIDERS_COUNT > 0u)

#define CSSoilMoisture_IS_NON_DIPLEX_SLIDER           ( (CSSoilMoisture_TOTAL_LINEAR_SLIDERS_COUNT - \
                                                           CSSoilMoisture_TOTAL_DIPLEXED_SLIDERS_COUNT) > 0u)
#define CSSoilMoisture_ADD_SLIDER_TYPE                ((CSSoilMoisture_TOTAL_RADIAL_SLIDERS_COUNT > 0u) ? \
                                                        ((CSSoilMoisture_TOTAL_TOUCH_PADS_COUNT > 0u) || \
                                                         (CSSoilMoisture_TOTAL_LINEAR_SLIDERS_COUNT > 0u)) : 0u)
                                                         
#define CSSoilMoisture_WIDGET_CSHL_PARAMETERS_COUNT           (CSSoilMoisture_TOTAL_WIDGET_COUNT + \
                                                                 CSSoilMoisture_TOTAL_TOUCH_PADS_COUNT + \
                                                                 CSSoilMoisture_TOTAL_MATRIX_BUTTONS_COUNT)

#define CSSoilMoisture_WIDGET_RESOLUTION_PARAMETERS_COUNT     (CSSoilMoisture_WIDGET_CSHL_PARAMETERS_COUNT + \
                                                                 CSSoilMoisture_TOTAL_GENERICS_COUNT)
                                                                 
#define CSSoilMoisture_SENSORS_TBL_SIZE (CSSoilMoisture_TOTAL_LINEAR_SLIDERS_COUNT + \
                                        CSSoilMoisture_TOTAL_RADIAL_SLIDERS_COUNT + \
                                        CSSoilMoisture_TOTAL_BUTTONS_COUNT + \
                                        CSSoilMoisture_TOTAL_GENERICS_COUNT + \
                                        (CSSoilMoisture_TOTAL_TOUCH_PADS_COUNT * 2u) + \
                                        (CSSoilMoisture_TOTAL_MATRIX_BUTTONS_COUNT * 2u))
                                        
/*Types of centroids */
#define CSSoilMoisture_TYPE_RADIAL_SLIDER         (0x01u)
#define CSSoilMoisture_TYPE_LINEAR_SLIDER         (0x02u)
#define CSSoilMoisture_TYPE_GENERIC               (0xFFu)

/* Defines is slot active */
#define CSSoilMoisture_SENSOR_1_IS_ACTIVE     (0x01u)
#define CSSoilMoisture_SENSOR_2_IS_ACTIVE     (0x02u)
#define CSSoilMoisture_WIDGET_IS_ACTIVE       (0x01u)

/* Defines diplex type of Slider */
#define CSSoilMoisture_IS_DIPLEX              (0x80u)

/* Defines max fingers on TouchPad  */
#define CSSoilMoisture_POS_PREV               (0u)
#define CSSoilMoisture_POS                    (1u)
#define CSSoilMoisture_POS_NEXT               (2u)
#define CSSoilMoisture_CENTROID_ROUND_VALUE   (0x7F00u)

#define CSSoilMoisture_NEGATIVE_NOISE_THRESHOLD        (20u)
#define CSSoilMoisture_LOW_BASELINE_RESET              (5u)


/***************************************
*        Function Prototypes
***************************************/
void CSSoilMoisture_BaseInit(uint8 sensor) ;
void CSSoilMoisture_InitializeSensorBaseline(uint8 sensor) \
                                               ;
void CSSoilMoisture_InitializeAllBaselines(void) ;
void CSSoilMoisture_InitializeEnabledBaselines(void) \
                                                 ;
void CSSoilMoisture_UpdateSensorBaseline(uint8 sensor) ;
void CSSoilMoisture_UpdateEnabledBaselines(void) ;
uint8 CSSoilMoisture_CheckIsSensorActive(uint8 sensor) ;
uint8 CSSoilMoisture_CheckIsWidgetActive(uint8 widget) ;
uint8 CSSoilMoisture_CheckIsAnyWidgetActive(void) ;
void CSSoilMoisture_EnableWidget(uint8 widget) ;
void CSSoilMoisture_DisableWidget(uint8 widget) ;
#if (CSSoilMoisture_TOTAL_MATRIX_BUTTONS_COUNT)
    uint8 CSSoilMoisture_GetMatrixButtonPos(uint8 widget, uint8* pos) \
	                                          ;
#endif /* (CSSoilMoisture_TOTAL_MATRIX_BUTTONS_COUNT) */

#if (CSSoilMoisture_TOTAL_LINEAR_SLIDERS_COUNT)
    uint16 CSSoilMoisture_GetCentroidPos(uint8 widget) ;
#endif /* (CSSoilMoisture_TOTAL_LINEAR_SLIDERS_COUNT) */
#if (CSSoilMoisture_TOTAL_RADIAL_SLIDERS_COUNT)
    uint16 CSSoilMoisture_GetRadialCentroidPos(uint8 widget) \
                                                 ;
#endif /* (CSSoilMoisture_TOTAL_RADIAL_SLIDERS_COUNT) */
#if (CSSoilMoisture_TOTAL_TOUCH_PADS_COUNT)
    uint8 CSSoilMoisture_GetTouchCentroidPos(uint8 widget, uint16* pos) \
	                                           ;
#endif /* (CSSoilMoisture_TOTAL_TOUCH_PADS_COUNT) */

#if (CSSoilMoisture_IS_DIPLEX_SLIDER)
    uint8 CSSoilMoisture_FindMaximum(uint8 offset, uint8 count, uint8 fingerThreshold, const uint8 CYCODE *diplex)
                                       ;
#else 
    uint8 CSSoilMoisture_FindMaximum(uint8 offset, uint8 count, uint8 fingerThreshold)
                                       ;
#endif /* (CSSoilMoisture_IS_DIPLEX_SLIDER) */

#if(CSSoilMoisture_TOTAL_CENTROIDS_COUNT)
    uint8 CSSoilMoisture_CalcCentroid(uint8 maximum, uint8 offset, 
                                        uint8 count, uint16 resolution, uint8 noiseThreshold)
	                                    ;
#endif /* (CSSoilMoisture_TOTAL_CENTROIDS_COUNT) */

/* SmartSense functions */
#if (CSSoilMoisture_TUNING_METHOD == CSSoilMoisture_AUTO_TUNING)
    extern void CSSoilMoisture_CalculateThresholds(uint8 SensorNumber)
           ;
#endif /* (CSSoilMoisture_TUNING_METHOD == CSSoilMoisture_AUTO_TUNING) */

/* Median filter function prototype */
#if ( (CSSoilMoisture_RAW_FILTER_MASK & CSSoilMoisture_MEDIAN_FILTER) | \
      (CSSoilMoisture_POS_FILTERS_MASK & CSSoilMoisture_MEDIAN_FILTER) )
    uint16 CSSoilMoisture_MedianFilter(uint16 x1, uint16 x2, uint16 x3)
    ;
#endif /* CSSoilMoisture_RAW_FILTER_MASK && CSSoilMoisture_POS_FILTERS_MASK */

/* Averaging filter function prototype */
#if ( (CSSoilMoisture_RAW_FILTER_MASK & CSSoilMoisture_AVERAGING_FILTER) | \
      (CSSoilMoisture_POS_FILTERS_MASK & CSSoilMoisture_AVERAGING_FILTER) )
    uint16 CSSoilMoisture_AveragingFilter(uint16 x1, uint16 x2, uint16 x3)
    ;
#endif /* CSSoilMoisture_RAW_FILTER_MASK && CSSoilMoisture_POS_FILTERS_MASK */

/* IIR2Filter(1/2prev + 1/2cur) filter function prototype */
#if ( (CSSoilMoisture_RAW_FILTER_MASK & CSSoilMoisture_IIR2_FILTER) | \
      (CSSoilMoisture_POS_FILTERS_MASK & CSSoilMoisture_IIR2_FILTER) )
    uint16 CSSoilMoisture_IIR2Filter(uint16 x1, uint16 x2) ;
#endif /* CSSoilMoisture_RAW_FILTER_MASK && CSSoilMoisture_POS_FILTERS_MASK */

/* IIR4Filter(3/4prev + 1/4cur) filter function prototype */
#if ( (CSSoilMoisture_RAW_FILTER_MASK & CSSoilMoisture_IIR4_FILTER) | \
      (CSSoilMoisture_POS_FILTERS_MASK & CSSoilMoisture_IIR4_FILTER) )
    uint16 CSSoilMoisture_IIR4Filter(uint16 x1, uint16 x2) ;
#endif /* CSSoilMoisture_RAW_FILTER_MASK && CSSoilMoisture_POS_FILTERS_MASK */

/* IIR8Filter(7/8prev + 1/8cur) filter function prototype - RawCounts only */
#if (CSSoilMoisture_RAW_FILTER_MASK & CSSoilMoisture_IIR8_FILTER)
    uint16 CSSoilMoisture_IIR8Filter(uint16 x1, uint16 x2) ;
#endif /* CSSoilMoisture_RAW_FILTER_MASK */

/* IIR16Filter(15/16prev + 1/16cur) filter function prototype - RawCounts only */
#if (CSSoilMoisture_RAW_FILTER_MASK & CSSoilMoisture_IIR16_FILTER)
    uint16 CSSoilMoisture_IIR16Filter(uint16 x1, uint16 x2) ;
#endif /* CSSoilMoisture_RAW_FILTER_MASK */

/* JitterFilter filter function prototype */
#if ( (CSSoilMoisture_RAW_FILTER_MASK & CSSoilMoisture_JITTER_FILTER) | \
      (CSSoilMoisture_POS_FILTERS_MASK & CSSoilMoisture_JITTER_FILTER) )
    uint16 CSSoilMoisture_JitterFilter(uint16 x1, uint16 x2) ;
#endif /* CSSoilMoisture_RAW_FILTER_MASK && CSSoilMoisture_POS_FILTERS_MASK */

/* Storage of filters data */
#if ( (CSSoilMoisture_RAW_FILTER_MASK & CSSoilMoisture_MEDIAN_FILTER) | \
      (CSSoilMoisture_RAW_FILTER_MASK & CSSoilMoisture_AVERAGING_FILTER) )

    extern uint16 CSSoilMoisture_rawFilterData1[CSSoilMoisture_TOTAL_SENSOR_COUNT];
    extern uint16 CSSoilMoisture_rawFilterData2[CSSoilMoisture_TOTAL_SENSOR_COUNT];

#elif ( (CSSoilMoisture_RAW_FILTER_MASK & CSSoilMoisture_IIR2_FILTER)   | \
        (CSSoilMoisture_RAW_FILTER_MASK & CSSoilMoisture_IIR4_FILTER)   | \
        (CSSoilMoisture_RAW_FILTER_MASK & CSSoilMoisture_JITTER_FILTER) | \
        (CSSoilMoisture_RAW_FILTER_MASK & CSSoilMoisture_IIR8_FILTER)   | \
        (CSSoilMoisture_RAW_FILTER_MASK & CSSoilMoisture_IIR16_FILTER) )
        
    extern uint16 CSSoilMoisture_rawFilterData1[CSSoilMoisture_TOTAL_SENSOR_COUNT];

#else
    /* No Raw filters */
#endif  /* ( (CSSoilMoisture_RAW_FILTER_MASK & CSSoilMoisture_MEDIAN_FILTER) || \
        *    (CSSoilMoisture_RAW_FILTER_MASK & CSSoilMoisture_AVERAGING_FILTER) )
        */

extern uint8 CSSoilMoisture_sensorEnableMask[(((CSSoilMoisture_TOTAL_SENSOR_COUNT - 1u) / 8u) + 1u)];
extern const uint8 CYCODE CSSoilMoisture_widgetNumber[CSSoilMoisture_TOTAL_SENSOR_COUNT];

extern uint16 CSSoilMoisture_sensorBaseline[CSSoilMoisture_TOTAL_SENSOR_COUNT];
extern uint8 CSSoilMoisture_sensorBaselineLow[CSSoilMoisture_TOTAL_SENSOR_COUNT];
extern uint8 CSSoilMoisture_sensorSignal[CSSoilMoisture_TOTAL_SENSOR_COUNT];
extern uint8 CSSoilMoisture_sensorOnMask[(((CSSoilMoisture_TOTAL_SENSOR_COUNT - 1u) / 8u) + 1u)];

extern uint8 CSSoilMoisture_lowBaselineResetCnt[CSSoilMoisture_TOTAL_SENSOR_COUNT];

/****************************************************************************************
*       Obsolete definitions. Not recommended to use. Will be removed in future releases.
*****************************************************************************************/

/* Obsolete names of variables */
//#define CSSoilMoisture_SensorBaseline          CSSoilMoisture_sensorBaseline
//#define CSSoilMoisture_SensorBaselineLow       CSSoilMoisture_sensorBaselineLow
//#define CSSoilMoisture_SensorSignal            CSSoilMoisture_sensorSignal
//#define CSSoilMoisture_SensorOnMask            CSSoilMoisture_sensorOnMask
//#define CSSoilMoisture_LowBaselineResetCnt     CSSoilMoisture_lowBaselineResetCnt


#endif /* CY_CAPSENSE_CSD_CSHL_CSSoilMoisture_H */

/* [] END OF FILE */
