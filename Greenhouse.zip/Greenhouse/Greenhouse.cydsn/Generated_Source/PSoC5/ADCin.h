/*******************************************************************************
* File Name: ADCin.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_ADCin_H) /* Pins ADCin_H */
#define CY_PINS_ADCin_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "ADCin_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 ADCin__PORT == 15 && ((ADCin__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    ADCin_Write(uint8 value);
void    ADCin_SetDriveMode(uint8 mode);
uint8   ADCin_ReadDataReg(void);
uint8   ADCin_Read(void);
void    ADCin_SetInterruptMode(uint16 position, uint16 mode);
uint8   ADCin_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the ADCin_SetDriveMode() function.
     *  @{
     */
        #define ADCin_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define ADCin_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define ADCin_DM_RES_UP          PIN_DM_RES_UP
        #define ADCin_DM_RES_DWN         PIN_DM_RES_DWN
        #define ADCin_DM_OD_LO           PIN_DM_OD_LO
        #define ADCin_DM_OD_HI           PIN_DM_OD_HI
        #define ADCin_DM_STRONG          PIN_DM_STRONG
        #define ADCin_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define ADCin_MASK               ADCin__MASK
#define ADCin_SHIFT              ADCin__SHIFT
#define ADCin_WIDTH              1u

/* Interrupt constants */
#if defined(ADCin__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in ADCin_SetInterruptMode() function.
     *  @{
     */
        #define ADCin_INTR_NONE      (uint16)(0x0000u)
        #define ADCin_INTR_RISING    (uint16)(0x0001u)
        #define ADCin_INTR_FALLING   (uint16)(0x0002u)
        #define ADCin_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define ADCin_INTR_MASK      (0x01u) 
#endif /* (ADCin__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define ADCin_PS                     (* (reg8 *) ADCin__PS)
/* Data Register */
#define ADCin_DR                     (* (reg8 *) ADCin__DR)
/* Port Number */
#define ADCin_PRT_NUM                (* (reg8 *) ADCin__PRT) 
/* Connect to Analog Globals */                                                  
#define ADCin_AG                     (* (reg8 *) ADCin__AG)                       
/* Analog MUX bux enable */
#define ADCin_AMUX                   (* (reg8 *) ADCin__AMUX) 
/* Bidirectional Enable */                                                        
#define ADCin_BIE                    (* (reg8 *) ADCin__BIE)
/* Bit-mask for Aliased Register Access */
#define ADCin_BIT_MASK               (* (reg8 *) ADCin__BIT_MASK)
/* Bypass Enable */
#define ADCin_BYP                    (* (reg8 *) ADCin__BYP)
/* Port wide control signals */                                                   
#define ADCin_CTL                    (* (reg8 *) ADCin__CTL)
/* Drive Modes */
#define ADCin_DM0                    (* (reg8 *) ADCin__DM0) 
#define ADCin_DM1                    (* (reg8 *) ADCin__DM1)
#define ADCin_DM2                    (* (reg8 *) ADCin__DM2) 
/* Input Buffer Disable Override */
#define ADCin_INP_DIS                (* (reg8 *) ADCin__INP_DIS)
/* LCD Common or Segment Drive */
#define ADCin_LCD_COM_SEG            (* (reg8 *) ADCin__LCD_COM_SEG)
/* Enable Segment LCD */
#define ADCin_LCD_EN                 (* (reg8 *) ADCin__LCD_EN)
/* Slew Rate Control */
#define ADCin_SLW                    (* (reg8 *) ADCin__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define ADCin_PRTDSI__CAPS_SEL       (* (reg8 *) ADCin__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define ADCin_PRTDSI__DBL_SYNC_IN    (* (reg8 *) ADCin__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define ADCin_PRTDSI__OE_SEL0        (* (reg8 *) ADCin__PRTDSI__OE_SEL0) 
#define ADCin_PRTDSI__OE_SEL1        (* (reg8 *) ADCin__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define ADCin_PRTDSI__OUT_SEL0       (* (reg8 *) ADCin__PRTDSI__OUT_SEL0) 
#define ADCin_PRTDSI__OUT_SEL1       (* (reg8 *) ADCin__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define ADCin_PRTDSI__SYNC_OUT       (* (reg8 *) ADCin__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(ADCin__SIO_CFG)
    #define ADCin_SIO_HYST_EN        (* (reg8 *) ADCin__SIO_HYST_EN)
    #define ADCin_SIO_REG_HIFREQ     (* (reg8 *) ADCin__SIO_REG_HIFREQ)
    #define ADCin_SIO_CFG            (* (reg8 *) ADCin__SIO_CFG)
    #define ADCin_SIO_DIFF           (* (reg8 *) ADCin__SIO_DIFF)
#endif /* (ADCin__SIO_CFG) */

/* Interrupt Registers */
#if defined(ADCin__INTSTAT)
    #define ADCin_INTSTAT            (* (reg8 *) ADCin__INTSTAT)
    #define ADCin_SNAP               (* (reg8 *) ADCin__SNAP)
    
	#define ADCin_0_INTTYPE_REG 		(* (reg8 *) ADCin__0__INTTYPE)
#endif /* (ADCin__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_ADCin_H */


/* [] END OF FILE */
