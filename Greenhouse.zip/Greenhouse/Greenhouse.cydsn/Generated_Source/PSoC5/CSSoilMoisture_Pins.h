/*******************************************************************************
* File Name: CSSoilMoisture_Pins.h
* Version 3.50
*
* Description:
*  This file contains API to enable firmware control of a Pins component.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2008-2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CAPSENSE_CSD_Pins_CSSoilMoisture_H)
#define CY_CAPSENSE_CSD_Pins_CSSoilMoisture_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "CSSoilMoisture.h"


/***************************************
*        Function Prototypes
***************************************/

void CSSoilMoisture_SetAllSensorsDriveMode(uint8 mode) ;
void CSSoilMoisture_SetAllCmodsDriveMode(uint8 mode) ;
#if (CSSoilMoisture_CURRENT_SOURCE == CSSoilMoisture_EXTERNAL_RB)
    void CSSoilMoisture_SetAllRbsDriveMode(uint8 mode) ;    
#endif  /* (CSSoilMoisture_CURRENT_SOURCE == CSSoilMoisture_EXTERNAL_RB) */   


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define CSSoilMoisture_DM_ALG_HIZ         (PIN_DM_ALG_HIZ)
#define CSSoilMoisture_DM_DIG_HIZ         (PIN_DM_DIG_HIZ)
#define CSSoilMoisture_DM_RES_UP          (PIN_DM_RES_UP)
#define CSSoilMoisture_DM_RES_DWN         (PIN_DM_RES_DWN)
#define CSSoilMoisture_DM_OD_LO           (PIN_DM_OD_LO)
#define CSSoilMoisture_DM_OD_HI           (PIN_DM_OD_HI)
#define CSSoilMoisture_DM_STRONG          (PIN_DM_STRONG)
#define CSSoilMoisture_DM_RES_UPDWN       (PIN_DM_RES_UPDWN)

/* PC registers defines for sensors */
#define CSSoilMoisture_PortCH0__Generic0_0__GEN  CSSoilMoisture_PortCH0__Generic0_0__GEN__PC
/* For Cmods*/
#define CSSoilMoisture_CmodCH0_Cmod_CH0       CSSoilMoisture_CmodCH0__Cmod_CH0__PC


#endif /* (CY_CAPSENSE_CSD_Pins_CSSoilMoisture_H) */


/* [] END OF FILE */
