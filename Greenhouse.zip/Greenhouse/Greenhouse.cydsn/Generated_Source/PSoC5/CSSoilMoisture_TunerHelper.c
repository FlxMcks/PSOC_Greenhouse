/*******************************************************************************
* File Name: CSSoilMoisture_TunerHelper.c
* Version 3.50
*
* Description:
*  This file provides the source code of Tuner helper APIs for the CapSense CSD 
*  component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "CSSoilMoisture_TunerHelper.h"

#if (CSSoilMoisture_TUNER_API_GENERATE)
    volatile CSSoilMoisture_MAILBOXES CSSoilMoisture_mailboxesComm;
#endif  /* (CSSoilMoisture_TUNER_API_GENERATE) */


/*******************************************************************************
* Function Name: CSSoilMoisture_TunerStart
********************************************************************************
*
* Summary:
*  Initializes CapSense CSD component and EzI2C communication componenet to use
*  mailbox data structure for communication with Tuner GUI.
*  Start the scanning, after initialization complete.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Reentrant:
*  No
*
* Note:
*  All widgets are enabled by default except proximity widgets. Proximity widgets 
*  must be manually enabled as their long scan time is incompatible 
*  with the fast response required of other widget types. 
*
*******************************************************************************/
void CSSoilMoisture_TunerStart(void) 
{
    #if (CSSoilMoisture_TUNER_API_GENERATE)
        
        /* Init mbx and quick check */
        CSSoilMoisture_InitMailbox(&CSSoilMoisture_mailboxesComm.csdMailbox);
        CSSoilMoisture_mailboxesComm.numMailBoxes = CSSoilMoisture_DEFAULT_MAILBOXES_NUMBER;
        
        /* Start CapSense and baselines */
        CSSoilMoisture_Start();
        
        /* Initialize baselines */ 
        CSSoilMoisture_InitializeAllBaselines();
        CSSoilMoisture_InitializeAllBaselines();
        
        /* Start EzI2C, clears buf pointers */
        EZI2C_Start();
        
        /* Setup EzI2C buffers */
        EZI2C_SetBuffer1(sizeof(CSSoilMoisture_mailboxesComm), sizeof(CSSoilMoisture_mailboxesComm),
                                        (void *) &CSSoilMoisture_mailboxesComm);
        
        /* Starts scan all enabled sensors */
        CSSoilMoisture_ScanEnabledWidgets();
    
    #endif  /* (CSSoilMoisture_TUNER_API_GENERATE) */
}


/*******************************************************************************
* Function Name: CSSoilMoisture_TunerComm
********************************************************************************
*
* Summary:
*  This function is blocking. It waits till scaning loop is completed and apply
*  new parameters from Tuner GUI if available (manual tuning mode only). Updates
*  enabled baselines and state of widgets. Waits while Tuner GUI reports that 
*  content of mailbox could be modified. Then loads the report data into outbox 
*  and sets the busy flag. Starts new scanning loop.
*  
* Parameters:
*  None
*
* Return:
*  None
*
* Reentrant:
*  No
*
*******************************************************************************/
void CSSoilMoisture_TunerComm(void) 
{
    #if (CSSoilMoisture_TUNER_API_GENERATE)
        if (0u == CSSoilMoisture_IsBusy())
        {   
            /* Apply new settings */
            #if (CSSoilMoisture_TUNING_METHOD == CSSoilMoisture_MANUAL_TUNING)
                CSSoilMoisture_ReadMessage(&CSSoilMoisture_mailboxesComm.csdMailbox);
            #endif  /* (CSSoilMoisture_TUNING_METHOD == CSSoilMoisture_MANUAL_TUNING) */

            /* Update all baselines and process all widgets */
            CSSoilMoisture_UpdateEnabledBaselines();
            CSSoilMoisture_ProcessAllWidgets(&CSSoilMoisture_mailboxesComm.csdMailbox.outbox);
            CSSoilMoisture_PostMessage(&CSSoilMoisture_mailboxesComm.csdMailbox);

            /* Enable EZI2C interrupts, after scan complete */
            EZI2C_EnableInt();

            while((CSSoilMoisture_mailboxesComm.csdMailbox.type != CSSoilMoisture_TYPE_ID) || \
                  ((EZI2C_GetActivity() & EZI2C_STATUS_BUSY) != 0u)){}
            
            /* Disable EZI2C interrupts, while scanning */
            EZI2C_DisableInt();
            
            /* Start scan all sensors */
            CSSoilMoisture_ScanEnabledWidgets();
        }
    #endif /* (CSSoilMoisture_TUNER_API_GENERATE) */
}


#if (CSSoilMoisture_TUNER_API_GENERATE)
    /*******************************************************************************
    * Function Name: CSSoilMoisture_ProcessAllWidgets
    ********************************************************************************
    *
    * Summary:
    *  Call required functions to update all widgets state:
    *   - CSSoilMoisture_GetCentroidPos() - calls only if linear sliders 
    *     available.
    *   - CSSoilMoisture_GetRadialCentroidPos() - calls only if radial slider 
    *     available.
    *   - CSSoilMoisture_GetTouchCentroidPos() - calls only if touch pad slider 
    *     available.
    *   - CSSoilMoisture_CheckIsAnyWidgetActive();
    *  The results of opeartions are copied to OUTBOX.
    *   
    * Parameters:
    *  None
    *
    * Return:
    *  None
    *
    * Global Variables:
    *  CSSoilMoisture_OUTBOX outbox - structure which is used as ouput 
    *  buffer for report data to Tuner GUI.
    *  Update fields:
    *    - position[];
    *    - OnMask[];
    *
    * Reentrant:
    *  No
    *
    *******************************************************************************/
    void CSSoilMoisture_ProcessAllWidgets(volatile CSSoilMoisture_OUTBOX *outbox)
	                                        
    {
        uint8 i = 0u;
		#if (CSSoilMoisture_TOTAL_MATRIX_BUTTONS_COUNT)
        	volatile uint8 *mbPositionAddr;
		#endif /* (CSSoilMoisture_TOTAL_MATRIX_BUTTONS_COUNT) */

        #if (CSSoilMoisture_TOTAL_TOUCH_PADS_COUNT)
            uint16 pos[2];
        #endif  /* (CSSoilMoisture_TOTAL_TOUCH_PADS_COUNT) */
        
        #if ( (CSSoilMoisture_TOTAL_RADIAL_SLIDERS_COUNT) || (CSSoilMoisture_TOTAL_TOUCH_PADS_COUNT) || \
              (CSSoilMoisture_TOTAL_MATRIX_BUTTONS_COUNT) )
            uint8 widgetCnt;
        #endif  /* ((CSSoilMoisture_TOTAL_RADIAL_SLIDERS_COUNT) || (CSSoilMoisture_TOTAL_TOUCH_PADS_COUNT)) || 
                *   (CSSoilMoisture_TOTAL_MATRIX_BUTTONS_COUNT)
                */
        
        /* Calculate widget with centroids */
        #if (CSSoilMoisture_TOTAL_LINEAR_SLIDERS_COUNT)
            for(; i < CSSoilMoisture_TOTAL_LINEAR_SLIDERS_COUNT; i++)
            {
                outbox->position[i] = CSSoilMoisture_SWAP_ENDIAN16(CSSoilMoisture_GetCentroidPos(i));
            }
        #endif /* (CSSoilMoisture_TOTAL_LINEAR_SLIDERS_COUNT) */
        
        #if (CSSoilMoisture_TOTAL_RADIAL_SLIDERS_COUNT)
            widgetCnt = i;
            for(; i < (widgetCnt + CSSoilMoisture_TOTAL_RADIAL_SLIDERS_COUNT); i++)
            {
                outbox->position[i] = CSSoilMoisture_SWAP_ENDIAN16(CSSoilMoisture_GetRadialCentroidPos(i));
            }
        #endif /* (CSSoilMoisture_TOTAL_RADIAL_SLIDERS_COUNT) */
        
        #if (CSSoilMoisture_TOTAL_TOUCH_PADS_COUNT)
            widgetCnt = i;
            for(; i < (widgetCnt + (CSSoilMoisture_TOTAL_TOUCH_PADS_COUNT * 2u)); i = (i+2u))
            {
                if(CSSoilMoisture_GetTouchCentroidPos(i, pos) == 0u)
                {
                    outbox->position[i] = 0xFFFFu;
                    outbox->position[i+1u] = 0xFFFFu;
                }
                else
                {
                    outbox->position[i] = CSSoilMoisture_SWAP_ENDIAN16( (uint16) pos[0u]);
                    outbox->position[i+1u] = CSSoilMoisture_SWAP_ENDIAN16( (uint16) pos[1u]);
                }
            }
        #endif /* (CSSoilMoisture_TOTAL_TOUCH_PADS_COUNT) */

        #if (CSSoilMoisture_TOTAL_MATRIX_BUTTONS_COUNT)
            i += CSSoilMoisture_TOTAL_BUTTONS_COUNT;
            widgetCnt = 0u;
            for(; widgetCnt < (CSSoilMoisture_TOTAL_MATRIX_BUTTONS_COUNT * 2u); widgetCnt += 2u)
            {
                mbPositionAddr = &outbox->mbPosition[widgetCnt];
                if(CSSoilMoisture_GetMatrixButtonPos(i, ((uint8*) mbPositionAddr)) == 0u)
                {
                    outbox->mbPosition[widgetCnt] = 0xFFu;
                    outbox->mbPosition[widgetCnt+1u] = 0xFFu;
                }
                i += 2u;
            }
        #endif /* (CSSoilMoisture_TOTAL_MATRIX_BUTTONS_COUNT) */

        /* Update On/Off State */
        (void)CSSoilMoisture_CheckIsAnyWidgetActive();

        /* Copy OnMask */
        for(i = 0u; i < CSSoilMoisture_TOTAL_SENSOR_MASK_COUNT; i++)
        {
            outbox->onMask[i]  = CSSoilMoisture_sensorOnMask[i];
        }
    }
#endif /* (CSSoilMoisture_TUNER_API_GENERATE) */


/* [] END OF FILE */
