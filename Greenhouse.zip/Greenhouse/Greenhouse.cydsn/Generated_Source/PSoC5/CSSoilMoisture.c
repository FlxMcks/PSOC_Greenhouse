/*******************************************************************************
* File Name: CSSoilMoisture.c
* Version 3.50
*
* Description:
*  This file provides the source code of scanning APIs for the CapSense CSD 
*  component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "CSSoilMoisture.h"
#include "cyapicallbacks.h"


static uint8 CSSoilMoisture_initVar = 0u;
            
/* Global software variables */
volatile uint8 CSSoilMoisture_csv;            /* CapSense CSD status, control variable */
volatile uint8 CSSoilMoisture_sensorIndex;    /* Index of scannig sensor */

/* AutoTunning start */
#if (CSSoilMoisture_TUNING_METHOD == CSSoilMoisture_AUTO_TUNING)
    uint8 CSSoilMoisture_lowLevelTuningDone = 1u;
#endif /* (CSSoilMoisture_TUNING_METHOD == CSSoilMoisture_AUTO_TUNING) */

#if (CSSoilMoisture_CURRENT_SOURCE == CSSoilMoisture_EXTERNAL_RB)
    uint8  CSSoilMoisture_extRbCh0Cur = CSSoilMoisture_RBLEED1;
    #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN)
        uint8  CSSoilMoisture_extRbCh1Cur = (CSSoilMoisture_RBLEED1 + CSSoilMoisture_TOTAL_RB_NUMBER__CH0);
    #endif /* (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN)*/ 
#endif /* (CSSoilMoisture_CURRENT_SOURCE == CSSoilMoisture_EXTERNAL_RB) */ 
        
/* Global array of Raw Counts */
uint16 CSSoilMoisture_sensorRaw[CSSoilMoisture_TOTAL_SENSOR_COUNT]; 

uint8 CSSoilMoisture_sensorEnableMask[(((CSSoilMoisture_TOTAL_SENSOR_COUNT - 1u) / 8u) + 1u)] = {
0x1u, };

uint8 CYXDATA * const CYCODE CSSoilMoisture_pcTable[] = {
    (uint8 CYXDATA *)CSSoilMoisture_PortCH0__Generic0_0__GEN__PC, 
};

const uint8 CYCODE CSSoilMoisture_portTable[] = {
    CSSoilMoisture_PortCH0__Generic0_0__GEN__PORT, 
};

const uint8 CYCODE CSSoilMoisture_maskTable[] = {
    CSSoilMoisture_PortCH0__Generic0_0__GEN__MASK,
};

uint8 CYXDATA * const CYCODE CSSoilMoisture_csTable[] = {
    (uint8 CYXDATA *)CYREG_PRT0_CAPS_SEL, (uint8 CYXDATA *)CYREG_PRT1_CAPS_SEL, (uint8 CYXDATA *)CYREG_PRT2_CAPS_SEL,
    (uint8 CYXDATA *)CYREG_PRT3_CAPS_SEL, (uint8 CYXDATA *)CYREG_PRT4_CAPS_SEL, (uint8 CYXDATA *)CYREG_PRT5_CAPS_SEL,
    (uint8 CYXDATA *)CYREG_PRT6_CAPS_SEL, (uint8 CYXDATA *)CYREG_PRT15_CAPS_SEL,
};

uint8 CSSoilMoisture_idacSettings[] = {
    200u,
};

uint8 CSSoilMoisture_widgetResolution[] = {
    CSSoilMoisture_PWM_RESOLUTION_10_BITS,
};

uint8 CSSoilMoisture_analogSwitchDivider[CSSoilMoisture_TOTAL_SCANSLOT_COUNT];
const uint8 CYCODE CSSoilMoisture_widgetNumber[] = {
    0u, /* Generic0__GEN */
    
};




/*******************************************************************************
* Function Name: CSSoilMoisture_Init
********************************************************************************
*
* Summary:
*  Inits default CapSense configuration provided with customizer that defines 
*  mode of component operations and resets all sensors to an inactive state.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void CSSoilMoisture_Init(void) 
{
    #if ( (CSSoilMoisture_PRS_OPTIONS) || \
          (CSSoilMoisture_IMPLEMENTATION_CH0 == CSSoilMoisture_MEASURE_IMPLEMENTATION_UDB) || \
          ( (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN) && \
            (CSSoilMoisture_IMPLEMENTATION_CH1 == CSSoilMoisture_MEASURE_IMPLEMENTATION_UDB)) )
        
        uint8 enableInterrupts;
    #endif /* ( (CSSoilMoisture_PRS_OPTIONS) || \
           * (CSSoilMoisture_IMPLEMENTATION_CH0 == CSSoilMoisture_MEASURE_IMPLEMENTATION_UDB) || \
           * ( (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN) && \
           * (CSSoilMoisture_IMPLEMENTATION_CH1 == CSSoilMoisture_MEASURE_IMPLEMENTATION_UDB)) ) 
           */
    
    /* Clear all sensors */
    CSSoilMoisture_ClearSensors();

    /* Set Prescaler */
    #if (CSSoilMoisture_PRESCALER_OPTIONS == CSSoilMoisture_PRESCALER_UDB)
        /* Do nothing = config without prescaler */
    #elif (CSSoilMoisture_PRESCALER_OPTIONS == CSSoilMoisture_PRESCALER_FF)
        CSSoilMoisture_PRESCALER_CONTROL_REG   = (CSSoilMoisture_PRESCALER_CTRL_ENABLE |
                                                    CSSoilMoisture_PRESCALER_CTRL_MODE_CMP);
                                               
        CSSoilMoisture_PRESCALER_CONTROL2_REG |= CSSoilMoisture_PRESCALER_CTRL_CMP_LESS_EQ;
    #else
        /* Do nothing = config without prescaler */
    #endif  /* (CSSoilMoisture_PRESCALER_OPTIONS == CSSoilMoisture_PRESCALER_UDB) */

    /* Set PRS */
    #if (CSSoilMoisture_PRS_OPTIONS)
        CSSoilMoisture_SetAnalogSwitchesSource(CSSoilMoisture_ANALOG_SWITCHES_SRC_PRS);
    #endif /* (CSSoilMoisture_PRS_OPTIONS) */

    #if (CSSoilMoisture_PRS_OPTIONS == CSSoilMoisture_PRS_8BITS)
        /* Aux control set FIFO as REG */
        enableInterrupts = CyEnterCriticalSection();
        CSSoilMoisture_AUX_CONTROL_A_REG |= CSSoilMoisture_AUXCTRL_FIFO_SINGLE_REG;
        CyExitCriticalSection(enableInterrupts);
        
        /* Write polynomial */
        CSSoilMoisture_POLYNOM_REG   = CSSoilMoisture_PRS8_DEFAULT_POLYNOM;
        /* Write FIFO with seed */
        CSSoilMoisture_SEED_COPY_REG = CSSoilMoisture_MEASURE_FULL_RANGE_LOW;
        
    #elif (CSSoilMoisture_PRS_OPTIONS == CSSoilMoisture_PRS_16BITS)
        /* Aux control set FIFO as REG */ 
        enableInterrupts = CyEnterCriticalSection();  
        CSSoilMoisture_AUX_CONTROL_A_REG |= CSSoilMoisture_AUXCTRL_FIFO_SINGLE_REG;
        CSSoilMoisture_AUX_CONTROL_B_REG |= CSSoilMoisture_AUXCTRL_FIFO_SINGLE_REG;
        CyExitCriticalSection(enableInterrupts);
        
        /* Write polynomial */
        CY_SET_REG16(CSSoilMoisture_POLYNOM_PTR, CSSoilMoisture_PRS16_DEFAULT_POLYNOM);
        /* Write FIFO with seed */
        CY_SET_REG16(CSSoilMoisture_SEED_COPY_PTR, CSSoilMoisture_MEASURE_FULL_RANGE);
                
    #elif (CSSoilMoisture_PRS_OPTIONS == CSSoilMoisture_PRS_16BITS_4X)
        /* Aux control set FIFO as REG */
        enableInterrupts = CyEnterCriticalSection();
        CSSoilMoisture_AUX_CONTROL_A_REG  |= CSSoilMoisture_AUXCTRL_FIFO_SINGLE_REG;
        CyExitCriticalSection(enableInterrupts);
        
        /* Write polynomial */
        CSSoilMoisture_POLYNOM_A__D1_REG   = HI8(CSSoilMoisture_PRS16_DEFAULT_POLYNOM);
        CSSoilMoisture_POLYNOM_A__D0_REG   = LO8(CSSoilMoisture_PRS16_DEFAULT_POLYNOM);
        /* Write FIFO with seed */
        CSSoilMoisture_SEED_COPY_A__F1_REG = CSSoilMoisture_MEASURE_FULL_RANGE_LOW;
        CSSoilMoisture_SEED_COPY_A__F0_REG = CSSoilMoisture_MEASURE_FULL_RANGE_LOW; 
        
    #else
        /* Do nothing = config without PRS */
    #endif  /* (CSSoilMoisture_PRS_OPTIONS == CSSoilMoisture_PRS_8BITS) */ 
    
    /* Set ScanSpeed */
    CSSoilMoisture_SCANSPEED_PERIOD_REG = CSSoilMoisture_SCANSPEED_VALUE;
    
    /* Set the Measure */
    #if (CSSoilMoisture_IMPLEMENTATION_CH0 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF)
        /* Window PWM */
        CSSoilMoisture_PWM_CH0_CONTROL_REG      = CSSoilMoisture_MEASURE_CTRL_ENABLE;
        CSSoilMoisture_PWM_CH0_CONTROL2_REG    |= CSSoilMoisture_MEASURE_CTRL_PULSEWIDTH;
        CY_SET_REG16(CSSoilMoisture_PWM_CH0_COUNTER_PTR, CSSoilMoisture_MEASURE_FULL_RANGE);
        
        /* Raw Counter */
        CSSoilMoisture_RAW_CH0_CONTROL_REG      = CSSoilMoisture_MEASURE_CTRL_ENABLE;
        CSSoilMoisture_RAW_CH0_CONTROL2_REG    |= CSSoilMoisture_MEASURE_CTRL_PULSEWIDTH;
        CY_SET_REG16(CSSoilMoisture_RAW_CH0_PERIOD_PTR, CSSoilMoisture_MEASURE_FULL_RANGE);
    
    #else
        /*Window PWM and Raw Counter AUX set */
        enableInterrupts = CyEnterCriticalSection();
        CSSoilMoisture_PWM_CH0_AUX_CONTROL_REG |= CSSoilMoisture_AUXCTRL_FIFO_SINGLE_REG;
        CSSoilMoisture_RAW_CH0_AUX_CONTROL_REG |= CSSoilMoisture_AUXCTRL_FIFO_SINGLE_REG;
        CyExitCriticalSection(enableInterrupts);
        
        /* Window PWM */
        CSSoilMoisture_PWM_CH0_ADD_VALUE_REG    = CSSoilMoisture_MEASURE_FULL_RANGE_LOW;
        CSSoilMoisture_PWM_CH0_PERIOD_LO_REG    = CSSoilMoisture_MEASURE_FULL_RANGE_LOW;
        CSSoilMoisture_PWM_CH0_COUNTER_LO_REG   = CSSoilMoisture_MEASURE_FULL_RANGE_LOW;
        
        /* Raw Counter */
        CSSoilMoisture_RAW_CH0_ADD_VALUE_REG    = CSSoilMoisture_MEASURE_FULL_RANGE_LOW;
        CSSoilMoisture_RAW_CH0_PERIOD_HI_REG    = CSSoilMoisture_MEASURE_FULL_RANGE_LOW;
        CSSoilMoisture_RAW_CH0_PERIOD_LO_REG    = CSSoilMoisture_MEASURE_FULL_RANGE_LOW;
        
    #endif  /* (CSSoilMoisture_IMPLEMENTATION_CH0 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF) */ 
    
    #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN)
        #if (CSSoilMoisture_IMPLEMENTATION_CH1 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF)
            /* Window PWM */
            CSSoilMoisture_PWM_CH1_CONTROL_REG      = CSSoilMoisture_MEASURE_CTRL_ENABLE;
            CSSoilMoisture_PWM_CH1_CONTROL2_REG    |= CSSoilMoisture_MEASURE_CTRL_PULSEWIDTH;
            CY_SET_REG16(CSSoilMoisture_PWM_CH1_COUNTER_PTR, CSSoilMoisture_MEASURE_FULL_RANGE);
            
            /* Raw Counter */
            CSSoilMoisture_RAW_CH1_CONTROL_REG      = CSSoilMoisture_MEASURE_CTRL_ENABLE;
            CSSoilMoisture_RAW_CH1_CONTROL2_REG    |= CSSoilMoisture_MEASURE_CTRL_PULSEWIDTH;
            CY_SET_REG16(CSSoilMoisture_RAW_CH1_PERIOD_PTR, CSSoilMoisture_MEASURE_FULL_RANGE);
           
        #else
            /*Window PWM and Raw Counter AUX set */
            enableInterrupts = CyEnterCriticalSection();
            CSSoilMoisture_PWM_CH1_AUX_CONTROL_REG |= CSSoilMoisture_AUXCTRL_FIFO_SINGLE_REG;
            CSSoilMoisture_RAW_CH1_AUX_CONTROL_REG |= CSSoilMoisture_AUXCTRL_FIFO_SINGLE_REG;
            CyExitCriticalSection(enableInterrupts);
            
            /* Window PWM */
            CSSoilMoisture_PWM_CH1_ADD_VALUE_REG    = CSSoilMoisture_MEASURE_FULL_RANGE_LOW;
            CSSoilMoisture_PWM_CH1_PERIOD_LO_REG    = CSSoilMoisture_MEASURE_FULL_RANGE_LOW;
            CSSoilMoisture_PWM_CH1_COUNTER_LO_REG   = CSSoilMoisture_MEASURE_FULL_RANGE_LOW;
            
            /* Raw Counter */
            
            CSSoilMoisture_RAW_CH1_ADD_VALUE_REG    = CSSoilMoisture_MEASURE_FULL_RANGE_LOW;
            CSSoilMoisture_RAW_CH1_PERIOD_HI_REG    = CSSoilMoisture_MEASURE_FULL_RANGE_LOW;
            CSSoilMoisture_RAW_CH1_PERIOD_LO_REG    = CSSoilMoisture_MEASURE_FULL_RANGE_LOW;
            
        #endif  /* (CSSoilMoisture_IMPLEMENTATION_CH1 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF) */
    
    #endif  /* (CSSoilMoisture_DESIGN_TYPE == TWO_CHANNELS_DESIGN) */
    
    /* Setup ISR */
    CyIntDisable(CSSoilMoisture_IsrCH0_ISR_NUMBER);
    (void)CyIntSetVector(CSSoilMoisture_IsrCH0_ISR_NUMBER, &CSSoilMoisture_IsrCH0_ISR);
    CyIntSetPriority(CSSoilMoisture_IsrCH0_ISR_NUMBER, CSSoilMoisture_IsrCH0_ISR_PRIORITY);
    
    #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN)
        CyIntDisable(CSSoilMoisture_IsrCH1_ISR_NUMBER);
        CyIntSetVector(CSSoilMoisture_IsrCH1_ISR_NUMBER, CSSoilMoisture_IsrCH1_ISR);
        CyIntSetPriority(CSSoilMoisture_IsrCH1_ISR_NUMBER, CSSoilMoisture_IsrCH1_ISR_PRIORITY);
    #endif  /* CSSoilMoisture_DESIGN_TYPE */
    
    /* Setup AMux Bus: Connect Cmod, Cmp, Idac */
    CSSoilMoisture_AMuxCH0_Init();
    CSSoilMoisture_AMuxCH0_Connect(CSSoilMoisture_AMuxCH0_CMOD_CHANNEL);
    CSSoilMoisture_AMuxCH0_Connect(CSSoilMoisture_AMuxCH0_CMP_VP_CHANNEL);
    #if (CSSoilMoisture_CURRENT_SOURCE)
        CSSoilMoisture_AMuxCH0_Connect(CSSoilMoisture_AMuxCH0_IDAC_CHANNEL);
    #endif  /* CSSoilMoisture_CURRENT_SOURCE */
    
    #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN) 
        CSSoilMoisture_AMuxCH1_Init();
        CSSoilMoisture_AMuxCH1_Connect(CSSoilMoisture_AMuxCH1_CMOD_CHANNEL);
        CSSoilMoisture_AMuxCH1_Connect(CSSoilMoisture_AMuxCH1_CMP_VP_CHANNEL);
        #if (CSSoilMoisture_CURRENT_SOURCE)
            CSSoilMoisture_AMuxCH1_Connect(CSSoilMoisture_AMuxCH1_IDAC_CHANNEL);
        #endif  /* CSSoilMoisture_CURRENT_SOURCE */
    #endif  /* CSSoilMoisture_DESIGN_TYPE */
    
    /* Int Rb */
    #if (CSSoilMoisture_CURRENT_SOURCE == CSSoilMoisture_EXTERNAL_RB)
        CSSoilMoisture_InitRb();
    #endif /* (CSSoilMoisture_CURRENT_SOURCE == CSSoilMoisture_EXTERNAL_RB) */
    
    /* Enable window generation */
    CSSoilMoisture_CONTROL_REG |= CSSoilMoisture_CTRL_WINDOW_EN__CH0;
    #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN)
        CSSoilMoisture_CONTROL_REG |= CSSoilMoisture_CTRL_WINDOW_EN__CH1;
    #endif  /* CSSoilMoisture_DESIGN_TYPE */
    
    /* Initialize Cmp and Idac */
    CSSoilMoisture_CompCH0_Init();
    #if (CSSoilMoisture_CURRENT_SOURCE)
        CSSoilMoisture_IdacCH0_Init();
        CSSoilMoisture_IdacCH0_SetPolarity(CSSoilMoisture_IdacCH0_IDIR);
        CSSoilMoisture_IdacCH0_SetRange(CSSoilMoisture_IDAC_RANGE_VALUE);
        CSSoilMoisture_IdacCH0_SetValue(CSSoilMoisture_TURN_OFF_IDAC);
    #endif  /* CSSoilMoisture_CURRENT_SOURCE */
    
    #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN) 
        CSSoilMoisture_CompCH1_Init();
        #if (CSSoilMoisture_CURRENT_SOURCE)
            CSSoilMoisture_IdacCH1_Init();
            CSSoilMoisture_IdacCH1_SetPolarity(CSSoilMoisture_IdacCH1_IDIR);
            CSSoilMoisture_IdacCH1_SetRange(CSSoilMoisture_IDAC_RANGE_VALUE);
            CSSoilMoisture_IdacCH1_SetValue(CSSoilMoisture_TURN_OFF_IDAC);
        #endif  /* CSSoilMoisture_CURRENT_SOURCE */
    #endif  /* CSSoilMoisture_DESIGN_TYPE */
    
    /* Initialize Vref if as VDAC */
    #if (CSSoilMoisture_VREF_OPTIONS == CSSoilMoisture_VREF_VDAC)
        CSSoilMoisture_VdacRefCH0_Init();
        #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN)
            CSSoilMoisture_VdacRefCH1_Init();
        #endif  /* CSSoilMoisture_DESIGN_TYPE */
    #endif  /* CSSoilMoisture_VREF_OPTIONS */
}


/*******************************************************************************
* Function Name: CSSoilMoisture_Enable
********************************************************************************
*
* Summary:
*  Enables active mode power template bits for number of component used within 
*  CapSense.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void CSSoilMoisture_Enable(void) 
{
    uint8 enableInterrupts;
    
    enableInterrupts = CyEnterCriticalSection();
    
    /* Enable Prescaler */
    #if (CSSoilMoisture_PRESCALER_OPTIONS == CSSoilMoisture_PRESCALER_UDB)
        /* Do nothing  for UDB */
    #elif (CSSoilMoisture_PRESCALER_OPTIONS == CSSoilMoisture_PRESCALER_FF)
        CSSoilMoisture_PRESCALER_ACT_PWRMGR_REG  |= CSSoilMoisture_PRESCALER_ACT_PWR_EN;
        CSSoilMoisture_PRESCALER_STBY_PWRMGR_REG |= CSSoilMoisture_PRESCALER_STBY_PWR_EN;
        
    #else
        /* Do nothing = config without prescaler */
    #endif  /* (CSSoilMoisture_PRESCALER_OPTIONS == CSSoilMoisture_PRESCALER_UDB) */
    
    /* Enable ScanSpeed */
    CSSoilMoisture_SCANSPEED_AUX_CONTROL_REG |= CSSoilMoisture_SCANSPEED_CTRL_ENABLE;
    
    /* Enable Measure CH0 */
    #if (CSSoilMoisture_IMPLEMENTATION_CH0 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF)
        /* Window PWM */
        CSSoilMoisture_PWM_CH0_ACT_PWRMGR_REG  |= CSSoilMoisture_PWM_CH0_ACT_PWR_EN;
        CSSoilMoisture_PWM_CH0_STBY_PWRMGR_REG |= CSSoilMoisture_PWM_CH0_STBY_PWR_EN;
        
        /* Raw Counter */
        CSSoilMoisture_RAW_CH0_ACT_PWRMGR_REG  |= CSSoilMoisture_RAW_CH0_ACT_PWR_EN;
        CSSoilMoisture_RAW_CH0_STBY_PWRMGR_REG |= CSSoilMoisture_RAW_CH0_STBY_PWR_EN;
        
    #else
        /* Window PWM -  Do nothing */
        /* Raw Counter - Do nothing */
        
    #endif  /* (CSSoilMoisture_IMPLEMENTATION_CH0 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF) */ 
    
    /* Enable Measure CH1*/
    #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN)
        #if (CSSoilMoisture_IMPLEMENTATION_CH1 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF)
            /* Window PWM */
            CSSoilMoisture_PWM_CH1_ACT_PWRMGR_REG  |= CSSoilMoisture_PWM_CH1_ACT_PWR_EN;
            CSSoilMoisture_PWM_CH1_STBY_PWRMGR_REG |= CSSoilMoisture_PWM_CH1_STBY_PWR_EN;
            
            /* Raw Counter */
            CSSoilMoisture_RAW_CH1_ACT_PWRMGR_REG  |= CSSoilMoisture_RAW_CH1_ACT_PWR_EN;
            CSSoilMoisture_RAW_CH1_STBY_PWRMGR_REG |= CSSoilMoisture_RAW_CH1_STBY_PWR_EN;
           
        #else
        /* Window PWM -  Do nothing */
        /* Raw Counter - Do nothing */
        
        #endif  /* (CSSoilMoisture_IMPLEMENTATION_CH1 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF) */
    
    #endif  /* (CSSoilMoisture_DESIGN_TYPE == TWO_CHANNELS_DESIGN)*/
    
    /* Enable the Clock */
    #if (CSSoilMoisture_CLOCK_SOURCE == CSSoilMoisture_INTERNAL_CLOCK)
       CSSoilMoisture_IntClock_Enable();
    #endif  /* CSSoilMoisture_CLOCK_SOURCE */
    
    /* Setup Cmp and Idac */
    CSSoilMoisture_CompCH0_Enable();
    #if (CSSoilMoisture_CURRENT_SOURCE)
        CSSoilMoisture_IdacCH0_Enable();
    #endif  /* CSSoilMoisture_CURRENT_SOURCE */
    
    #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN) 
        CSSoilMoisture_CompCH1_Enable();
        #if (CSSoilMoisture_CURRENT_SOURCE)
            CSSoilMoisture_IdacCH1_Enable();
        #endif  /* CSSoilMoisture_CURRENT_SOURCE */
    #endif  /* CSSoilMoisture_DESIGN_TYPE */
    
    /* Enable Vref */
    #if (CSSoilMoisture_VREF_OPTIONS == CSSoilMoisture_VREF_VDAC)
        CSSoilMoisture_VdacRefCH0_Enable();
        CSSoilMoisture_VdacRefCH0_SetValue(CSSoilMoisture_VdacRefCH0_DEFAULT_DATA);
        #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN)
            CSSoilMoisture_VdacRefCH1_Enable();
            CSSoilMoisture_VdacRefCH1_SetValue(CSSoilMoisture_VdacRefCH1_DEFAULT_DATA);
        #endif  /* (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN) */
    #else
        /* Enable CapSense Buf */
        CSSoilMoisture_BufCH0_STBY_PWRMGR_REG |= CSSoilMoisture_BufCH0_STBY_PWR_EN;
        CSSoilMoisture_BufCH0_ACT_PWRMGR_REG  |= CSSoilMoisture_BufCH0_ACT_PWR_EN;
        
        #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN)
            CSSoilMoisture_BufCH1_STBY_PWRMGR_REG |= CSSoilMoisture_BufCH1_STBY_PWR_EN;
            CSSoilMoisture_BufCH1_ACT_PWRMGR_REG  |= CSSoilMoisture_BufCH1_ACT_PWR_EN;
        #endif  /* (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN) */
    #endif  /* (CSSoilMoisture_VREF_VDAC == CSSoilMoisture_VREF_OPTIONS) */
    
    /* Set reference on AMux Bus */
    #if (CSSoilMoisture_VREF_OPTIONS == CSSoilMoisture_VREF_VDAC)
        /* Connect Vdac to AMux Bus */
        CSSoilMoisture_AMuxCH0_Connect(CSSoilMoisture_AMuxCH0_VREF_CHANNEL);
        #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN)
            CSSoilMoisture_AMuxCH1_Connect(CSSoilMoisture_AMuxCH1_VREF_CHANNEL);
        #endif  /* (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN) */
        
    #else
        /* Enable CapSense Buf */
        CSSoilMoisture_BufCH0_CAPS_CFG0_REG |= CSSoilMoisture_CSBUF_ENABLE;
        
        #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN)
            CSSoilMoisture_BufCH1_CAPS_CFG0_REG |= CSSoilMoisture_CSBUF_ENABLE;
        #endif  /* (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN) */
    #endif  /* (CSSoilMoisture_VREF_VDAC == CSSoilMoisture_VREF_OPTIONS)*/
    
    CyExitCriticalSection(enableInterrupts);
    
    /* Enable interrupt */
    CyIntEnable(CSSoilMoisture_IsrCH0_ISR_NUMBER);
    #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN) 
        CyIntEnable(CSSoilMoisture_IsrCH1_ISR_NUMBER);
    #endif  /* CSSoilMoisture_DESIGN_TYPE */
    
    /* Set CapSense Enable state */
    CSSoilMoisture_CONTROL_REG |= CSSoilMoisture_CTRL_CAPSENSE_EN;
}


/*******************************************************************************
* Function Name: CSSoilMoisture_Start
********************************************************************************
*
* Summary:
*  Initializes registers and starts the CSD method of CapSense component. Reset 
*  all sensors to an inactive state. Enables interrupts for sensors scanning.
*  When Auto Tuning (SmartSense) mode is selected the tuning procedure is 
*  applied for all sensors.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global Variables:
*  CSSoilMoisture_initVar - used to check initial configuration, modified on 
*  first function call.
*  CSSoilMoisture_lowLevelTuningDone - used to notify the Tuner GUI that 
*  tuning of scanning parameters are done.
*
* Reentrant:
*  No
*
* Note:
*  All widgets are enabled by default except proximity widgets. Proximity widgets 
*  must be manually enabled as their long scan time is incompatible 
*  with the fast response required of other widget types. 
*
*******************************************************************************/
void CSSoilMoisture_Start(void)  
{
    if (CSSoilMoisture_initVar == 0u)
    {
        CSSoilMoisture_Init();
        CSSoilMoisture_initVar = 1u;
    }
    CSSoilMoisture_Enable();
    
    /* AutoTunning start */
    #if (CSSoilMoisture_TUNING_METHOD == CSSoilMoisture_AUTO_TUNING)
        /* AutoTune by sensor or pair of sensor basis */
        CSSoilMoisture_AutoTune();
        CSSoilMoisture_lowLevelTuningDone = 1u;
    #endif /* (CSSoilMoisture_TUNING_METHOD == CSSoilMoisture_AUTO_TUNING) */
}


/*******************************************************************************
* Function Name: CSSoilMoisture_Stop
********************************************************************************
*
* Summary:
*  Stops the sensors scanner, disables internal interrupts, and resets all 
*  sensors to an inactive state. Disables Active mode power template bits for 
*  number of component used within CapSense.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Side Effects:
*  This function should be called after scans will be completed.
*
*******************************************************************************/
void CSSoilMoisture_Stop(void) 
{
    /* Stop Capsensing */
    CSSoilMoisture_CONTROL_REG &= (uint8)(~CSSoilMoisture_CTRL_START);
    
    /* Disable interrupt */
    CyIntDisable(CSSoilMoisture_IsrCH0_ISR_NUMBER);
    #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN) 
        CyIntDisable(CSSoilMoisture_IsrCH1_ISR_NUMBER);
    #endif  /* CSSoilMoisture_DESIGN_TYPE */
    
    /* Clear all sensors */
    CSSoilMoisture_ClearSensors();
    
    /* Disable Prescaler */
    #if (CSSoilMoisture_PRESCALER_OPTIONS == CSSoilMoisture_PRESCALER_UDB)
        /* Do nothing  for UDB */
    #elif (CSSoilMoisture_PRESCALER_OPTIONS == CSSoilMoisture_PRESCALER_FF)        
        CSSoilMoisture_PRESCALER_ACT_PWRMGR_REG  &= ~CSSoilMoisture_PRESCALER_ACT_PWR_EN;
        CSSoilMoisture_PRESCALER_STBY_PWRMGR_REG &= ~CSSoilMoisture_PRESCALER_STBY_PWR_EN;
        
    #else
        /* Do nothing = config without prescaler */
    #endif  /* (CSSoilMoisture_PRESCALER_OPTIONS == CSSoilMoisture_PRESCALER_UDB) */
    
    /* Disable ScanSpeed */
    CSSoilMoisture_SCANSPEED_AUX_CONTROL_REG &= (uint8)(~CSSoilMoisture_SCANSPEED_CTRL_ENABLE);
    
    /* Disable Measure CH0 */
    #if (CSSoilMoisture_IMPLEMENTATION_CH0 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF)
        /* Window PWM */
        CSSoilMoisture_PWM_CH0_ACT_PWRMGR_REG  &= ~CSSoilMoisture_PWM_CH0_ACT_PWR_EN;
        CSSoilMoisture_PWM_CH0_STBY_PWRMGR_REG &= ~CSSoilMoisture_PWM_CH0_STBY_PWR_EN;

        /* Raw Counter */
        CSSoilMoisture_RAW_CH0_ACT_PWRMGR_REG  &= ~CSSoilMoisture_RAW_CH0_ACT_PWR_EN;
        CSSoilMoisture_RAW_CH0_STBY_PWRMGR_REG &= ~CSSoilMoisture_RAW_CH0_STBY_PWR_EN;

    #else
        /* Window PWM -  Do nothing */
        /* Raw Counter - Do nothing */
        
    #endif  /* (CSSoilMoisture_IMPLEMENTATION_CH0 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF) */ 
    
    /* Disable Measure CH1 */
    #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN)
        #if (CSSoilMoisture_IMPLEMENTATION_CH1 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF)
            /* Window PWM */
            CSSoilMoisture_PWM_CH1_ACT_PWRMGR_REG  &= ~CSSoilMoisture_PWM_CH1_ACT_PWR_EN;
            CSSoilMoisture_PWM_CH1_STBY_PWRMGR_REG &= ~CSSoilMoisture_PWM_CH1_STBY_PWR_EN;
    
            /* Raw Counter */
            CSSoilMoisture_RAW_CH1_ACT_PWRMGR_REG  &= ~CSSoilMoisture_RAW_CH1_ACT_PWR_EN;
            CSSoilMoisture_RAW_CH1_STBY_PWRMGR_REG &= ~CSSoilMoisture_RAW_CH1_STBY_PWR_EN;
           
        #else
        /* Window PWM -  Do nothing */
        /* Raw Counter - Do nothing */
        
        #endif  /* (CSSoilMoisture_IMPLEMENTATION_CH1 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF) */
    
    #endif  /* (CSSoilMoisture_DESIGN_TYPE == TWO_CHANNELS_DESIGN)*/
    
    /* Disable the Clock */
    #if (CSSoilMoisture_CLOCK_SOURCE == CSSoilMoisture_INTERNAL_CLOCK)
       CSSoilMoisture_IntClock_Stop();
    #endif  /* CSSoilMoisture_CLOCK_SOURCE */
    
    /* Disable power from Cmp and Idac */
    CSSoilMoisture_CompCH0_Stop();
    #if (CSSoilMoisture_CURRENT_SOURCE)
        CSSoilMoisture_IdacCH0_Stop();
    #endif  /* CSSoilMoisture_CURRENT_SOURCE */
    
    #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN) 
        CSSoilMoisture_CompCH1_Stop();
        #if (CSSoilMoisture_CURRENT_SOURCE)
            CSSoilMoisture_IdacCH1_Stop();
        #endif  /* CSSoilMoisture_CURRENT_SOURCE */
    #endif  /* CSSoilMoisture_DESIGN_TYPE */    
    
    /* Disable Vref if as VDAC */
    #if (CSSoilMoisture_VREF_OPTIONS == CSSoilMoisture_VREF_VDAC)
        CSSoilMoisture_VdacRefCH0_Stop();
        #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN)
            CSSoilMoisture_VdacRefCH1_Stop();
        #endif  /* CSSoilMoisture_DESIGN_TYPE */
    #endif  /* CSSoilMoisture_VREF_OPTIONS */

    #if (CSSoilMoisture_VREF_VDAC == CSSoilMoisture_VREF_OPTIONS)
        /* The Idac turn off before */
    #else
        /* Enable CapSense Buf */
        CSSoilMoisture_BufCH0_CAPS_CFG0_REG &= (uint8)(~CSSoilMoisture_CSBUF_ENABLE);
        CSSoilMoisture_BufCH0_ACT_PWRMGR_REG &= (uint8)(~CSSoilMoisture_BufCH0_ACT_PWR_EN);
        CSSoilMoisture_BufCH0_STBY_PWRMGR_REG &= (uint8)(~CSSoilMoisture_BufCH0_STBY_PWR_EN);
        
        #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN)
            CSSoilMoisture_BufCH1_CAPS_CFG0_REG &= (uint8)(~CSSoilMoisture_CSBUF_ENABLE);
            CSSoilMoisture_BufCH1_ACT_PWRMGR_REG &= (uint8)(~CSSoilMoisture_BufCH1_ACT_PWR_EN);
            CSSoilMoisture_BufCH1_STBY_PWRMGR_REG &= (uint8)(~CSSoilMoisture_BufCH1_STBY_PWR_EN);
        #endif  /*(CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN) */
    #endif  /* (CSSoilMoisture_VREF_VDAC == CSSoilMoisture_VREF_OPTIONS) */
    
    /* Set CapSense Disable state */
    CSSoilMoisture_CONTROL_REG &= (uint8)(~CSSoilMoisture_CTRL_CAPSENSE_EN);
}


#if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_ONE_CHANNEL_DESIGN)
    /*******************************************************************************
    * Function Name: CSSoilMoisture_FindNextSensor
    ********************************************************************************
    *
    * Summary:
    *  Finds next sensor to scan. 
    *
    * Parameters:
    *  snsIndex:  Current index of sensor.
    *
    * Return:
    *  Returns the next sensor index to scan.
    *
    * Global Variables:
    *  CSSoilMoisture_sensorEnableMask[ ] - used to store bit masks of enabled 
    *  sensors.
    *  CSSoilMoisture_sensorEnableMask[0] contains the masked bits for sensors 0
    *  through 7 (sensor 0 is bit 0, sensor 1 is bit 1).
    *  CSSoilMoisture_sensorEnableMask[1] contains the masked bits for sensors 
    *  8 through 15 (if needed), and so on.
    *    0 - sensor doesn't scan by CSSoilMoisture_ScanEnabledWidgets().
    *    1 - sensor scans by CSSoilMoisture_ScanEnabledWidgets().
    *
    * Note: 
    *  This function has effect on current scanning scanning and should not
    *  be used outisde of component.
    *
    *******************************************************************************/
    uint8 CSSoilMoisture_FindNextSensor(uint8 snsIndex) CYREENTRANT
    {
        uint8 pos;
        uint8 enMask;
        
        /* Check if sensor enabled */
        do
        {
            /* Proceed with the next sensor */
            snsIndex++;
            if(snsIndex == CSSoilMoisture_TOTAL_SENSOR_COUNT)
            {
                break;
            }
            pos = (snsIndex >> 3u);
            enMask = 0x01u << (snsIndex & 0x07u);
        }    
        while((CSSoilMoisture_sensorEnableMask[pos] & enMask) == 0u);
        
        return snsIndex;
    }
 #endif  /* CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_ONE_CHANNEL_DESIGN */
 
 
#if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN)
    /*******************************************************************************
    * Function Name: CSSoilMoisture_FindNextPair
    ********************************************************************************
    *
    * Summary:
    *  Finds next pair or sensor to scan. Sets condition bits to skip scanning.
    *  
    * Parameters:
    *  snsIndex:  Current index pair of sensors.
    *
    * Return:
    *  Returns the next pair of sensors index to scan.
    *
    * Global Variables:
    *  CSSoilMoisture_sensorEnableMask[ ] - used to store bit masks of enabled 
    *  sensors.
    *  CSSoilMoisture_sensorEnableMask[0] contains the masked bits for sensors 0
    *  through 7 (sensor 0 is bit 0, sensor 1 is bit 1).
    *  CSSoilMoisture_sensorEnableMask[1] contains the masked bits for sensors 
    *  8 through 15 (if needed), and so on.
    *    0 - sensor doesn't scan by CSSoilMoisture_ScanEnabledWidgets().
    *    1 - sensor scans by CSSoilMoisture_ScanEnabledWidgets().
    *
    * Note: 
    *  This function has effect on control signals set for scanning and should not
    *  be used outisde of component.
    *
    *******************************************************************************/
    uint8 CSSoilMoisture_FindNextPair(uint8 snsIndex) CYREENTRANT
    {
        uint8 posCh;
        uint8 enMaskCh;
        uint8 newRegValue;
        uint8 indexCh0 = snsIndex;
        uint8 indexCh1 = snsIndex + CSSoilMoisture_TOTAL_SENSOR_COUNT__CH0;
        
        /* Find enabled sensor on channel 0 */
        do
        {
            /* Procced the scanning */
            indexCh0++;
            if (indexCh0 >= CSSoilMoisture_TOTAL_SENSOR_COUNT__CH0)
            {
                /* Lets hadle now all from CH1 */
                indexCh0 = CSSoilMoisture_END_OF_SCAN__CH0;
                break;
            }
            
            posCh = (indexCh0 >> 3u);
            enMaskCh = 0x01u << (indexCh0 & 0x07u);
        }
        while((CSSoilMoisture_sensorEnableMask[posCh] & enMaskCh) == 0u);
        
        /* Find enabled sensor on channel 1 */
        do
        {
            /* Procced the scanning */
            indexCh1++;        
            if (indexCh1 >= CSSoilMoisture_TOTAL_SENSOR_COUNT)
            {
                /* Lets hadle now all from CH0 */
                indexCh1 = CSSoilMoisture_END_OF_SCAN__CH1;
                break;
            }
            
            posCh = (indexCh1 >> 3u);
            enMaskCh = 0x01u << (indexCh1 & 0x07u);
        } 
        while((CSSoilMoisture_sensorEnableMask[posCh] & enMaskCh) == 0u);
        
        indexCh1 -= CSSoilMoisture_TOTAL_SENSOR_COUNT__CH0;
        
        /* Find the pair to scan */
        if(indexCh0 == indexCh1)
        {
            /* Scans TWO Channels */
            snsIndex = indexCh0;
            
            CSSoilMoisture_CONTROL_REG |= (CSSoilMoisture_CTRL_WINDOW_EN__CH0 | 
                                             CSSoilMoisture_CTRL_WINDOW_EN__CH1);
        }
        else if(indexCh0 < indexCh1)
        {
           /* Scans Channel ONE only */
           snsIndex = indexCh0;
           
            newRegValue = CSSoilMoisture_CONTROL_REG;
            newRegValue |= CSSoilMoisture_CTRL_WINDOW_EN__CH0;
            newRegValue &= ~CSSoilMoisture_CTRL_WINDOW_EN__CH1;
            CSSoilMoisture_CONTROL_REG = newRegValue;
        }
        else
        {
            /* Scans Channel TWO only */
            snsIndex = indexCh1;
            
            newRegValue = CSSoilMoisture_CONTROL_REG;
            newRegValue |= CSSoilMoisture_CTRL_WINDOW_EN__CH1;
            newRegValue &= ~CSSoilMoisture_CTRL_WINDOW_EN__CH0;
            CSSoilMoisture_CONTROL_REG = newRegValue;
        }
        
        return (snsIndex);
    }
#endif  /* CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN */


/*******************************************************************************
* Function Name: CSSoilMoisture_SetScanSlotSettings
********************************************************************************
*
* Summary:
*  Sets the scan settings of the selected scan slot (sensor or pair of sensors). 
*  The scan settings incorporate IDAC value (for IDAC configurations) for every 
*  sensor and resolution. The resolution is the same for all sensors within 
*  widget.
*
* Parameters:
*  slot:  Scan slot number (sensor or pair of sensors).
*
* Return:
*  None
*
* Global Variables:
*  CSSoilMoisture_idacSettings[] - used to store idac value for every sensor.
*  CSSoilMoisture_widgetResolution[] - used to store scan resolution of every 
*  widget.
*
*******************************************************************************/
void CSSoilMoisture_SetScanSlotSettings(uint8 slot) CYREENTRANT
{
    uint8 widget;
    
    #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_ONE_CHANNEL_DESIGN)
        /* Define widget sensor belongs to */
        widget = CSSoilMoisture_widgetNumber[slot];
        
        /* Set Idac Value */
        #if (CSSoilMoisture_CURRENT_SOURCE)
            CSSoilMoisture_IdacCH0_SetValue(CSSoilMoisture_idacSettings[slot]);
        #endif  /* CSSoilMoisture_CURRENT_SOURCE */
        
        /* Window PWM */
        #if (CSSoilMoisture_IMPLEMENTATION_CH0 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF)
            CY_SET_REG16(CSSoilMoisture_PWM_CH0_PERIOD_PTR,
                ((uint16) CSSoilMoisture_widgetResolution[widget] << 8u) | CSSoilMoisture_MEASURE_FULL_RANGE_LOW);
        #else
            CSSoilMoisture_PWM_CH0_PERIOD_HI_REG = CSSoilMoisture_widgetResolution[widget];
        #endif  /* (CSSoilMoisture_IMPLEMENTATION_CH0 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF) */ 

        #if ( (CSSoilMoisture_MULTIPLE_PRESCALER_ENABLED) || \
              (CSSoilMoisture_TUNING_METHOD == CSSoilMoisture_AUTO_TUNING) )
            CSSoilMoisture_SetPrescaler(CSSoilMoisture_analogSwitchDivider[slot]);
        #elif (CSSoilMoisture_PRESCALER_OPTIONS)
            CSSoilMoisture_SetPrescaler(CSSoilMoisture_analogSwitchDivider);
        #endif /* ((CSSoilMoisture_MULTIPLE_PRESCALER_ENABLED) || \
               *   (CSSoilMoisture_TUNING_METHOD == CSSoilMoisture_AUTO_TUNING))
               */

    #else
        if(slot < CSSoilMoisture_TOTAL_SENSOR_COUNT__CH0)
        {
            /* Define widget sensor belongs to */
            widget = CSSoilMoisture_widgetNumber[slot];
            
            /* Set Idac Value */
            #if (CSSoilMoisture_CURRENT_SOURCE)
                CSSoilMoisture_IdacCH0_SetValue(CSSoilMoisture_idacSettings[slot]);
            #endif  /* CSSoilMoisture_CURRENT_SOURCE */
            
            /* Set Pwm Resolution */
            #if (CSSoilMoisture_IMPLEMENTATION_CH0 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF)
                CY_SET_REG16(CSSoilMoisture_PWM_CH0_PERIOD_PTR,
                  ((uint16) CSSoilMoisture_widgetResolution[widget] << 8u) | CSSoilMoisture_MEASURE_FULL_RANGE_LOW);
            #else
                CSSoilMoisture_PWM_CH0_PERIOD_HI_REG = CSSoilMoisture_widgetResolution[widget];
            #endif  /* (CSSoilMoisture_IMPLEMENTATION_CH0 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF)*/ 
        }
        
        if(slot < CSSoilMoisture_TOTAL_SENSOR_COUNT__CH1)
        {
            widget = CSSoilMoisture_widgetNumber[slot+CSSoilMoisture_TOTAL_SENSOR_COUNT__CH0];
        
            /* Set Idac Value */
            #if (CSSoilMoisture_CURRENT_SOURCE)
                CSSoilMoisture_IdacCH1_SetValue(CSSoilMoisture_idacSettings[slot+
                                                                             CSSoilMoisture_TOTAL_SENSOR_COUNT__CH0]);
            #endif  /* CSSoilMoisture_CURRENT_SOURCE */
            
            /* Set Pwm Resolution */
            #if (CSSoilMoisture_IMPLEMENTATION_CH1 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF)
                CY_SET_REG16(CSSoilMoisture_PWM_CH1_PERIOD_PTR,
                  ((uint16) CSSoilMoisture_widgetResolution[widget] << 8u) | CSSoilMoisture_MEASURE_FULL_RANGE_LOW);
            #else
                CSSoilMoisture_PWM_CH1_PERIOD_HI_REG = CSSoilMoisture_widgetResolution[widget];
            #endif  /* (CSSoilMoisture_IMPLEMENTATION_CH1 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF)*/ 
        }

        #if ( (CSSoilMoisture_MULTIPLE_PRESCALER_ENABLED) || \
              (CSSoilMoisture_TUNING_METHOD == CSSoilMoisture_AUTO_TUNING) )
            CSSoilMoisture_SetPrescaler(CSSoilMoisture_analogSwitchDivider[slot]);
        #elif (CSSoilMoisture_PRESCALER_OPTIONS)
            CSSoilMoisture_SetPrescaler(CSSoilMoisture_analogSwitchDivider);
        #endif /* ((CSSoilMoisture_MULTIPLE_PRESCALER_ENABLED) || \
               *   (CSSoilMoisture_TUNING_METHOD == CSSoilMoisture_AUTO_TUNING))
               */

    #endif  /* CSSoilMoisture_DESIGN_TYPE */
}


/*******************************************************************************
* Function Name: CSSoilMoisture_ScanSensor
********************************************************************************
*
* Summary:
*  Sets scan settings and starts scanning a sensor or pair of combined sensors
*  on each channel. If two channels are configured, two sensors may be scanned 
*  at the same time. After scanning is complete the isr copies the measured 
*  sensor raw data to the global array. Use of the isr ensures this function 
*  is non-blocking. Each sensor has a unique number within the sensor array. 
*  This number is assigned by the CapSense customizer in sequence.
*
* Parameters:
*  sensor:  Sensor number.
*
* Return:
*  None
*
* Global Variables:
*  CSSoilMoisture_csv - used to provide status and mode of scanning process. 
*  Sets busy status(scan in progress) and mode of scan as single scan.
*  For two channel design the additional bits are set to define if scan a 
*  pair of sensors or single one.
*  CSSoilMoisture_sensorIndex - used to store sensor scanning sensor number.
*  Sets to provided sensor argument.
*
* Reentrant:
*  No
*
*******************************************************************************/
void CSSoilMoisture_ScanSensor(uint8 sensor)  
{
    /* Clears status/control variable and set sensorIndex */
    CSSoilMoisture_csv = 0u;
    CSSoilMoisture_sensorIndex = sensor;
    
    #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_ONE_CHANNEL_DESIGN)
        /* Start of sensor scan */
        CSSoilMoisture_csv = (CSSoilMoisture_SW_STS_BUSY | CSSoilMoisture_SW_CTRL_SINGLE_SCAN);
        CSSoilMoisture_PreScan(sensor);
        
    #else
        /* CH0: check end of scan conditions */
        if(sensor < CSSoilMoisture_TOTAL_SENSOR_COUNT__CH0)
        {
            CSSoilMoisture_CONTROL_REG |= CSSoilMoisture_CTRL_WINDOW_EN__CH0;
        }
        else
        {
            CSSoilMoisture_CONTROL_REG &= ~CSSoilMoisture_CTRL_WINDOW_EN__CH0;
        }
        
        /* CH1: check end of scan conditions */
        if(sensor < CSSoilMoisture_TOTAL_SENSOR_COUNT__CH1)
        {
            CSSoilMoisture_CONTROL_REG |= CSSoilMoisture_CTRL_WINDOW_EN__CH1;
        }
        else
        {
            CSSoilMoisture_CONTROL_REG &= ~CSSoilMoisture_CTRL_WINDOW_EN__CH1;
        }
        
        /* Start sensor scan */
        if( ((CSSoilMoisture_CONTROL_REG & CSSoilMoisture_CTRL_WINDOW_EN__CH0) != 0u) || 
            ((CSSoilMoisture_CONTROL_REG & CSSoilMoisture_CTRL_WINDOW_EN__CH1) != 0u) )
        {
        
            CSSoilMoisture_csv |= (CSSoilMoisture_SW_STS_BUSY | CSSoilMoisture_SW_CTRL_SINGLE_SCAN);
            CSSoilMoisture_PreScan(sensor);
        }
        
    #endif  /* CSSoilMoisture_DESIGN_TYPE */
}


/*******************************************************************************
* Function Name: CSSoilMoisture_ScanEnableWidgets
********************************************************************************
*
* Summary:
*  Scans all of the enabled widgets. Starts scanning a sensor or pair of sensors 
*  within enabled widget. The isr proceeding scanning next sensor or pair till 
*  all enabled widgets will be scanned. Use of the isr ensures this function is 
*  non-blocking. All widgets are enabled by default except proximity widgets. 
*  Proximity widgets must be manually enabled as their long scan time is 
*  incompatible with fast response desired of other widget types.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global Variables:
*  CSSoilMoisture_csv - used to provide status and mode of scanning process. 
*  Sets busy status(scan in progress) and clears single scan mode.
*  For two channel design the additional bits are set to define if scan a 
*  pair of sensors or single one. 
*  CSSoilMoisture_sensorIndex - used to store sensor scanning sensor number.
*  Sets to 0xFF and provided to function CSSoilMoisture_FindNextSensor or
*  CSSoilMoisture_FindNextPair, these functions starts with sensor index
*  increment and overflow of uint8 gives desired index 0.
*
* Reentrant:
*  No
*
*******************************************************************************/
void CSSoilMoisture_ScanEnabledWidgets(void) 
{
    /* Clears status/control variable and set sensorIndex */
    CSSoilMoisture_csv = 0u;
    CSSoilMoisture_sensorIndex = 0xFFu;
    
    #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_ONE_CHANNEL_DESIGN)
        /* Find next sensor */
        CSSoilMoisture_sensorIndex = CSSoilMoisture_FindNextSensor(CSSoilMoisture_sensorIndex);

        /* Check end of scan condition */
        if(CSSoilMoisture_sensorIndex < CSSoilMoisture_TOTAL_SENSOR_COUNT)
        {
            CSSoilMoisture_csv |= CSSoilMoisture_SW_STS_BUSY;
            CSSoilMoisture_PreScan(CSSoilMoisture_sensorIndex);
        }
        
    #else
        /* Find next sensor and set proper control register */
        CSSoilMoisture_sensorIndex = CSSoilMoisture_FindNextPair(CSSoilMoisture_sensorIndex);
        
        /* Start sensor scan */
        if((CSSoilMoisture_sensorIndex < CSSoilMoisture_TOTAL_SENSOR_COUNT__CH0) || 
           (CSSoilMoisture_sensorIndex < CSSoilMoisture_TOTAL_SENSOR_COUNT__CH1))
        {
            CSSoilMoisture_csv |= CSSoilMoisture_SW_STS_BUSY;
            CSSoilMoisture_PreScan(CSSoilMoisture_sensorIndex);
        }
        
    #endif  /* CSSoilMoisture_DESIGN_TYPE */
}


/*******************************************************************************
* Function Name: CSSoilMoisture_IsBusy
********************************************************************************
*
* Summary:
*  Returns the state of CapSense component. The 1 means that scanning in 
*  progress and 0 means that scanning is complete.
*
* Parameters:
*  None
*
* Return:
*  Returns the state of scanning. 1 - scanning in progress, 0 - scanning 
*  completed.
*
* Global Variables:
*  CSSoilMoisture_csv - used to provide status and mode of scanning process. 
*  Checks the busy status.
*
*******************************************************************************/
uint8 CSSoilMoisture_IsBusy(void) 
{
    return ((0u != (CSSoilMoisture_csv & CSSoilMoisture_SW_STS_BUSY)) ? 1u : 0u);
}


/*******************************************************************************
* Function Name: CSSoilMoisture_ReadSensorRaw
********************************************************************************
*
* Summary:
*  Returns scan sensor raw data from the CSSoilMoisture_sensorRaw[] array. 
*  Each scan sensor has a unique number within the sensor array. This number 
*  is assigned by the CapSense customizer in sequence.
*
* Parameters:
*  sensor:  Sensor number.
*
* Return:
*  Returns current raw data value for defined sensor number.
*
* Global Variables:
*  CSSoilMoisture_sensorRaw[] - used to store sensors raw data.
*
*******************************************************************************/
uint16 CSSoilMoisture_ReadSensorRaw(uint8 sensor) 
{
    return (CSSoilMoisture_sensorRaw[sensor]);
}


/*******************************************************************************
* Function Name: CSSoilMoisture_ClearSensors
********************************************************************************
*
* Summary:
*  Resets all sensors to the non-sampling state by sequentially disconnecting
*  all sensors from Analog MUX Bus and putting them to inactive state.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
void CSSoilMoisture_ClearSensors(void) 
{
    uint8 i;
   
    for (i = 0u; i < CSSoilMoisture_TOTAL_SENSOR_COUNT; i++)
    {
        CSSoilMoisture_DisableScanSlot(i);
    }
}


#if (CSSoilMoisture_IS_COMPLEX_SCANSLOTS)
    /*******************************************************************************
    * Function Name: CSSoilMoisture_EnableScanSlot
    ********************************************************************************
    *
    * Summary:
    *  Configures the selected slot to measure during the next measurement 
    *  cycle. The corresponding pin/pins are set to Analog High-Z mode and 
    *  connected to the Analog Mux Bus. This also enables the comparator function.
    *
    * Parameters:
    *  slot:  Slot number.
    *
    * Return:
    *  None
    *
    * Global Constants:
    *  CSSoilMoisture_portTable[]  - used to store the port number that pin 
    *  belongs to for every sensor.
    *  CSSoilMoisture_maskTable[]  - used to store the pin within the port for 
    *  every sensor.
    *  CSSoilMoisture_indexTable[] - used to store indexes of complex sensors.
    *  The offset and position in this array are stored in port and mask table for 
    *  complex sensors.
    *  The bit 7 (msb) is used to define the sensor type: single or complex.
    *
    *******************************************************************************/
    void CSSoilMoisture_EnableScanSlot(uint8 slot) CYREENTRANT
    {
        uint8 j;
        uint8 snsNumber;
        const uint8 CYCODE *index;
        /* Read the sensor type: single or complex */
        uint8 snsType = CSSoilMoisture_portTable[slot];
        
        /* Check if sensor is complex */
        if ((snsType & CSSoilMoisture_COMPLEX_SS_FLAG) == 0u)
        {
            /* Enable sensor (signle) */
            CSSoilMoisture_EnableSensor(slot);
        }
        else
        {
            /* Enable complex sensor */
            snsType &= ~CSSoilMoisture_COMPLEX_SS_FLAG;
            index = &CSSoilMoisture_indexTable[snsType];
            snsNumber = CSSoilMoisture_maskTable[slot];
                        
            for (j=0u; j < snsNumber; j++)
            {
                CSSoilMoisture_EnableSensor(index[j]);
            }
        } 
    }
    
    
    /*******************************************************************************
    * Function Name: CSSoilMoisture_DisableScanSlot
    ********************************************************************************
    *
    * Summary:
    *  Disables the selected slot. The corresponding pin/pis is/are disconnected 
    *  from the Analog Mux Bus and connected to GND, High_Z or Shield electrode.
    *
    * Parameters:
    *  slot:  Slot number.
    *
    * Return:
    *  None
    *
    * Global Variables:
    *  CSSoilMoisture_portTable[]  - used to store the port number that pin 
    *  belongs to for every sensor.
    *  CSSoilMoisture_maskTable[]  - used to store the pin within the port for 
    *  every sensor.
    *  CSSoilMoisture_indexTable[] - used to store indexes of complex sensors.
    *  The offset and position in this array are stored in port and mask table for 
    *  complex sensors.
    *  The 7bit(msb) is used to define the sensor type: single or complex.
    *
    *******************************************************************************/
    void CSSoilMoisture_DisableScanSlot(uint8 slot) CYREENTRANT
    {
        uint8 j;
        uint8 snsNumber;
        const uint8 CYCODE *index;
        /* Read the sensor type: single or complex */
        uint8 snsType = CSSoilMoisture_portTable[slot];
        
        /* Check if sensor is complex */
        if ((snsType & CSSoilMoisture_COMPLEX_SS_FLAG) == 0u)
        {
            /* Disable sensor (signle) */
            CSSoilMoisture_DisableSensor(slot);
        }
        else
        {
            /* Disable complex sensor */
            snsType &= ~CSSoilMoisture_COMPLEX_SS_FLAG;
            index = &CSSoilMoisture_indexTable[snsType];
            snsNumber = CSSoilMoisture_maskTable[slot];
                        
            for (j=0u; j < snsNumber; j++)
            {
                CSSoilMoisture_DisableSensor(index[j]);
            }
        } 
    }
#endif  /* CSSoilMoisture_IS_COMPLEX_SCANSLOTS */


/*******************************************************************************
* Function Name: CSSoilMoisture_EnableSensor
********************************************************************************
*
* Summary:
*  Configures the selected sensor to measure during the next measurement cycle.
*  The corresponding pins are set to Analog High-Z mode and connected to the
*  Analog Mux Bus. This also enables the comparator function.
*
* Parameters:
*  sensor:  Sensor number.
*
* Return:
*  None
*
* Global Variables:
*  CSSoilMoisture_portTable[] - used to store the port number that pin 
*  belongs to for every sensor.
*  CSSoilMoisture_maskTable[] - used to store the pin within the port for 
*  every sensor.
*  CSSoilMoisture_csTable[]   - used to store the pointers to CAPS_SEL 
*  registers for every port.
*  CSSoilMoisture_pcTable[]   - used to store the pointers to PC pin 
*  register for every sensor.
*  CSSoilMoisture_amuxIndex[] - used to store corrected AMUX index when 
*  complex sensors are defeined.
*
*******************************************************************************/
void CSSoilMoisture_EnableSensor(uint8 sensor) CYREENTRANT
{
    uint8 port = CSSoilMoisture_portTable[sensor];
    uint8 mask = CSSoilMoisture_maskTable[sensor];
    
    #if ((CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN) && \
         (CSSoilMoisture_IS_COMPLEX_SCANSLOTS))
        uint8 amuxCh = CSSoilMoisture_amuxIndex[sensor];
    #endif  /* ((CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN) && \
            *   (CSSoilMoisture_IS_COMPLEX_SCANSLOTS))
            */
    
    /* Make sensor High-Z */
    *CSSoilMoisture_pcTable[sensor] = CSSoilMoisture_PRT_PC_HIGHZ;
    
    /* Connect to DSI output */
	if(port == 15u)
	{
		port = 7u;
	}
    *CSSoilMoisture_csTable[port] |= mask;
    
    /* Connect to AMUX */
    #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_ONE_CHANNEL_DESIGN)
        #if (CSSoilMoisture_IS_COMPLEX_SCANSLOTS)
            CSSoilMoisture_AMuxCH0_Connect(CSSoilMoisture_amuxIndex[sensor]);
        #else
            CSSoilMoisture_AMuxCH0_Connect(sensor);
        #endif  /* CSSoilMoisture_IS_COMPLEX_SCANSLOTS */
                
    #else
        #if (CSSoilMoisture_IS_COMPLEX_SCANSLOTS)
            if ((amuxCh & CSSoilMoisture_CHANNEL1_FLAG) == 0u)
            {
                CSSoilMoisture_AMuxCH0_Connect(amuxCh);
            } 
            else
            {
                amuxCh &= ~ CSSoilMoisture_CHANNEL1_FLAG;
                CSSoilMoisture_AMuxCH1_Connect(amuxCh);
            }
            
        #else
            if (sensor < CSSoilMoisture_TOTAL_SENSOR_COUNT__CH0) 
            {
                CSSoilMoisture_AMuxCH0_Connect(sensor);
            } 
            else
            {
                CSSoilMoisture_AMuxCH1_Connect(sensor - CSSoilMoisture_TOTAL_SENSOR_COUNT__CH0);
            }
            
        #endif  /* CSSoilMoisture_IS_COMPLEX_SCANSLOTS */
        
    #endif  /* CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_ONE_CHANNEL_DESIGN */
}


/*******************************************************************************
* Function Name: CSSoilMoisture_DisableSensor
********************************************************************************
*
* Summary:
*  Disables the selected sensor. The corresponding pin is disconnected from the
*  Analog Mux Bus and connected to GND, High_Z or Shield electrode.
*
* Parameters:
*  sensor:  Sensor number
*
* Return:
*  None
*
* Global Variables:
*  CSSoilMoisture_portTable[] - used to store the port number that pin 
*  belongs to for every sensor.
*  CSSoilMoisture_maskTable[] - used to store the pin within the port for 
*  every sensor.
*  CSSoilMoisture_csTable[]   - used to store the pointers to CAPS_SEL 
*  registers for every port.
*  CSSoilMoisture_pcTable[]   - used to store the pointers to PC pin 
*  register for every sensor.
*  CSSoilMoisture_amuxIndex[] - used to store corrected AMUX index when 
*  complex sensors are defeined.
*
*******************************************************************************/
void CSSoilMoisture_DisableSensor(uint8 sensor) CYREENTRANT
{
    uint8 port = CSSoilMoisture_portTable[sensor];
    uint8 mask = CSSoilMoisture_maskTable[sensor];
    
    #if ((CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN) && \
         (CSSoilMoisture_IS_COMPLEX_SCANSLOTS))
        uint8 amuxCh = CSSoilMoisture_amuxIndex[sensor];
    #endif  /* ((CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_TWO_CHANNELS_DESIGN) && \
            *   (CSSoilMoisture_IS_COMPLEX_SCANSLOTS))
            */
    
    /* Disconnect from AMUX */
    #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_ONE_CHANNEL_DESIGN)
        #if (CSSoilMoisture_IS_COMPLEX_SCANSLOTS)
            CSSoilMoisture_AMuxCH0_Disconnect(CSSoilMoisture_amuxIndex[sensor]);
        #else
            CSSoilMoisture_AMuxCH0_Disconnect(sensor);
        #endif  /* CSSoilMoisture_IS_COMPLEX_SCANSLOTS */
                
    #else
        #if (CSSoilMoisture_IS_COMPLEX_SCANSLOTS)
            if ((amuxCh & CSSoilMoisture_CHANNEL1_FLAG) == 0u)
            {
                CSSoilMoisture_AMuxCH0_Disconnect(amuxCh);
            } 
            else
            {
                amuxCh &= ~ CSSoilMoisture_CHANNEL1_FLAG;
                CSSoilMoisture_AMuxCH1_Disconnect(amuxCh);
            }
            
        #else
            if (sensor < CSSoilMoisture_TOTAL_SENSOR_COUNT__CH0) 
            {
                CSSoilMoisture_AMuxCH0_Disconnect(sensor);
            } 
            else
            {
                CSSoilMoisture_AMuxCH1_Disconnect(sensor - CSSoilMoisture_TOTAL_SENSOR_COUNT__CH0);
            }
            
        #endif  /* CSSoilMoisture_IS_COMPLEX_SCANSLOTS */
        
    #endif  /* CSSoilMoisture_DESIGN_TYPE */
    
    /* Disconnect from DSI output */
	if(port == 15u)
	{
		port = 7u;
	}
    *CSSoilMoisture_csTable[port] &= (uint8)~mask;
    
    /* Set sensor to inactive state */
    #if (CSSoilMoisture_CONNECT_INACTIVE_SNS == CSSoilMoisture_CIS_GND)
        *CSSoilMoisture_pcTable[sensor] = CSSoilMoisture_PRT_PC_GND;
    #elif (CSSoilMoisture_CONNECT_INACTIVE_SNS == CSSoilMoisture_CIS_HIGHZ)
        *CSSoilMoisture_pcTable[sensor] = CSSoilMoisture_PRT_PC_HIGHZ;
    #else
        *CSSoilMoisture_pcTable[sensor] = CSSoilMoisture_PRT_PC_SHIELD;
    #endif  /* (CSSoilMoisture_CONNECT_INACTIVE_SNS == CSSoilMoisture_CIS_GND) */
}


/*******************************************************************************
* Function Name: CSSoilMoisture_PreScan
********************************************************************************
*
* Summary:
*  Set required settings, enable sensor, remove Vref from AMUX and start the 
*  scanning process of the sensor.
*
* Parameters:
*  sensor:  Sensor number.
*
* Return:
*  None
*
* Global Variables:
*  CSSoilMoisture_rbTable[] - used to store pointers to PC pin registers for 
*  every bleed resistor (Rb). Only available when Current Source is External 
*  resistor.
*
*******************************************************************************/
void CSSoilMoisture_PreScan(uint8 sensor) CYREENTRANT
{
    /* Set Sensor Settings */
    CSSoilMoisture_SetScanSlotSettings(sensor);
    
    /* Place disable interrupts here to eliminate influence on start of scanning */
    /* `#START CSSoilMoisture_PreScan_DisableInt` */

    /* `#END` */
    
    #ifdef CSSoilMoisture_PRE_SCAN_DISABLE_INT_CALLBACK
    CSSoilMoisture_PreScan_DisableInt_Callback();
    #endif /* CSSoilMoisture_PRE_SCAN_DISABLE_INT_CALLBACK */

    /* Resets digital and pre-charge clocks */
    CSSoilMoisture_CONTROL_REG |= CSSoilMoisture_CTRL_SYNC_EN;
        
    #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_ONE_CHANNEL_DESIGN)
        #if (CSSoilMoisture_CURRENT_SOURCE == CSSoilMoisture_IDAC_SOURCE)
            /* Disable Vref from AMux */
            #if (CSSoilMoisture_VREF_VDAC == CSSoilMoisture_VREF_OPTIONS)
                CSSoilMoisture_AMuxCH0_Disconnect(CSSoilMoisture_AMuxCH0_VREF_CHANNEL);
            #else
                CSSoilMoisture_BufCH0_CAPS_CFG0_REG &= ~CSSoilMoisture_CSBUF_ENABLE;
            #endif  /* (CSSoilMoisture_VREF_VDAC != CSSoilMoisture_VREF_OPTIONS) */

            /* Enable Sensor */
            CSSoilMoisture_EnableScanSlot(sensor);
            
        #elif (CSSoilMoisture_CURRENT_SOURCE == CSSoilMoisture_IDAC_SINK)
            /* Connect IDAC */
            CSSoilMoisture_AMuxCH0_Connect(CSSoilMoisture_AMuxCH0_IDAC_CHANNEL);
            
            /* Enable Sensor */
            CSSoilMoisture_EnableScanSlot(sensor);
                
            /* Disable CapSense Buffer */
            CSSoilMoisture_BufCH0_CAPS_CFG0_REG &= (uint8)~CSSoilMoisture_CSBUF_ENABLE;
            
        #else
            /* Connect DSI output to Rb */
            *CSSoilMoisture_rbTable[CSSoilMoisture_extRbCh0Cur] |= CSSoilMoisture_BYP_MASK;
            
            /* Enable Sensor */
            CSSoilMoisture_EnableScanSlot(sensor);
             
            /* Disable CapSense Buffer */
            CSSoilMoisture_BufCH0_CAPS_CFG0_REG &= ~CSSoilMoisture_CSBUF_ENABLE;
        
        #endif  /* (CSSoilMoisture_CURRENT_SOURCE == CSSoilMoisture_IDAC_SOURCE) */
        
    #else

        if((CSSoilMoisture_CONTROL_REG & CSSoilMoisture_CTRL_WINDOW_EN__CH0) != 0u)
        {
            #if (CSSoilMoisture_CURRENT_SOURCE == CSSoilMoisture_IDAC_SOURCE)
                /* Disable Vref from AMux */
                #if (CSSoilMoisture_VREF_VDAC == CSSoilMoisture_VREF_OPTIONS)
                    CSSoilMoisture_AMuxCH0_Disconnect(CSSoilMoisture_AMuxCH0_VREF_CHANNEL);
                #else
                    CSSoilMoisture_BufCH0_CAPS_CFG0_REG &= ~CSSoilMoisture_CSBUF_ENABLE;
                #endif  /* (CSSoilMoisture_VREF_VDAC != CSSoilMoisture_VREF_OPTIONS) */
                
                /* Enable Sensor */
                CSSoilMoisture_EnableScanSlot(sensor);
                
            #elif (CSSoilMoisture_CURRENT_SOURCE == CSSoilMoisture_IDAC_SINK)
                /* Connect IDAC */
                CSSoilMoisture_AMuxCH0_Connect(CSSoilMoisture_AMuxCH0_IDAC_CHANNEL);
                
                /* Enable Sensor */
                CSSoilMoisture_EnableScanSlot(sensor);
                    
                /* Disable Vref from AMux */
                CSSoilMoisture_BufCH0_CAPS_CFG0_REG &= ~CSSoilMoisture_CSBUF_ENABLE;
                
            #else
                /* Connect DSI output to Rb */
                *CSSoilMoisture_rbTable[CSSoilMoisture_extRbCh0Cur] |= CSSoilMoisture_BYP_MASK;
                
                /* Enable Sensor */
                CSSoilMoisture_EnableScanSlot(sensor);
                    
                /* Disable Vref from AMux */
                CSSoilMoisture_BufCH0_CAPS_CFG0_REG &= ~CSSoilMoisture_CSBUF_ENABLE;
            
            #endif  /* (CSSoilMoisture_CURRENT_SOURCE == CSSoilMoisture_IDAC_SOURCE) */
            
        }
        
        if((CSSoilMoisture_CONTROL_REG & CSSoilMoisture_CTRL_WINDOW_EN__CH1) != 0u)
        {
            sensor += CSSoilMoisture_TOTAL_SENSOR_COUNT__CH0;
            
            #if (CSSoilMoisture_CURRENT_SOURCE == CSSoilMoisture_IDAC_SOURCE)
                /* Disable Vref from AMux */
                #if (CSSoilMoisture_VREF_VDAC == CSSoilMoisture_VREF_OPTIONS)
                   CSSoilMoisture_AMuxCH1_Disconnect(CSSoilMoisture_AMuxCH1_VREF_CHANNEL);
                #else 
                    CSSoilMoisture_BufCH1_CAPS_CFG0_REG &= ~CSSoilMoisture_CSBUF_ENABLE;
                #endif  /* (CSSoilMoisture_VREF_VDAC == CSSoilMoisture_VREF_OPTIONS) */
                
                /* Enable Sensor */
                CSSoilMoisture_EnableScanSlot(sensor);
                
            #elif (CSSoilMoisture_CURRENT_SOURCE == CSSoilMoisture_IDAC_SINK)
                /* Connect IDAC */
                CSSoilMoisture_AMuxCH1_Connect(CSSoilMoisture_AMuxCH1_IDAC_CHANNEL);
                
                /* Enable Sensor */
                CSSoilMoisture_EnableScanSlot(sensor);
                    
                /* Disable Vref from AMux */
                CSSoilMoisture_BufCH1_CAPS_CFG0_REG &= ~CSSoilMoisture_CSBUF_ENABLE;
                
            #else
                /* Connect DSI output to Rb */
                *CSSoilMoisture_rbTable[CSSoilMoisture_extRbCh1Cur] |= CSSoilMoisture_BYP_MASK;
                
                /* Enable Sensor */
                CSSoilMoisture_EnableScanSlot(sensor);
                
                /* Disable Vref from AMux */
                CSSoilMoisture_BufCH1_CAPS_CFG0_REG &= ~CSSoilMoisture_CSBUF_ENABLE;
            
            #endif  /* (CSSoilMoisture_CURRENT_SOURCE == CSSoilMoisture_IDAC_SOURCE) */
        }
    
    #endif  /* (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_ONE_CHANNEL_DESIGN) */
    
    /* Start measurament, pre-charge clocks are running and PRS as well */
    CSSoilMoisture_CONTROL_REG |= CSSoilMoisture_CTRL_START;
    
    /* Place enable interrupts here to eliminate influence on start of scanning */
    /* `#START CSSoilMoisture_PreScan_EnableInt` */

    /* `#END` */

    #ifdef CSSoilMoisture_PRE_SCAN_ENABLE_INT_CALLBACK
        CSSoilMoisture_PreScan_EnableInt_Callback();
    #endif /* CSSoilMoisture_PRE_SCAN_ENABLE_INT_CALLBACK */
}


#if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_ONE_CHANNEL_DESIGN)
    /*******************************************************************************
    * Function Name: CSSoilMoisture_PostScan
    ********************************************************************************
    *
    * Summary:
    *  Store results of measurament in CSSoilMoisture_SensorResult[] array,
    *  sets scan sensor in none sampling state, turn off Idac(Current Source IDAC),
    *  disconnect IDAC(Sink mode) or bleed resistor (Rb) and apply Vref on AMUX.
    *  Only one channel designs.
    *
    * Parameters:
    *  sensor:  Sensor number.
    *
    * Return:
    *  None
    *
    * Global Variables:
    *  CSSoilMoisture_sensorRaw[] - used to store sensors raw data.
    *
    * Reentrant:
    *  No
    *
    *******************************************************************************/
    void CSSoilMoisture_PostScan(uint8 sensor) CYREENTRANT
    {
        /* Stop Capsensing and rearm sync */
        CSSoilMoisture_CONTROL_REG &= (uint8)~(CSSoilMoisture_CTRL_START | CSSoilMoisture_CTRL_SYNC_EN);
        
        /* Read SlotResult from Raw Counter */
        #if (CSSoilMoisture_IMPLEMENTATION_CH0 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF)
            CSSoilMoisture_sensorRaw[sensor]  = CSSoilMoisture_MEASURE_FULL_RANGE - 
                                                      CY_GET_REG16(CSSoilMoisture_RAW_CH0_COUNTER_PTR);
        #else
            CSSoilMoisture_sensorRaw[sensor]  = ((uint16) CSSoilMoisture_RAW_CH0_COUNTER_HI_REG << 8u);
            CSSoilMoisture_sensorRaw[sensor] |= (uint16) CSSoilMoisture_RAW_CH0_COUNTER_LO_REG;
            CSSoilMoisture_sensorRaw[sensor]  = CSSoilMoisture_MEASURE_FULL_RANGE -
                                                      CSSoilMoisture_sensorRaw[sensor];
        #endif  /* (CSSoilMoisture_IMPLEMENTATION == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF) */
        
        /* Disable Sensor */
        CSSoilMoisture_DisableScanSlot(sensor);
        
        #if(CSSoilMoisture_CURRENT_SOURCE)
            /* Turn off IDAC */
            CSSoilMoisture_IdacCH0_SetValue(CSSoilMoisture_TURN_OFF_IDAC);
            #if (CSSoilMoisture_CURRENT_SOURCE == CSSoilMoisture_IDAC_SINK)
                /* Disconnect IDAC */
                CSSoilMoisture_AMuxCH0_Disconnect(CSSoilMoisture_AMuxCH0_IDAC_CHANNEL);
            #endif  /* (CSSoilMoisture_CURRENT_SOURCE == CSSoilMoisture_IDAC_SINK) */
        #else
            /* Disconnect DSI output from Rb */
            *CSSoilMoisture_rbTable[CSSoilMoisture_extRbCh0Cur] &= ~CSSoilMoisture_BYP_MASK; 
        #endif  /* (CSSoilMoisture_CURRENT_SOURCE)*/
            
        /* Enable Vref on AMUX */
        #if (CSSoilMoisture_VREF_OPTIONS == CSSoilMoisture_VREF_VDAC)
            CSSoilMoisture_AMuxCH0_Connect(CSSoilMoisture_AMuxCH0_VREF_CHANNEL);
        #else
            CSSoilMoisture_BufCH0_CAPS_CFG0_REG |= CSSoilMoisture_CSBUF_ENABLE;
        #endif  /* (CSSoilMoisture_VREF_VDAC == CSSoilMoisture_VREF_OPTIONS) */
    }
    
#else

    /*******************************************************************************
    * Function Name: CSSoilMoisture_PostScan
    ********************************************************************************
    *
    * Summary:
    *  Store results of measurament in CSSoilMoisture_SensorResult[] array,
    *  sets scan sensor in none sampling state, turn off Idac(Current Source IDAC),
    *  disconnect IDAC(Sink mode) or bleed resistor (Rb) and apply Vref on AMUX.
    *  Only used for channel 0 in two channes designs.
    *
    * Parameters:
    *  sensor:  Sensor number.
    *
    * Return:
    *  None
    *
    * Global Variables:
    *  CSSoilMoisture_sensorRaw[] - used to store sensors raw data.
    *
    * Reentrant:
    *  No
    *
    *******************************************************************************/
    void CSSoilMoisture_PostScanCh0(uint8 sensor) CYREENTRANT
    {
        if (((CSSoilMoisture_CONTROL_REG & CSSoilMoisture_CTRL_WINDOW_EN__CH0) == 0u) && 
            ((CSSoilMoisture_CONTROL_REG & CSSoilMoisture_CTRL_WINDOW_EN__CH1) == 0u)) 
        {
            /* Stop Capsensing and rearm sync */
            CSSoilMoisture_CONTROL_REG &= ~(CSSoilMoisture_CTRL_START | CSSoilMoisture_CTRL_SYNC_EN);
        }
        
        /* Read SlotResult from Raw Counter */
        #if (CSSoilMoisture_IMPLEMENTATION_CH0 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF)
            CSSoilMoisture_sensorRaw[sensor]  = CSSoilMoisture_MEASURE_FULL_RANGE - 
                                                      CY_GET_REG16(CSSoilMoisture_RAW_CH0_COUNTER_PTR);
        #else
            CSSoilMoisture_sensorRaw[sensor]  = ((uint16) CSSoilMoisture_RAW_CH0_COUNTER_HI_REG << 8u);
            CSSoilMoisture_sensorRaw[sensor] |= (uint16) CSSoilMoisture_RAW_CH0_COUNTER_LO_REG;
            CSSoilMoisture_sensorRaw[sensor]  = CSSoilMoisture_MEASURE_FULL_RANGE - 
                                                      CSSoilMoisture_sensorRaw[sensor];
        #endif  /* (CSSoilMoisture_IMPLEMENTATION_CH0 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF)*/
        
        /* Disable Sensor */
        CSSoilMoisture_DisableScanSlot(sensor);
        
        #if (CSSoilMoisture_CURRENT_SOURCE)
            /* Turn off IDAC */
            CSSoilMoisture_IdacCH0_SetValue(CSSoilMoisture_TURN_OFF_IDAC);
            #if (CSSoilMoisture_CURRENT_SOURCE == CSSoilMoisture_IDAC_SINK)
                /* Disconnect IDAC */
                CSSoilMoisture_AMuxCH0_Disconnect(CSSoilMoisture_AMuxCH0_IDAC_CHANNEL);
            #endif  /* (CSSoilMoisture_CURRENT_SOURCE == CSSoilMoisture_IDAC_SINK) */
        #else
            /* Disconnect DSI output from Rb */
            *CSSoilMoisture_rbTable[CSSoilMoisture_extRbCh0Cur] &= ~CSSoilMoisture_BYP_MASK; 
        #endif  /* (CSSoilMoisture_CURRENT_SOURCE)*/
        
        /* Enable Vref on AMUX */
        #if (CSSoilMoisture_VREF_OPTIONS == CSSoilMoisture_VREF_VDAC)
            CSSoilMoisture_AMuxCH0_Connect(CSSoilMoisture_AMuxCH0_VREF_CHANNEL);
        #else
            CSSoilMoisture_BufCH0_CAPS_CFG0_REG |= CSSoilMoisture_CSBUF_ENABLE;
        #endif  /* (CSSoilMoisture_VREF_VDAC == CSSoilMoisture_VREF_OPTIONS) */
    }
    
    
    /*******************************************************************************
    * Function Name: CSSoilMoisture_PostScanCh1
    ********************************************************************************
    *
    * Summary:
    *  Store results of measurament in CSSoilMoisture_SensorResult[] array,
    *  sets scan sensor in none sampling state, turn off Idac(Current Source IDAC), 
    *  disconnect IDAC(Sink mode) or bleed resistor (Rb) and apply Vref on AMUX.
    *  Only used for channel 1 in two channes designs.
    *
    * Parameters:
    *  sensor:  Sensor number.
    *
    * Return:
    *  None
    *
    * Global Variables:
    *  CSSoilMoisture_sensorRaw[] - used to store sensors raw data.
    *
    * Reentrant:
    *  No
    *
    *******************************************************************************/
    void CSSoilMoisture_PostScanCh1(uint8 sensor) CYREENTRANT
    {
        if (((CSSoilMoisture_CONTROL_REG & CSSoilMoisture_CTRL_WINDOW_EN__CH0) == 0u) && 
            ((CSSoilMoisture_CONTROL_REG & CSSoilMoisture_CTRL_WINDOW_EN__CH1) == 0u))
        {
            /* Stop Capsensing and rearm sync */
            CSSoilMoisture_CONTROL_REG &= ~(CSSoilMoisture_CTRL_START | CSSoilMoisture_CTRL_SYNC_EN);
        }
        
        /* Read SlotResult from Raw Counter */
        #if (CSSoilMoisture_IMPLEMENTATION_CH1 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF)
            CSSoilMoisture_sensorRaw[sensor]  = CSSoilMoisture_MEASURE_FULL_RANGE - 
                                                      CY_GET_REG16(CSSoilMoisture_RAW_CH1_COUNTER_PTR);
        #else
            CSSoilMoisture_sensorRaw[sensor]  = ((uint16) CSSoilMoisture_RAW_CH1_COUNTER_HI_REG << 8u);
            CSSoilMoisture_sensorRaw[sensor] |= (uint16) CSSoilMoisture_RAW_CH1_COUNTER_LO_REG;
            CSSoilMoisture_sensorRaw[sensor]  = CSSoilMoisture_MEASURE_FULL_RANGE - 
                                                      CSSoilMoisture_sensorRaw[sensor];
        #endif  /* (CSSoilMoisture_IMPLEMENTATION_CH1 == CSSoilMoisture_MEASURE_IMPLEMENTATION_FF)*/
        
        /* Disable Sensor */
        CSSoilMoisture_DisableScanSlot(sensor);
        
        #if (CSSoilMoisture_CURRENT_SOURCE)
            /* Turn off IDAC */
            CSSoilMoisture_IdacCH1_SetValue(CSSoilMoisture_TURN_OFF_IDAC);
            #if (CSSoilMoisture_CURRENT_SOURCE == CSSoilMoisture_IDAC_SINK)
                /* Disconnect IDAC */
                CSSoilMoisture_AMuxCH1_Disconnect(CSSoilMoisture_AMuxCH1_IDAC_CHANNEL);
            #endif  /* (CSSoilMoisture_CURRENT_SOURCE == CSSoilMoisture_IDAC_SINK) */
        #else
            /* Disconnect DSI output from Rb */
            *CSSoilMoisture_rbTable[CSSoilMoisture_extRbCh1Cur] &= ~CSSoilMoisture_BYP_MASK; 
        #endif  /* (CSSoilMoisture_CURRENT_SOURCE)*/

        /* Enable Vref on AMUX */
        #if (CSSoilMoisture_VREF_OPTIONS == CSSoilMoisture_VREF_VDAC)
            CSSoilMoisture_AMuxCH1_Connect(CSSoilMoisture_AMuxCH1_VREF_CHANNEL);
        #else
            CSSoilMoisture_BufCH1_CAPS_CFG0_REG |= CSSoilMoisture_CSBUF_ENABLE;
        #endif  /* (CSSoilMoisture_VREF_VDAC == CSSoilMoisture_VREF_OPTIONS) */
    }
    
#endif  /* CSSoilMoisture_DESIGN_TYPE */


#if (CSSoilMoisture_CURRENT_SOURCE == CSSoilMoisture_EXTERNAL_RB)
    /*******************************************************************************
    * Function Name:  CSSoilMoisture_InitRb
    ********************************************************************************
    *
    * Summary:
    *  Sets all Rbleed resistor to High-Z mode. The first Rbleed resistor is active
    *  while next measure.
    *  This function is available only if Current Source is External Resistor.
    *
    * Parameters:
    *  None
    *
    * Return:
    *  None
    *
    ********************************************************************************/
    void CSSoilMoisture_InitRb(void) 
    {
        uint8 i;
        
        /* Disable all Rb */
        for(i = 0u; i < CSSoilMoisture_TOTAL_RB_NUMBER; i++)
        {
            /* Make High-Z */
            *CSSoilMoisture_rbTable[i] = CSSoilMoisture_PRT_PC_HIGHZ;
        }
    }
    
    
    /*******************************************************************************
    * Function Name: CSSoilMoisture_SetRBleed
    ********************************************************************************
    *
    * Summary:
    *  Sets the pin to use for the bleed resistor (Rb) connection. This function
    *  can be called at runtime to select the current Rb pin setting from those 
    *  defined customizer. The function overwrites the component parameter setting. 
    *  This function is available only if Current Source is External Resistor.
    * 
    * Parameters:
    *  rbleed:  Ordering number for bleed resistor terminal defined in CapSense
    *  customizer.
    *
    * Return:
    *  None
    *
    * Global Variables:
    *  CSSoilMoisture_extRbCh0Cur - used to store current number of active 
    *  bleed resistor (Rb) of channel 0.
    *  CSSoilMoisture_extRbCh1Cur - used to store current number of active 
    *  bleed resistor (Rb) of channel 1.
    *  The active bleed resistor (Rb) pin will be used while next measurement  
    *  cycle.
    *
    * Reentrant:
    *  No
    *
    *******************************************************************************/
    void CSSoilMoisture_SetRBleed(uint8 rbleed) 
    {
        #if (CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_ONE_CHANNEL_DESIGN)
            CSSoilMoisture_extRbCh0Cur = rbleed;
            
        #else
            if(rbleed < CSSoilMoisture_TOTAL_RB_NUMBER__CH0)
            {
                CSSoilMoisture_extRbCh0Cur = rbleed;
            }
            else
            {
                CSSoilMoisture_extRbCh1Cur = (rbleed - CSSoilMoisture_TOTAL_RB_NUMBER__CH0);   
            }
    
        #endif  /* CSSoilMoisture_DESIGN_TYPE == CSSoilMoisture_ONE_CHANNEL_DESIGN */ 
    }
#endif /* CSSoilMoisture_CURRENT_SOURCE == CSSoilMoisture_EXTERNAL_RB */ 

#if (CSSoilMoisture_PRESCALER_OPTIONS)
    /*******************************************************************************
    * Function Name: CSSoilMoisture_SetPrescaler
    ********************************************************************************
    *
    * Summary:
    *  Sets analog switch divider.
    *
    * Parameters:
    *  prescaler:  Sets prescaler divider values.
    *
    * Return:
    *  None
    *
    *******************************************************************************/
    void CSSoilMoisture_SetPrescaler(uint8 prescaler) CYREENTRANT
    {
        /* Set Prescaler */
        #if (CSSoilMoisture_PRESCALER_OPTIONS == CSSoilMoisture_PRESCALER_UDB)
            CSSoilMoisture_PRESCALER_PERIOD_REG = prescaler;
            CSSoilMoisture_PRESCALER_COMPARE_REG = (prescaler >> 1u);
        #elif (CSSoilMoisture_PRESCALER_OPTIONS == CSSoilMoisture_PRESCALER_FF)
            CY_SET_REG16(CSSoilMoisture_PRESCALER_PERIOD_PTR, (uint16) prescaler);
            CY_SET_REG16(CSSoilMoisture_PRESCALER_COMPARE_PTR, (uint16) (prescaler >> 1u));
        #else
            /* Do nothing = config without prescaler */
        #endif  /* (CSSoilMoisture_PRESCALER_OPTIONS == CSSoilMoisture_PRESCALER_UDB) */
    }


    /*******************************************************************************
    * Function Name: CSSoilMoisture_GetPrescaler
    ********************************************************************************
    *
    * Summary:
    *  Gets analog switch divider.
    *
    * Parameters:
    *  None
    *
    * Return:
    *   Returns the prescaler divider value.
    *
    *******************************************************************************/
    uint8 CSSoilMoisture_GetPrescaler(void) 
    {
        uint8 prescaler = 0u;

        /* Get Prescaler */
        #if (CSSoilMoisture_PRESCALER_OPTIONS == CSSoilMoisture_PRESCALER_UDB)
            prescaler = CSSoilMoisture_PRESCALER_PERIOD_REG;
            
        #elif (CSSoilMoisture_PRESCALER_OPTIONS == CSSoilMoisture_PRESCALER_FF)
            prescaler = (uint8) CY_GET_REG16(CSSoilMoisture_PRESCALER_PERIOD_PTR);
            
        #else
            /* Do nothing = config without prescaler */
        #endif  /* (CSSoilMoisture_PRESCALER_OPTIONS == CSSoilMoisture_PRESCALER_UDB) */
        
        return (prescaler);
    }
#endif  /* CSSoilMoisture_PRESCALER_OPTIONS */


/*******************************************************************************
* Function Name: CSSoilMoisture_SetScanSpeed
********************************************************************************
*
* Summary:
*  Sets ScanSpeed divider.
*
* Parameters:
*  scanspeed:  Sets ScanSpeed divider.
*
* Return:
*  None
*
*******************************************************************************/
void CSSoilMoisture_SetScanSpeed(uint8 scanSpeed) 
{
    CSSoilMoisture_SCANSPEED_PERIOD_REG = scanSpeed; 
}


#if (CSSoilMoisture_PRS_OPTIONS)
    /*******************************************************************************
    * Function Name: CSSoilMoisture_SetAnalogSwitchesSource
    ********************************************************************************
    *
    * Summary:
    *  Selects the Analog switches source between PRS and prescaler. It is useful
    *  for sensor capacitance determination for sensors with low self-capacitance.
    *  This function is used in auto-tuning procedure.
    *
    * Parameters:
    *  src:  analog switches source:
    *           CSSoilMoisture_ANALOG_SWITCHES_SRC_PRESCALER - selects prescaler
    *           CSSoilMoisture_ANALOG_SWITCHES_SRC_PRS - selects PRS
    *
    * Return:
    *  None
    *
    * Reentrant:
    *  No
    *******************************************************************************/
    void CSSoilMoisture_SetAnalogSwitchesSource(uint8 src)
                      
    {
        if(src == CSSoilMoisture_ANALOG_SWITCHES_SRC_PRESCALER)
        {
            CSSoilMoisture_CONTROL_REG &= (uint8)~0x10u;
        }
        else
        {
            CSSoilMoisture_CONTROL_REG |= 0x10u;
        }
    }
#endif /* (CSSoilMoisture_PRS_OPTIONS) */

/* [] END OF FILE */
