/*******************************************************************************
* File Name: PPWMServo.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_PPWMServo_ALIASES_H) /* Pins PPWMServo_ALIASES_H */
#define CY_PINS_PPWMServo_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"


/***************************************
*              Constants        
***************************************/
#define PPWMServo_0			(PPWMServo__0__PC)
#define PPWMServo_0_INTR	((uint16)((uint16)0x0001u << PPWMServo__0__SHIFT))

#define PPWMServo_INTR_ALL	 ((uint16)(PPWMServo_0_INTR))

#endif /* End Pins PPWMServo_ALIASES_H */


/* [] END OF FILE */
