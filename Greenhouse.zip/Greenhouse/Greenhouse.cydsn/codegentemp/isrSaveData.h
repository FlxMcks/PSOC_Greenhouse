/*******************************************************************************
* File Name: isrSaveData.h
* Version 1.71
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_isrSaveData_H)
#define CY_ISR_isrSaveData_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void isrSaveData_Start(void);
void isrSaveData_StartEx(cyisraddress address);
void isrSaveData_Stop(void);

CY_ISR_PROTO(isrSaveData_Interrupt);

void isrSaveData_SetVector(cyisraddress address);
cyisraddress isrSaveData_GetVector(void);

void isrSaveData_SetPriority(uint8 priority);
uint8 isrSaveData_GetPriority(void);

void isrSaveData_Enable(void);
uint8 isrSaveData_GetState(void);
void isrSaveData_Disable(void);

void isrSaveData_SetPending(void);
void isrSaveData_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the isrSaveData ISR. */
#define isrSaveData_INTC_VECTOR            ((reg32 *) isrSaveData__INTC_VECT)

/* Address of the isrSaveData ISR priority. */
#define isrSaveData_INTC_PRIOR             ((reg8 *) isrSaveData__INTC_PRIOR_REG)

/* Priority of the isrSaveData interrupt. */
#define isrSaveData_INTC_PRIOR_NUMBER      isrSaveData__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable isrSaveData interrupt. */
#define isrSaveData_INTC_SET_EN            ((reg32 *) isrSaveData__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the isrSaveData interrupt. */
#define isrSaveData_INTC_CLR_EN            ((reg32 *) isrSaveData__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the isrSaveData interrupt state to pending. */
#define isrSaveData_INTC_SET_PD            ((reg32 *) isrSaveData__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the isrSaveData interrupt. */
#define isrSaveData_INTC_CLR_PD            ((reg32 *) isrSaveData__INTC_CLR_PD_REG)


#endif /* CY_ISR_isrSaveData_H */


/* [] END OF FILE */
