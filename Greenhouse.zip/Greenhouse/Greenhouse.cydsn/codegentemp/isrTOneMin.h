/*******************************************************************************
* File Name: isrTOneMin.h
* Version 1.71
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_isrTOneMin_H)
#define CY_ISR_isrTOneMin_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void isrTOneMin_Start(void);
void isrTOneMin_StartEx(cyisraddress address);
void isrTOneMin_Stop(void);

CY_ISR_PROTO(isrTOneMin_Interrupt);

void isrTOneMin_SetVector(cyisraddress address);
cyisraddress isrTOneMin_GetVector(void);

void isrTOneMin_SetPriority(uint8 priority);
uint8 isrTOneMin_GetPriority(void);

void isrTOneMin_Enable(void);
uint8 isrTOneMin_GetState(void);
void isrTOneMin_Disable(void);

void isrTOneMin_SetPending(void);
void isrTOneMin_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the isrTOneMin ISR. */
#define isrTOneMin_INTC_VECTOR            ((reg32 *) isrTOneMin__INTC_VECT)

/* Address of the isrTOneMin ISR priority. */
#define isrTOneMin_INTC_PRIOR             ((reg8 *) isrTOneMin__INTC_PRIOR_REG)

/* Priority of the isrTOneMin interrupt. */
#define isrTOneMin_INTC_PRIOR_NUMBER      isrTOneMin__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable isrTOneMin interrupt. */
#define isrTOneMin_INTC_SET_EN            ((reg32 *) isrTOneMin__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the isrTOneMin interrupt. */
#define isrTOneMin_INTC_CLR_EN            ((reg32 *) isrTOneMin__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the isrTOneMin interrupt state to pending. */
#define isrTOneMin_INTC_SET_PD            ((reg32 *) isrTOneMin__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the isrTOneMin interrupt. */
#define isrTOneMin_INTC_CLR_PD            ((reg32 *) isrTOneMin__INTC_CLR_PD_REG)


#endif /* CY_ISR_isrTOneMin_H */


/* [] END OF FILE */
