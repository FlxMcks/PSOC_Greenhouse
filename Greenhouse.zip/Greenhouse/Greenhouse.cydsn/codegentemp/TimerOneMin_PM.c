/*******************************************************************************
* File Name: TimerOneMin_PM.c
* Version 2.80
*
*  Description:
*     This file provides the power management source code to API for the
*     Timer.
*
*   Note:
*     None
*
*******************************************************************************
* Copyright 2008-2017, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#include "TimerOneMin.h"

static TimerOneMin_backupStruct TimerOneMin_backup;


/*******************************************************************************
* Function Name: TimerOneMin_SaveConfig
********************************************************************************
*
* Summary:
*     Save the current user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  TimerOneMin_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void TimerOneMin_SaveConfig(void) 
{
    #if (!TimerOneMin_UsingFixedFunction)
        TimerOneMin_backup.TimerUdb = TimerOneMin_ReadCounter();
        TimerOneMin_backup.InterruptMaskValue = TimerOneMin_STATUS_MASK;
        #if (TimerOneMin_UsingHWCaptureCounter)
            TimerOneMin_backup.TimerCaptureCounter = TimerOneMin_ReadCaptureCount();
        #endif /* Back Up capture counter register  */

        #if(!TimerOneMin_UDB_CONTROL_REG_REMOVED)
            TimerOneMin_backup.TimerControlRegister = TimerOneMin_ReadControlRegister();
        #endif /* Backup the enable state of the Timer component */
    #endif /* Backup non retention registers in UDB implementation. All fixed function registers are retention */
}


/*******************************************************************************
* Function Name: TimerOneMin_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  TimerOneMin_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void TimerOneMin_RestoreConfig(void) 
{   
    #if (!TimerOneMin_UsingFixedFunction)

        TimerOneMin_WriteCounter(TimerOneMin_backup.TimerUdb);
        TimerOneMin_STATUS_MASK =TimerOneMin_backup.InterruptMaskValue;
        #if (TimerOneMin_UsingHWCaptureCounter)
            TimerOneMin_SetCaptureCount(TimerOneMin_backup.TimerCaptureCounter);
        #endif /* Restore Capture counter register*/

        #if(!TimerOneMin_UDB_CONTROL_REG_REMOVED)
            TimerOneMin_WriteControlRegister(TimerOneMin_backup.TimerControlRegister);
        #endif /* Restore the enable state of the Timer component */
    #endif /* Restore non retention registers in the UDB implementation only */
}


/*******************************************************************************
* Function Name: TimerOneMin_Sleep
********************************************************************************
*
* Summary:
*     Stop and Save the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  TimerOneMin_backup.TimerEnableState:  Is modified depending on the
*  enable state of the block before entering sleep mode.
*
*******************************************************************************/
void TimerOneMin_Sleep(void) 
{
    #if(!TimerOneMin_UDB_CONTROL_REG_REMOVED)
        /* Save Counter's enable state */
        if(TimerOneMin_CTRL_ENABLE == (TimerOneMin_CONTROL & TimerOneMin_CTRL_ENABLE))
        {
            /* Timer is enabled */
            TimerOneMin_backup.TimerEnableState = 1u;
        }
        else
        {
            /* Timer is disabled */
            TimerOneMin_backup.TimerEnableState = 0u;
        }
    #endif /* Back up enable state from the Timer control register */
    TimerOneMin_Stop();
    TimerOneMin_SaveConfig();
}


/*******************************************************************************
* Function Name: TimerOneMin_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*
* Parameters:
*  void
*
* Return:
*  void
*
* Global variables:
*  TimerOneMin_backup.enableState:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void TimerOneMin_Wakeup(void) 
{
    TimerOneMin_RestoreConfig();
    #if(!TimerOneMin_UDB_CONTROL_REG_REMOVED)
        if(TimerOneMin_backup.TimerEnableState == 1u)
        {     /* Enable Timer's operation */
                TimerOneMin_Enable();
        } /* Do nothing if Timer was disabled before */
    #endif /* Remove this code section if Control register is removed */
}


/* [] END OF FILE */
