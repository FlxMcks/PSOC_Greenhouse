/*******************************************************************************
* File Name: isrTOneSec.h
* Version 1.71
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_isrTOneSec_H)
#define CY_ISR_isrTOneSec_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void isrTOneSec_Start(void);
void isrTOneSec_StartEx(cyisraddress address);
void isrTOneSec_Stop(void);

CY_ISR_PROTO(isrTOneSec_Interrupt);

void isrTOneSec_SetVector(cyisraddress address);
cyisraddress isrTOneSec_GetVector(void);

void isrTOneSec_SetPriority(uint8 priority);
uint8 isrTOneSec_GetPriority(void);

void isrTOneSec_Enable(void);
uint8 isrTOneSec_GetState(void);
void isrTOneSec_Disable(void);

void isrTOneSec_SetPending(void);
void isrTOneSec_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the isrTOneSec ISR. */
#define isrTOneSec_INTC_VECTOR            ((reg32 *) isrTOneSec__INTC_VECT)

/* Address of the isrTOneSec ISR priority. */
#define isrTOneSec_INTC_PRIOR             ((reg8 *) isrTOneSec__INTC_PRIOR_REG)

/* Priority of the isrTOneSec interrupt. */
#define isrTOneSec_INTC_PRIOR_NUMBER      isrTOneSec__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable isrTOneSec interrupt. */
#define isrTOneSec_INTC_SET_EN            ((reg32 *) isrTOneSec__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the isrTOneSec interrupt. */
#define isrTOneSec_INTC_CLR_EN            ((reg32 *) isrTOneSec__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the isrTOneSec interrupt state to pending. */
#define isrTOneSec_INTC_SET_PD            ((reg32 *) isrTOneSec__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the isrTOneSec interrupt. */
#define isrTOneSec_INTC_CLR_PD            ((reg32 *) isrTOneSec__INTC_CLR_PD_REG)


#endif /* CY_ISR_isrTOneSec_H */


/* [] END OF FILE */
