/* ========================================
 *
 * Copyright Felix Moecks, 04.05.2023
 * 
 * PSOC Project Greenhouse
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>
#include <string.h>
#include "stdlib.h"

//definitions
#define FALSE 0
#define TRUE 1

//definition of delaytimes for One wire
#define tickDelay(tick) CyDelayUs(tick)
#define A  6
#define B 64
#define C 60
#define D 10
#define E  9
#define F 55
#define G  0
#define H 480
#define I 70
#define J 410

//function prototypes
CY_ISR_PROTO(OneSIntervall);
CY_ISR_PROTO(OneMIntervall);
CY_ISR_PROTO(OneFiveMIntervall);
CY_ISR_PROTO(ConsoleInput);
CY_ISR_PROTO(isr_sSample);
void Startup();
void GetLastDates();
void calcTimes();
_Bool SaveCurrentDateAndTime();
int DHTread();
int ReadOW1();
int ReadOW2();
_Bool SaveData();
_Bool ControllInput();
_Bool PrintNewestLastAsJSON();
_Bool SensorAdress(int sensorNumber);
void PrintEEROM();
int OWTouchReset(void);
int OWReadBit(void);
void OWWriteBit(int bit);
int OWReadByte(void);
void OWWriteByte(uint64 data);
void Controlling();

//global variables
//flags 
_Bool flagDownSample = FALSE;
_Bool flagReactToInput = FALSE;
_Bool flagFirstInput = FALSE;
_Bool flagPrintRealTimeData = FALSE;
_Bool flagOFMin = FALSE;
_Bool errorSensor = FALSE;
_Bool allowOWread = TRUE;
//for controlling
_Bool heaterFlag = FALSE;
_Bool waterSprayer = FALSE;
int OpenWindowPerPercent = 0;
//for setup & addresses
int nextOWAdress = 0;
_Bool setup = FALSE;
uint8 OneWire1[8], OneWire2[8];
//for save data
uint8 nextSaveRow=1;
//for live data and avg
uint16 OW1Result, OW2Result;
int airTemperature=99;
int airHumidity=99;
int SoilMoistDigital;
uint32 SumTemperatureAir, SumHumidityAir, SumTemperatureSoil1, SumTemperatureSoil2, SumSoilMoistDigital;
uint16 AmountTemperatureAir, AmountHumidityAir, AmountTemperatureSoil1, AmountTemperatureSoil2, AmountSoilMoistDigital;
//for date and time
uint8 sec, min, hour, day, month;
uint16 time,year;
//for input and print
char inputKey[20];
int nextInputKey=0;
char outputstring[100];

int main(void)
{
    CyGlobalIntEnable;      //enable global interrupts.
    Startup();              //initialize and enable all required components
    GetLastDates();         //real last time and date, in case of a short breakup
    
    //print Menu to console for the first time
    UART_1_PutString("\n\rCommand terminal:\n\r '?'\t\t-Print general information\n\r 'T?'\t\t-Print current time\n\r 'T hh:mm'\t-Set time to hh:mm\n\r 'D?'\t\t-Print current date\n\r 'D dd/mm/yyyy'\t-Set date to dd/mm/yyyy\n\r 'A'\t\t-Print saves from last 24h(latest at last)\n\r 'C'\t\t-Delete saves\n\r 'S'\t\t-Views live data and controls\n\rPress 'ESC' at any time to see the menu again\n\r");
    
    //set servo to default (window closed)
    PWMServo_WriteCompare(700);
    for(;;)
    {
        
        if(flagDownSample){
            //reads the value of the capactitve soil moisture sensor and stores it for the average value
            SoilMoistDigital = ADC_CapSens_Read16();
            SumSoilMoistDigital += SoilMoistDigital;
            AmountSoilMoistDigital++;
            
            //reads the value of the DHT11 sensor and stores it for the average value
            DHTread();
            SumTemperatureAir += airTemperature;
            SumHumidityAir += airHumidity;
            AmountTemperatureAir++;
            AmountHumidityAir++;
            
            
            //Soil temperatures via ds18b20. Only enter if setup is not active
            if(allowOWread==TRUE){
                OW1Result = ReadOW1();
                OW2Result = ReadOW2();
            }
            
            //Useful tools for programming only
            //PrintEEROM(); //prints EEPROM (for tests only)
            //PrintNewestLeastAsJSON();     //print data
            //while(SaveData()!=TRUE);      //save data every second
            //CyDelay(50000);               //wait 50s

            //print waning if temperature of the Soil is not correct (called ONLY ONCE)
            if((OW1Result >3000||OW2Result>3000) && errorSensor==FALSE && setup==FALSE){
                errorSensor = TRUE;
                UART_1_PutString("\n\r*************************************************************************************************************************************************\n\r");
                UART_1_PutString("\n\rWARNING\n\rAt least one of the soil temperature sensors is defective, not addressed correctly or not plugged in correctly.\n\rPlease check your circuit and make sure that the addresses are correct. To change the addresses, press 'E' and follow the instructions.\n\r");   
                UART_1_PutString("\n\r*************************************************************************************************************************************************\n\r");
            }
            //resets the limitation of the warning, after values are possible 
            else if((OW1Result <3000 && OW2Result<3000)&&errorSensor==TRUE && setup==FALSE) errorSensor = FALSE;
            
            //live time overview for the values and the controls
            if(flagPrintRealTimeData){
                //Print current values
                sprintf(outputstring,"\n\n\n\n\n\n\n\n\rTemperature[C]:\t\tHumidity[%%]:\t\tMoisture:\n\rAir:\t%i \t\tAir:\t%i \t\tSoil:\t%d\n\rSoil1:\t%i.%i\n\rSoil2:\t%i.%i \n\n\t\t\r",airTemperature, airHumidity, SoilMoistDigital, OW1Result/10, OW1Result%10, OW2Result/10, OW2Result%10);
                UART_1_PutString(outputstring);
                //The controls are done and printet here
                Controlling();
            }
            flagDownSample = FALSE;
        }
        //save Data after 15 min
        if(flagOFMin){
            while(SaveData()!=TRUE);
            flagOFMin = FALSE;
        }
        
        //calls a function to process the confirmed input
        if(flagReactToInput){
            while(ControllInput()!=TRUE);
        }
    }
}
CY_ISR(OneSIntervall){
    /**********************************************************
    *
    *   Downsampling for reading Sensors to 1 Value per second
    *
    **********************************************************/
    flagDownSample = TRUE;    //allow to enter main once a second
    TimerOneSec_ReadStatusRegister();   //reset isr
}
CY_ISR(OneMIntervall){
    /**********************************************************
    *
    *   Time Mesurment for Controllertime and save current time
    *
    **********************************************************/
    min++;                                      //count the minutes up
    while(SaveCurrentDateAndTime()!=TRUE);      //save the current time
    TimerOneMin_ReadStatusRegister();           //reset isr for next call
}
CY_ISR(OneFiveMIntervall){
    /**********************************************************
    *
    *   Allow Saving every 15min
    *
    **********************************************************/
    flagOFMin = TRUE;                           //set flag to allow saving the data
    Timer15Min_ReadStatusRegister();            //reset isr for next call
}
CY_ISR(ConsoleInput){
    /**********************************************************
    *
    *   Read the input after a Button is pressed.
    *   Prints Options, menu, and helt to the console, also shows the input.
    *   Input can become deleated with 'DEL', confirmed with 'ENTER'.
    *   Menu can called with 'ESC'.
    *
    **********************************************************/
    char newinput = UART_1_GetChar();
    //Enter if Setupmenu is not open (normal mode)
    if(setup!=TRUE){
        //If 'ENTER' was pressed
        if (newinput == 0x0A || newinput == 0x0D) {
            inputKey[nextInputKey] = '\0';                      //cut char array after last input
            flagReactToInput = TRUE;                            //confirms the input, and allows to read them 
            flagFirstInput = FALSE;                             //block the inpunt help
        }
        
        //if 'ESC' was pressed, ends Method: Controlling, print menu, reset input for next input
        else if(newinput == 0x1B) {
            flagPrintRealTimeData = FALSE;                      //ends the real time ciew of the data and controlls
            UART_1_PutString("\n\rCommand terminal:\n\r '?'\t\t-Print general information\n\r 'T?'\t\t-Print current time\n\r 'T hh:mm'\t-Set time to hh:mm\n\r 'D?'\t\t-Print current date\n\r 'D dd/mm/yyyy'\t-Set date to dd/mm/yyyy\n\r 'A'\t\t-Print saves from last 24h(latest at last)\n\r 'C'\t\t-Delete saves\n\r 'S'\t\t-View live data and controls\n\rPress 'ESC' at any time to see the menu again\n\r");
            for(int i = 0; i<20; i++) inputKey[i] = 0;          //write 0 to every array element to cleat them
            nextInputKey = 0;                                   //reset the next input location to 0
            flagFirstInput = FALSE;                             //block the input help
        }
        
        else{
            //if 'DEL' was pressed, the last input is deleted
            if(newinput == 0x7F && nextInputKey>0){ nextInputKey = nextInputKey-1;
            UART_1_PutChar(newinput);                           //prints out input
            }
            
            //if any other key was pressed, print current input
            else{
                inputKey[nextInputKey] = newinput;              //save input in array
                if(nextInputKey==0 && flagFirstInput!=1) {      //if this is the first input, Prit the input help
                    UART_1_PutString("\n\n\n\rUse 'Delete' to delete last input,\n\rUse 'Enter' to confirm input.\n\r");
                    UART_1_PutString("Your Input is:\t");
                    flagFirstInput = TRUE;
                }
                UART_1_PutChar(inputKey[nextInputKey]);         //print input to console
            }
            if(newinput != 0x7F)nextInputKey++;                 //If input is not 'Delete' go to next array slot for next input
        }
    }
    
    //Enter if setup menu is open
    if(setup==TRUE){
        //If setupmenu is open, only allow 'Enter' as an input to go on
        if (newinput == 0x0A || newinput == 0x0D) {
            inputKey[nextInputKey] = '\0';                      //cut char array after last input
            flagReactToInput = TRUE;                            //confirms the input, and allows to read them 
            flagFirstInput = FALSE;                             //block the inpunt help
        }
    }
    UART_1_ReadRxStatus();                                       //reset isr for next call   
}
void Startup(){
    /**********************************************************
    *
    *   Initialize and enable all required components.
    *
    **********************************************************/
    
    //for downsampling      (1sec)
    isrTOneSec_Enable();
    isrTOneSec_StartEx(OneSIntervall);
    TimerOneSec_Enable();
    TimerOneSec_Start();
    
    //for controller time   (1min)
    isrTOneMin_Enable();
    isrTOneMin_StartEx(OneMIntervall);
    TimerOneMin_Enable();
    TimerOneMin_Start();
    
    //for save intervall    (15min)
    isrSaveData_Enable();
    isrSaveData_StartEx(OneFiveMIntervall);
    Timer15Min_Enable();
    Timer15Min_Start();
    
    //isr for an console input
    isrUART_Enable();
    isrUART_StartEx(ConsoleInput);
    
    //UART for comunicate with console
    UART_1_Enable();
    UART_1_Start();
    
    //clocks for timer
    timer_clock_1kHz_Start();
    timer_clock_60Hz_Start();
    PWM_clock_1MHz_Start();
    
    //for converting values of the capacitive soil moisture sensor for Analog to digital values
    ADC_CapSens_Enable();
    ADC_CapSens_StartConvert();
    ADC_CapSens_Start();
    
    //for servo motor (window)
    PWMServo_Enable();
    PWMServo_Start();
    
    //for store all the data
    EEPROM_1_Enable();
    EEPROM_1_Start();
    
    //feedback after initialisation is done
    UART_1_PutString("\n\rSytem started up!\n\r");
}
void GetLastDates(){
    /**********************************************************
    *
    *   Reads last curent time, date and sensor addresses
    *   Needed after a short reset or crash
    *
    **********************************************************/
    
    //read last values from EEPROM
    nextSaveRow = EEPROM_1_ReadByte(0);                         //Pos 0 -next row to save data
    year = EEPROM_1_ReadByte(6)*10 + EEPROM_1_ReadByte(7);      //Pos 6+7 -current year, split up in two byte
    month = EEPROM_1_ReadByte(5);                               //Pos 5 -month
    day =  EEPROM_1_ReadByte(4);                                //Pos 4 -day
    hour = EEPROM_1_ReadByte(3);                                //Pos 3 -hour
    min = EEPROM_1_ReadByte(2);                                 //Pos 2 -min
    
    //read Soil temperature sensor address 1 from row 97
    for(int i = 0; i<8; i++){
        OneWire1[i]=EEPROM_1_ReadByte(97*16+i);
    }
    
    //read Soil temperature sensor address 2 from row 98
    for(int i = 0; i<8; i++){
        OneWire2[i]=EEPROM_1_ReadByte(98*16+i);
    }
}
void calcTimes(){
    /**********************************************************
    *
    *   The date, and time become calculated here.
    *   Too large values become converted.
    *   The month Februar always have 28 days!
    *
    **********************************************************/
    
    
    if(min >= 60){hour++; min=min%60;}                  //add 1 hour after 60 min are full (min 0-59)
    if(hour >= 24){day++; hour=hour%24;}                //add 1 day after 24 hours are full (hour 0-23)
    //add 1 month after 31 days full
    if (day > 31 && (month == 1 || month == 3|| month == 5|| month == 7|| month == 8|| month == 10|| month == 12)){month++, day = day%31;}
    //add 1 month after 30 days full
    else if (day > 30&& (month == 4 || month == 6|| month == 9|| month == 11) ){month++, day = day%30;}
    //add 1 month after 28 days full
    else if (day >28 && (month ==2)){month++; day = day%28;}
    if(month >= 13){year++;month=month%13+1;}           //add 1 Year after 12 month are full (month 0-12). Year can go up to 2559
}
_Bool SaveCurrentDateAndTime(){
    /**********************************************************
    *
    *   calculates and safe the current date and time
    *   return: TRUE if done
    *
    **********************************************************/
    
    calcTimes();
    EEPROM_1_WriteByte(year/10, 6);         //saves current year in row 0 Byte 6&7
    EEPROM_1_WriteByte(year%10, 7);
    EEPROM_1_WriteByte(month, 5);           //saves current month in row 0 Byte 5
    EEPROM_1_WriteByte(day, 4);             //saves current day in row 0 Byte 4
    EEPROM_1_WriteByte(hour, 3);            //saves current hour in row 0 Byte 3
    EEPROM_1_WriteByte(min, 2);             //saves current min in row 0 Byte 2
    
 return TRUE;   
}
_Bool SaveData(){
    /**********************************************************
    *
    *   calculates and saves the date and time stamp.
    *   Stores the average of all read data. Clears the last values after.
    *   Each row is a new Save. If one save is done, it jumps to the next row, up to the 97 row
    *   Row 0 is reserved for CurrentSaveRow(next row) and current time and date
    *   return: TRUE if done
    *
    **********************************************************/
    
    calcTimes();
    //values become saved in the next row
    EEPROM_1_WriteByte(min, (nextSaveRow*16));                                      //save timestamp (min)
    EEPROM_1_WriteByte(hour, (nextSaveRow*16+1));                                   //save timestamp (hour)
    EEPROM_1_WriteByte(day, (nextSaveRow*16+2));                                    //save timestamp (day)
    EEPROM_1_WriteByte(month, (nextSaveRow*16+3));                                  //save timestamp (month)
    EEPROM_1_WriteByte(year/10, (nextSaveRow*16+4));                                //save timestamp (year)
    EEPROM_1_WriteByte(year%10, (nextSaveRow*16+5));                                //save timestamp (year)
    EEPROM_1_WriteByte(0xFF, (nextSaveRow*16+6));                                   //row with nothing
    EEPROM_1_WriteByte(SumTemperatureAir/AmountTemperatureAir,nextSaveRow*16+7);    //calc and save air temperature
    EEPROM_1_WriteByte(SumHumidityAir/AmountHumidityAir,nextSaveRow*16+8);          //calc and save air humidity
    EEPROM_1_WriteByte((SumTemperatureSoil1/AmountTemperatureSoil1)/10,nextSaveRow*16+9);   //calc and save Soil 1 temperature
    EEPROM_1_WriteByte((SumTemperatureSoil1/AmountTemperatureSoil1)%10,nextSaveRow*16+10);
    EEPROM_1_WriteByte((SumTemperatureSoil2/AmountTemperatureSoil2)/10,nextSaveRow*16+11);  //calc and save Aoil 2 temperature
    EEPROM_1_WriteByte((SumTemperatureSoil2/AmountTemperatureSoil2)%10,nextSaveRow*16+12);
    EEPROM_1_WriteByte((SumSoilMoistDigital/AmountSoilMoistDigital),nextSaveRow*16+13);        //calc and save soil moisture
    
    //reset values
    SumTemperatureAir = AmountTemperatureAir = SumHumidityAir = AmountHumidityAir = SumSoilMoistDigital = 0;
    SumTemperatureSoil1 = AmountTemperatureSoil1 = SumTemperatureSoil2 = AmountTemperatureSoil2 = AmountSoilMoistDigital = 0;
    
    //go to next row for the next save
    nextSaveRow++;
    
    //after 97 rows it jumps fack to row 1 (row 0 is reserved for 'currentSaveRow' and current date and time
    if(nextSaveRow >= 97)nextSaveRow = 1;
    
    //store the number of the next row in row 0 byte 0
    EEPROM_1_WriteByte(nextSaveRow, 0);
 return TRUE;   
}
_Bool PrintNewestLastAsJSON(){
    /**********************************************************
    *
    *   prints all saved data to the console
    *   Prints oldest save first, and newst Last
    *   return TRUE when done
    *
    **********************************************************/
    
    uint8 row = nextSaveRow-1;
    UART_1_PutString("{\n\r");
    char out[200];          //if this is too small the program will crash, if this is too big, the next input doesnt work
    for(int i = 0; i<96; i++){
        uint rowtwo = (row+i)%96+1;     //calc the next row (oldest save first)
        sprintf(out, "\"Minute\":%d, \"Hour\":%d, \"Day\":%d, \"Month\":%d, \"Year\":%d%d, \"AirTemperature\":%d, \"AirHumidity\":%d, \"Soil1Temperature\":%d.%d, \"Soil2Temperature\":%d.%d, \"SoilMoisture\":%d,\n\r" ,EEPROM_1_ReadByte(rowtwo*16),EEPROM_1_ReadByte(rowtwo*16+1),EEPROM_1_ReadByte(rowtwo*16+2),EEPROM_1_ReadByte(rowtwo*16+3),EEPROM_1_ReadByte(rowtwo*16+4),EEPROM_1_ReadByte(rowtwo*16+5),EEPROM_1_ReadByte(rowtwo*16+7),EEPROM_1_ReadByte(rowtwo*16+8),EEPROM_1_ReadByte(rowtwo*16+9),EEPROM_1_ReadByte(rowtwo*16+10),EEPROM_1_ReadByte(rowtwo*16+11),EEPROM_1_ReadByte(rowtwo*16+12),EEPROM_1_ReadByte(rowtwo*16+13));
        UART_1_PutString(out);
    }
    UART_1_PutString("}\n\r");
    return TRUE;
}
_Bool ControllInput(){
    /**********************************************************
    *
    *   Is called after a cometed input.
    *   Detects the input and reacts accordingly.
    *   Recognizes lower and upper case letters.
    *   return: TRUE if done
    *
    **********************************************************/
    //always checks the nessecary keys, and the lenght of inserted string
    
    //Prints general Information
    if(inputKey[0] == '?' && strlen(inputKey)==1)  UART_1_PutString("\n\rGreenhouse controller #1, by Felix Moecks\n\r");
    
    else if(inputKey[0] == 'd' || inputKey[0] == 'D'){
        //prints current date
        if(inputKey[1] == '?' && strlen(inputKey)==2){
            UART_1_PutString("\n\rDate:\t");
            if(EEPROM_1_ReadByte(4)<10) UART_1_PutString("0");      //if byte has only one digit, print a 0 in before
            sprintf(outputstring, "%d.", EEPROM_1_ReadByte(4));
            UART_1_PutString(outputstring);
            if(EEPROM_1_ReadByte(5)<10) UART_1_PutString("0");      //if byte has only one digit, print a 0 in before
            sprintf(outputstring, "%d.", EEPROM_1_ReadByte(5));
            UART_1_PutString(outputstring);
            sprintf(outputstring, "%d%d\n\r", EEPROM_1_ReadByte(6), EEPROM_1_ReadByte(7));
            UART_1_PutString(outputstring);
        }
        
        //reads new date and saves it
        //prints new date
        else if (inputKey[1] == ' ' && inputKey[4] == '/' && inputKey[7] == '/' && strlen(inputKey)==12){
            uint16 intDM;                               //variable to save day and month
            intDM = (inputKey[2]-48)*10;                //reads tens digit of day, converts it from char to value
            day = intDM + (inputKey[3]-48);             //reads ones digit of day, converts it, add to tens digit and saves it as day
            intDM = (inputKey[5]-48)*10;                //reads tens digit of month, converts it from char to value
            month = intDM + (inputKey[6]-48);           //reads ones digit of month, converts it, add to tens digit and saves it as month
            intDM = (inputKey[8]-48)*1000;              //reads thousands digit of year, converts it from char to value
            intDM = intDM + (inputKey[9]-48)*100;       //reads hundrets digit of year, converts it from char to value
            intDM = intDM + (inputKey[10]-48)*10;       //reads tens digit of year, converts it from char to value
            year = intDM + (inputKey[11]-48);           //reads ones digit of year, converts it, add to tens digit and saves it as month
            SaveCurrentDateAndTime();       //save new values as currrent date
            //print new date
            UART_1_PutString("\n\rNew Date:\t");
            if(EEPROM_1_ReadByte(4)<10) UART_1_PutString("0");      //if byte has only one digit, print a 0 in before
            sprintf(outputstring, "%d.", EEPROM_1_ReadByte(4));
            UART_1_PutString(outputstring);
            if(EEPROM_1_ReadByte(5)<10) UART_1_PutString("0");      //if byte has only one digit, print a 0 in before
            sprintf(outputstring, "%d.", EEPROM_1_ReadByte(5));
            UART_1_PutString(outputstring);
            sprintf(outputstring, "%d%d\n\r", EEPROM_1_ReadByte(6), EEPROM_1_ReadByte(7));
            UART_1_PutString(outputstring);
        }
        
        //Invalid input
        else UART_1_PutString("\n\rInvalid input, please try it again\n\r");
    }
    
    else if(inputKey[0] == 't' || inputKey[0] == 'T'){
        //prints current time as hh:mm
        if(inputKey[1] == '?' && strlen(inputKey)==2){
            UART_1_PutString("\n\rTime:\t");
            if(EEPROM_1_ReadByte(3)<10) UART_1_PutString("0");      //if byte has only one digit, print a 0 in before
            sprintf(outputstring, "%d:", EEPROM_1_ReadByte(3));     //print  Hours
            UART_1_PutString(outputstring);
            if(EEPROM_1_ReadByte(2)<10) UART_1_PutString("0");      //if byte has only one digit, print a 0 in before
            sprintf(outputstring, "%d\n\r", EEPROM_1_ReadByte(2));  //print minutes
            UART_1_PutString(outputstring);
        }
        
        //reads new time and saves it
        //prints new time
        else if (inputKey[1] == ' ' && inputKey[4] == ':' && strlen(inputKey)==7){
            uint8 intHM = 0;
            intHM = (inputKey[2]-48)*10;            //reads tens digit of hour, converts it from cahr to value
            hour = intHM + (inputKey[3]-48);        //reads ones digit of hour, converts it from cahr to value, add it to the tens digit and saves it
            intHM = (inputKey[5]-48)*10;            //reads tens digit of minutes, converts it from cahr to value
            min = intHM + (inputKey[6]-48);         //reads tens digit of minutes, converts it from cahr to value, add it to the tens digit and saves it
            SaveCurrentDateAndTime();               //saves as current time
            //print new time
            UART_1_PutString("\n\rNew time:\t");
            if(EEPROM_1_ReadByte(3)<10) UART_1_PutString("0");      //if byte has only one digit, prit a 0 in before
            sprintf(outputstring, "%d:", EEPROM_1_ReadByte(3));     //hours
            UART_1_PutString(outputstring);
            if(EEPROM_1_ReadByte(2)<10) UART_1_PutString("0");      //if byte has only one digit, prit a 0 in before
            sprintf(outputstring, "%d\n\r", EEPROM_1_ReadByte(2));  //minutes
            UART_1_PutString(outputstring);
        }
        
        //Invalid input
        else UART_1_PutString("\n\rInvalid input, please try it again\n\r");
    }
    //prints out all saved data
    else if((inputKey[0] == 'a' || inputKey[0] == 'A') && strlen(inputKey)==1){
        UART_1_PutString("\n\r");
        while(PrintNewestLastAsJSON()!=TRUE);
    }
    
    //Overwrites all data with 0
    else if((inputKey[0] == 'c' || inputKey[0] == 'C') && strlen(inputKey)==1){
        isrUART_Disable();      //disables isr, do get done the job
        UART_1_PutString("\n\rThis might take a second");
        nextSaveRow = 1;
        for(int i=16; i<1552; i++){     //clear row 1-96 (rows 0,97,98 are not delete
         EEPROM_1_WriteByte(0,i);   
        }
        UART_1_PutString("\n\rSaved data deleted!!!");
        isrUART_Enable();
    }
    
    //Enables lifetime tracking of data and controls
    else if((inputKey[0] == 's' || inputKey[0] == 'S') && strlen(inputKey)==1){
        flagPrintRealTimeData = TRUE;           //code  is in the main, just enables a flag
    }
    
    // Enter the setup menu, disables input except Enter
    else if(((inputKey[0] == 'e' || inputKey[0] == 'E') && strlen(inputKey)==1) || (setup==TRUE && inputKey[1]=='\0')){
        switch (nextOWAdress){
            //case 0: setup:disables other inputs than 'ENTER', allowOWread: disables readOW function, print text and instructions, set OW1result to high to keep error open ,nextOWAdress:set next setep to case 1
        case 0:   setup = TRUE; allowOWread = FALSE; UART_1_PutString("\n\n\rWelcome to the setup menu, please follow the instructions to the end.\n\rMake sure that your system has only one sensor connected that communicates via One Wire (i.e. only one of the ds18b20+ sensors for the soil temperature).\n\rTo do this, you can simply unplug one of the two sensors and leave the cables plugged in. \n\rWhen this is done, press 'ENTER' to read the address from the connected sensor."); OW1Result=4000; nextOWAdress++; break;
            //case 1: read adress, print adress and instruction, go to next case
        case 1:   while(SensorAdress(1)!=TRUE); UART_1_PutString("\n\n\rThe adress of sensor 1 is:\t0x"); for(int i=0;i<8;i++){sprintf(outputstring, "%x", OneWire1[i]); UART_1_PutString(outputstring);} UART_1_PutString("\n\rPlease unplug this sensor now and connenct the second sensor. Please press 'ENTER' if the sensors are changed.\n\r"); nextOWAdress++; break;
            //case 2: read adress, print adress and "Job done", erset case to 0 for next setup if needed, allow readOW, allow other inputs than 'ENTER'
        case 2:   while(SensorAdress(2)!=TRUE); UART_1_PutString("\n\rThe adress of sensor 2 is:\t0x"); for(int i=0;i<8;i++){sprintf(outputstring, "%x", OneWire2[i]);UART_1_PutString(outputstring);} UART_1_PutString("\n\rSetup complete! You can connect the second sensor again now.\n\rPress 'ESC' to open the command terminal.\n\n\r"); allowOWread = TRUE; nextOWAdress-=2; setup = FALSE; break;
        default:  UART_1_PutString("Error"); break;
        }
    }
    
    //do nothing if input is empty (just enter was pressed)
    else if(inputKey[0] == '\0');
    
    //invalid input
    else{
        UART_1_PutString("\n\rInvalid input, please try it again!\n\r");
    }
    
    //resets the Array and the flags
    for(int i = 0; i<20; i++){
        inputKey[i]=0;          //clears input array
    }
    nextInputKey=0;     //reset array input slot
    flagReactToInput = FALSE;       //reset flag
    return TRUE;
}
void PrintEEROM(){
    /**********************************************************
    *
    *   prints out EEPROM storage for last 97 saves (all)
    *   (used for development only)
    *
    **********************************************************/
    
    int x=0;
    char outprint[10];
    for(int i = 0; i<1584; i++){        //print row 0-98 (inclusive sensor adress and current dates)
        if(i%16 == 0){
            sprintf(outprint, "\n\rRow:%i\t",x);
            UART_1_PutString(outprint);
         x++; }
        sprintf(outprint, "\t%d", EEPROM_1_ReadByte((i)));
        UART_1_PutString(outprint);
    }
}
int DHTread(){ 
    /**********************************************************
    *
    *   reads the Ait Temperature and Humidity
    *
    **********************************************************/
    
    uint8 IState;
    IState=CyEnterCriticalSection();  
    uint8 bits[5]; 
    uint8 cnt = 7; 
    uint8 idx = 0; 
    int   calc=0; 
    int   timeout=0; 
    for (int i=0; i< 5; i++)  
        bits[i] = 0; 
    PAirTemperature_Humidity_Write(0u); 
    CyDelay(19); 
    PAirTemperature_Humidity_Write(1u); 
    while(PAirTemperature_Humidity_Read()==1) 
    { 
        timeout++; 
        if(timeout>500) 
            goto r99;  //DHT error function 
    } 
    while(PAirTemperature_Humidity_Read()==0) 
    {         
        timeout++; 
        if(timeout>500) 
            goto r99; //DHT error function 
    } 
    calc=timeout; 
    timeout=0; 
    while(PAirTemperature_Humidity_Read()==1); 
    for (int i=0; i<40; i++) 
 	{ 
        timeout=0; 
        while(PAirTemperature_Humidity_Read()==0); 
        while(PAirTemperature_Humidity_Read()==1) 
            timeout++; 
        //Data acquiring point 
        if ((timeout) > (calc/2)) 
            bits[idx] |= (1 << cnt); 
        if (cnt == 0)   // next byte? 
   	 { 
        cnt = 7;    // restart at MSB 
   	 	idx++;      // next byte! 
   	 } 
   	else cnt--; 
    } 
    airHumidity = bits[0];  
    airTemperature = bits[2];  
    CyExitCriticalSection(IState); 
    CyDelay(1);
    
    return 0; 
    r99:    //Goto label for error in DHT reading 
        airHumidity = 99;  
        airTemperature = 99;  
        CyExitCriticalSection(IState); 
        return 99; 
}
int ReadOW1(){
    /**********************************************************
    *
    *   reads the Soil temperature.
    *   returns read value.
    *
    **********************************************************/
    
    int result;
    uint16 OWLSB; 
    
    OWTouchReset();         //Reset OW
    OWWriteByte(0x55);      //Match ROM
    //write ROM adress
    OWWriteByte(OneWire1[0]);
    OWWriteByte(OneWire1[1]);
    OWWriteByte(OneWire1[2]);
    OWWriteByte(OneWire1[3]);
    OWWriteByte(OneWire1[4]);
    OWWriteByte(OneWire1[5]);
    OWWriteByte(OneWire1[6]);
    OWWriteByte(OneWire1[7]);
    
    OWWriteByte(0x44);  //Initiates temperature conversion
    OWTouchReset();     //Reset OW
    OWWriteByte(0x55);  //Match ROM
    //write ROM adress
    OWWriteByte(OneWire1[0]);
    OWWriteByte(OneWire1[1]);
    OWWriteByte(OneWire1[2]);
    OWWriteByte(OneWire1[3]);
    OWWriteByte(OneWire1[4]);
    OWWriteByte(OneWire1[5]);
    OWWriteByte(OneWire1[6]);
    OWWriteByte(OneWire1[7]);
    
    OWWriteByte(0xBE);  //Reads the entire scratchpad including the CRC byte
    OWLSB = OWReadByte();   //read least significant byte
    result = OWReadByte();  //read most significant byte
    //combide LSB with MSB
    for(int i = 0; i < 8; i++)
    {
            result = (result << 1);
    }
    result = result + OWLSB;
    //calculate value*10 (for .0 digit)
    result = result * 10;
    result = result / 16;
    //count to avg temperature
    SumTemperatureSoil1 += result;
    AmountTemperatureSoil1++;
 return result;   
}
int ReadOW2(){
    /**********************************************************
    *
    *   reads the Soil temperature.
    *   returns read value.
    *
    **********************************************************/
    
    int result;
    uint16 OWLSB;

    OWTouchReset();         //Reset OW
    OWWriteByte(0x55);      //Match ROM
    //write ROM adress
    OWWriteByte(OneWire2[0]);
    OWWriteByte(OneWire2[1]);
    OWWriteByte(OneWire2[2]);
    OWWriteByte(OneWire2[3]);
    OWWriteByte(OneWire2[4]);
    OWWriteByte(OneWire2[5]);
    OWWriteByte(OneWire2[6]);
    OWWriteByte(OneWire2[7]);
    
    OWWriteByte(0x44);  //Initiates temperature conversion
    OWTouchReset();     //Reset OW
    OWWriteByte(0x55);  //Match ROM
    //write ROM adress
    OWWriteByte(OneWire2[0]);
    OWWriteByte(OneWire2[1]);
    OWWriteByte(OneWire2[2]);
    OWWriteByte(OneWire2[3]);
    OWWriteByte(OneWire2[4]);
    OWWriteByte(OneWire2[5]);
    OWWriteByte(OneWire2[6]);
    OWWriteByte(OneWire2[7]);
    
    OWWriteByte(0xBE);  //Reads the entire scratchpad including the CRC byte
    OWLSB = OWReadByte();   //read least significant byte
    result = OWReadByte();  //read most significant byte
    //combide LSB with MSB
    for(int i = 0; i < 8; i++)
    {
            result = (result << 1);
    }
    result = result + OWLSB;
    //calculate value*10 (for .0 digit)
    result = result * 10;
    result = result / 16;
    //count to avg temperature
    SumTemperatureSoil2 += result;
    AmountTemperatureSoil2++;
    
    return result;
}
int OWTouchReset(void){
    /**********************************************************
    *
    *   resets the OW device
    *   Return sample presence pulse result
    *
    **********************************************************/
    
    int result;
    tickDelay(G);
    POWTemperatureSoil1_Write(0x00); // Drives DQ low
    tickDelay(H);
    POWTemperatureSoil1_Write(0x01); // Releases the bus
    tickDelay(I);
    result = POWTemperatureSoil1_Read() ^ 0x01; // Sample for presence pulse from slave
    tickDelay(J); // Complete the reset sequence recovery
    return result; // Return sample presence pulse result
}
void OWWriteBit(int bit){
    /**********************************************************
    *
    *   writes one bit to the OW device
    *   Input: bit to write
    *
    **********************************************************/
    
    if(bit)
    {
            // Write '1' bit
            POWTemperatureSoil1_Write(0x00); // Drives DQ low
            tickDelay(A);
            POWTemperatureSoil1_Write(0x01); // Releases the bus
            tickDelay(B); // Complete the time slot and 10us recovery
    }
    else
    {
            // Write '0' bit
            POWTemperatureSoil1_Write(0x00); // Drives DQ low
            tickDelay(C);
            POWTemperatureSoil1_Write(0x01); // Releases the bus
            tickDelay(D);
    }
}
int OWReadBit(void){
    /**********************************************************
    *
    *   reads one bit to the OW device
    *   return read information
    *
    **********************************************************/
    
    int result;
    POWTemperatureSoil1_Write(0x00); // Drives DQ low
    tickDelay(A);
    POWTemperatureSoil1_Write(0x01); // Releases the bus
    tickDelay(E);
    result = POWTemperatureSoil1_Read() & 0x01; // Sample the bit value from the slave
    tickDelay(F); // Complete the time slot and 10us recovery

    return result;
}
void OWWriteByte(uint64 data){
    /**********************************************************
    *
    *   writes one Byte to the OW device
    *   Input: data to save
    *
    **********************************************************/
    
    int loop;
    // Loop to write each bit in the byte, LS-bit first
    for (loop = 0; loop < 8; loop++)
    {
            OWWriteBit(data & 0x01);

            // shift the data byte for the next bit
            data >>= 1;
    }
}
int OWReadByte(void){
    /**********************************************************
    *
    *   reads one Byte to the OW device
    *   return read Byte
    *
    **********************************************************/
    
    int loop, result=0;
    for (loop = 0; loop < 8; loop++)
    {
        // shift the result to get it ready for the next bit
        result >>= 1;

        // if result is one, then set MS bit
        if (OWReadBit())
            result |= 0x80;
    }
    return result;
}
void Controlling(){
    /**********************************************************
    *
    *   Controlls the temperature and humidity controlled devices like windows, Heater, etc.
    *
    **********************************************************/
    
    //variables
    char output[200],  airTemp[20], watersprayer[20], windowOpen[20];
    int valueOfAvtive = 0;
    
    //set modes for the Window and heater
    if(airTemperature < 5 && airTemperature < 20) heaterFlag = TRUE;            //activate heater
    else if(airTemperature > 10 && airTemperature < 20) heaterFlag = FALSE;     //deactivate heater
    else if(airTemperature <= 20) OpenWindowPerPercent = 0;                     //close window if its cold
    else if(airTemperature > 20) {
        switch(airTemperature){
        case 21: OpenWindowPerPercent = 1; break;
        case 22: OpenWindowPerPercent = 2; break;
        case 23: OpenWindowPerPercent = 3; break;
        case 24: OpenWindowPerPercent = 4; break;
        default: OpenWindowPerPercent = 5; break;
        }
        PWMServo_WriteCompare(1500-(OpenWindowPerPercent*160));                 //set servo to open windows certain widths
    }
    
    //controlls the sprinkler
    if (airHumidity < 30) waterSprayer = TRUE;                      //activate if humidity too low
    else if (airHumidity > 80) waterSprayer = FALSE;                //deactivate if humitdity over 80%
    
    //print the specific controled devices
    //heater
    if(heaterFlag){PLED_Write(1); strcpy(airTemp, "Heater:\t\tOn\n\r");valueOfAvtive++;}
    else{PLED_Write(0); strcpy(airTemp, "Heater:\t\tOff\n\r");}
    
    //how far is the window open
    if(OpenWindowPerPercent > 0) {sprintf(windowOpen,"Window %d%% open\n\r",OpenWindowPerPercent*20);valueOfAvtive++;}
    else{sprintf(windowOpen,"Window closed\n\r");valueOfAvtive++;}
    
    //watersprayer
    if (waterSprayer) {strcpy(watersprayer,"Watersprayer:\tOn\n\r");valueOfAvtive++;}
    else{strcpy(watersprayer, "Watersprayer:\tOff\n\r");}

    //print all
    sprintf(output, "Controlling systems:\n\r%s%s%s\n\rPress 'ESC' to stop live data.\n\n\n\n\n\r",windowOpen, airTemp, watersprayer);
    UART_1_PutString(output);
}
_Bool SensorAdress(int sensorNumber){
    /**********************************************************
    *
    *   Read and save sensor address
    *   Input: current sensor number
    *   return: TRUE if done
    *
    **********************************************************/
    
    if(sensorNumber==1){                                //for sensor 1
        OWTouchReset();                                 //start sensor
        OWWriteByte(0x33);                              //Set read ROM
        for(int i = 0; i < 8; i++){
            OneWire1[i] = OWReadByte();                 //read address byte, and copy to adress 1
        }
        for(int i = 0; i<8; i++){
            EEPROM_1_WriteByte(OneWire1[i],97*16+i);    //save Sensor ROM
        }
    }
    
     else if(sensorNumber==2){                          //for sensor 2
        OWTouchReset();                                 //start sensor
        OWWriteByte(0x33);                              //Set read ROM
        for(int i = 0; i < 8; i++){
            OneWire2[i] = OWReadByte();                 //read address byte, and copy to adress 1
        }
        for(int i = 0; i<8; i++){
            EEPROM_1_WriteByte(OneWire2[i],98*16+i);    //save Sensor ROM
        }
    }
    return TRUE;
}
/* [] END OF FILE */
